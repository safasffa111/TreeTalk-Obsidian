"use strict";
// TreeTalk portable production bundle generated from TypeScript source.
(function() {
  const __externalRequire = require;
  const __modules = {
"archive/archive-service.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArchiveService = exports.ArchiveError = void 0;
const schema_1 = require("../domain/schema");
class ArchiveError extends Error {
    code;
    recovery;
    constructor(code, message, recovery) {
        super(message);
        this.code = code;
        this.recovery = recovery;
        this.name = "ArchiveError";
    }
}
exports.ArchiveError = ArchiveError;
function folderName(folder, root) {
    const prefix = `${root}/`;
    if (!folder.startsWith(prefix)) {
        throw new ArchiveError("invalid-source", `Folder must be under ${root}`);
    }
    const name = folder.slice(prefix.length);
    if (name.length === 0 || name.includes("/")) {
        throw new ArchiveError("invalid-source", "Conversation folder is invalid");
    }
    return name;
}
function transition(conversation, status) {
    const next = structuredClone(conversation);
    const now = new Date().toISOString();
    next.status = status;
    next.revision += 1;
    next.updatedAt = now;
    return (0, schema_1.parseConversation)(next);
}
class ArchiveService {
    repository;
    folders;
    roots;
    inFlightFolders = new Set();
    constructor(repository, folders, roots) {
        this.repository = repository;
        this.folders = folders;
        this.roots = roots;
    }
    archive(folder, conversation) {
        if (conversation.status !== "active") {
            return Promise.reject(new ArchiveError("invalid-status", "Only active conversations can be archived"));
        }
        return this.moveWithStatus(folder, this.roots.active, this.roots.history, conversation, "archived");
    }
    restore(folder, conversation) {
        if (conversation.status !== "archived") {
            return Promise.reject(new ArchiveError("invalid-status", "Only archived conversations can be restored"));
        }
        return this.moveWithStatus(folder, this.roots.history, this.roots.active, conversation, "active");
    }
    async moveWithStatus(folder, sourceRoot, destinationRoot, conversation, status) {
        if (this.inFlightFolders.has(folder)) {
            throw new ArchiveError("operation-in-progress", `A lifecycle operation is already running for ${folder}`);
        }
        this.inFlightFolders.add(folder);
        try {
            return await this.performMoveWithStatus(folder, sourceRoot, destinationRoot, conversation, status);
        }
        finally {
            this.inFlightFolders.delete(folder);
        }
    }
    async performMoveWithStatus(folder, sourceRoot, destinationRoot, conversation, status) {
        const name = folderName(folder, sourceRoot);
        const destination = `${destinationRoot}/${name}`;
        const destinationFiles = await this.folders.list(`${destination}/`);
        if ((await this.folders.exists(destination)) || destinationFiles.length > 0) {
            throw new ArchiveError("destination-exists", `Conversation folder already exists: ${destination}`);
        }
        const next = transition(conversation, status);
        const saved = await this.repository.save(folder, next, conversation.revision);
        try {
            await this.folders.move(folder, destination);
        }
        catch (moveError) {
            const sourcePresent = (await this.folders.exists(folder)) ||
                (await this.folders.list(`${folder}/`)).length > 0;
            const destinationPresent = (await this.folders.exists(destination)) ||
                (await this.folders.list(`${destination}/`)).length > 0;
            if (!sourcePresent && destinationPresent) {
                return { conversation: saved, folder: destination };
            }
            if (!sourcePresent || destinationPresent) {
                throw new ArchiveError("move-state-unknown", `Folder move ended in an ambiguous state: ${String(moveError)}`);
            }
            try {
                const rollback = transition(saved, conversation.status);
                const recovered = await this.repository.save(folder, rollback, saved.revision);
                throw new ArchiveError("move-failed", `Folder move failed and status was restored: ${String(moveError)}`, { conversation: recovered, folder });
            }
            catch (rollbackError) {
                if (rollbackError instanceof ArchiveError && rollbackError.code === "move-failed") {
                    throw rollbackError;
                }
                throw new ArchiveError("rollback-failed", `Folder move and status rollback both failed: ${String(rollbackError)}`);
            }
            throw moveError;
        }
        return { conversation: saved, folder: destination };
    }
}
exports.ArchiveService = ArchiveService;

},
"archive/lifecycle-queue.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LifecycleQueue = void 0;
class LifecycleQueue {
    tail = Promise.resolve();
    run(operation) {
        const result = this.tail.catch(() => undefined).then(operation);
        this.tail = result.then(() => undefined, () => undefined);
        return result;
    }
}
exports.LifecycleQueue = LifecycleQueue;

},
"archive/lifecycle-reconciler.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LifecycleReconciler = void 0;
const schema_1 = require("../domain/schema");
function withStatus(conversation, status) {
    const next = structuredClone(conversation);
    next.status = status;
    next.revision += 1;
    next.updatedAt = new Date().toISOString();
    return (0, schema_1.parseConversation)(next);
}
function directConversationFolders(paths, root) {
    const folders = new Set();
    const prefix = `${root}/`;
    for (const path of paths) {
        if (!path.startsWith(prefix))
            continue;
        const relative = path.slice(prefix.length);
        const parts = relative.split("/");
        if (parts.length === 2 &&
            (parts[1] === "tree.json" || parts[1] === "tree.backup.json")) {
            folders.add(`${root}/${parts[0] ?? ""}`);
        }
    }
    return [...folders];
}
class LifecycleReconciler {
    repository;
    vault;
    roots;
    constructor(repository, vault, roots) {
        this.repository = repository;
        this.vault = vault;
        this.roots = roots;
    }
    async reconcile() {
        let repaired = 0;
        let failed = 0;
        const lifecycleRoots = [
            { path: this.roots.active, status: "active" },
            { path: this.roots.history, status: "archived" }
        ];
        for (const root of lifecycleRoots) {
            const folders = directConversationFolders(await this.vault.list(`${root.path}/`), root.path);
            for (const folder of folders) {
                try {
                    const loaded = await this.repository.load(folder);
                    if (loaded.conversation.status === root.status)
                        continue;
                    await this.repository.save(folder, withStatus(loaded.conversation, root.status), loaded.conversation.revision);
                    repaired += 1;
                }
                catch {
                    failed += 1;
                }
            }
        }
        return { repaired, failed };
    }
}
exports.LifecycleReconciler = LifecycleReconciler;

},
"domain/assistant-response.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startAssistantResponse = startAssistantResponse;
exports.appendAssistantDelta = appendAssistantDelta;
exports.finishAssistantResponse = finishAssistantResponse;
exports.appendAssistantResponse = appendAssistantResponse;
const schema_1 = require("./schema");
function mutableNode(conversation, conversationId, nodeId) {
    if (conversation.status !== "active" ||
        conversation.id !== conversationId) {
        throw new Error("Conversation is no longer active");
    }
    const next = structuredClone(conversation);
    const node = next.nodes[nodeId];
    if (node === undefined) {
        throw new Error(`Conversation node no longer exists: ${nodeId}`);
    }
    return { next, node };
}
function commit(conversation, nodeId, now) {
    const node = conversation.nodes[nodeId];
    if (node === undefined)
        throw new Error(`Conversation node no longer exists: ${nodeId}`);
    node.updatedAt = now;
    conversation.updatedAt = now;
    conversation.revision += 1;
    return (0, schema_1.parseConversation)(conversation);
}
function startAssistantResponse(conversation, input) {
    const { next, node } = mutableNode(conversation, input.conversationId, input.nodeId);
    if (node.messages.some((message) => message.id === input.messageId)) {
        throw new Error(`Assistant message already exists: ${input.messageId}`);
    }
    const message = {
        id: input.messageId,
        role: "assistant",
        content: "",
        status: "streaming",
        modelId: input.modelId,
        createdAt: input.now,
        updatedAt: input.now
    };
    if (input.providerProfileId !== undefined) {
        message.providerProfileId = input.providerProfileId;
    }
    node.messages.push(message);
    return commit(next, input.nodeId, input.now);
}
function appendAssistantDelta(conversation, input) {
    const { next, node } = mutableNode(conversation, input.conversationId, input.nodeId);
    const message = node.messages.find((entry) => entry.id === input.messageId);
    if (message === undefined || message.status !== "streaming") {
        throw new Error("Streaming assistant message is unavailable");
    }
    message.content += input.delta;
    message.updatedAt = input.now;
    return commit(next, input.nodeId, input.now);
}
function finishAssistantResponse(conversation, input) {
    const { next, node } = mutableNode(conversation, input.conversationId, input.nodeId);
    const message = node.messages.find((entry) => entry.id === input.messageId);
    if (message === undefined || message.status !== "streaming") {
        throw new Error("Streaming assistant message is unavailable");
    }
    if (input.finalContent !== undefined)
        message.content = input.finalContent;
    message.status = input.status;
    if (input.status === "complete") {
        message.referencedNoteNames = [...(input.referencedNoteNames ?? [])];
    }
    else {
        delete message.referencedNoteNames;
    }
    message.updatedAt = input.now;
    return commit(next, input.nodeId, input.now);
}
function appendAssistantResponse(conversation, input) {
    if (conversation.status !== "active" ||
        conversation.id !== input.conversationId) {
        throw new Error("Conversation is no longer active");
    }
    const next = structuredClone(conversation);
    const node = next.nodes[input.nodeId];
    if (node === undefined) {
        throw new Error(`Conversation node no longer exists: ${input.nodeId}`);
    }
    const message = {
        id: input.messageId,
        role: "assistant",
        content: input.content,
        status: "complete",
        modelId: input.modelId,
        createdAt: input.now,
        updatedAt: input.now
    };
    if (input.providerProfileId !== undefined) {
        message.providerProfileId = input.providerProfileId;
    }
    message.referencedNoteNames = [...(input.referencedNoteNames ?? [])];
    node.messages.push(message);
    node.updatedAt = input.now;
    next.updatedAt = input.now;
    next.revision += 1;
    return (0, schema_1.parseConversation)(next);
}

},
"domain/balanced-freeze-v3.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BALANCED_V3_ASSISTANT_OMISSION = exports.BALANCED_V3_PROTOCOL = void 0;
exports.balancedV3TextHash = balancedV3TextHash;
exports.protectionHashForRanges = protectionHashForRanges;
exports.assistantRetentionRatio = assistantRetentionRatio;
exports.noteRetentionRatio = noteRetentionRatio;
exports.buildAssistantFreezeArtifact = buildAssistantFreezeArtifact;
exports.buildNoteFreezeArtifact = buildNoteFreezeArtifact;
exports.buildRecoveryPatchArtifact = buildRecoveryPatchArtifact;
const balanced_markdown_compressor_1 = require("./balanced-markdown-compressor");
const note_snapshot_1 = require("./note-snapshot");
exports.BALANCED_V3_PROTOCOL = "balanced:v3";
exports.BALANCED_V3_ASSISTANT_OMISSION = "[TreeTalk 已省略部分较早的回答内容]";
function estimateTokens(text) {
    let weighted = 0;
    for (const character of text) {
        if (/\s/u.test(character))
            continue;
        if (/\p{Script=Han}|\p{Script=Hiragana}|\p{Script=Katakana}|\p{Extended_Pictographic}/u.test(character)) {
            weighted += 1;
        }
        else if (/[^\x00-\x7F]/u.test(character)) {
            weighted += 0.6;
        }
        else {
            weighted += 0.25;
        }
    }
    return Math.max(1, Math.ceil(weighted));
}
function balancedV3TextHash(value) {
    let hash = 0x811c9dc5;
    for (let index = 0; index < value.length; index += 1) {
        hash ^= value.charCodeAt(index);
        hash = Math.imul(hash, 0x01000193);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
}
function canonicalRanges(ranges) {
    const sorted = ranges
        .filter((range) => Number.isInteger(range.start) && Number.isInteger(range.end))
        .map((range) => ({
        start: Math.max(0, range.start),
        end: Math.max(0, range.end)
    }))
        .filter((range) => range.end > range.start)
        .sort((left, right) => left.start - right.start || left.end - right.end);
    const merged = [];
    for (const range of sorted) {
        const previous = merged.at(-1);
        if (previous !== undefined && range.start <= previous.end) {
            previous.end = Math.max(previous.end, range.end);
        }
        else {
            merged.push({ ...range });
        }
    }
    return merged;
}
function protectionHashForRanges(ranges) {
    const canonical = canonicalRanges(ranges);
    return canonical.length === 0
        ? "none"
        : balancedV3TextHash(canonical.map((range) => `${range.start}:${range.end}`).join("|"));
}
function artifactKey(parts) {
    return `balanced-v3-${balancedV3TextHash(parts.join("\u0001"))}`;
}
function assistantRetentionRatio(originalEstimatedTokens, tier) {
    if (tier === "compact")
        return 0.25;
    if (originalEstimatedTokens < 160)
        return 1;
    if (originalEstimatedTokens < 800)
        return 0.6;
    if (originalEstimatedTokens < 2000)
        return 0.5;
    return 0.4;
}
function noteRetentionRatio(originalEstimatedTokens, tier) {
    if (tier === "compact")
        return 0.35;
    if (originalEstimatedTokens < 300)
        return 1;
    if (originalEstimatedTokens < 1500)
        return 0.6;
    return 0.5;
}
function deletionRatio(original, sent) {
    return original <= 0 ? 0 : Math.max(0, Math.min(1, 1 - sent / original));
}
function buildAssistantFreezeArtifact(input) {
    const originalEstimatedTokens = estimateTokens(input.content);
    const retention = assistantRetentionRatio(originalEstimatedTokens, input.tier);
    if (retention >= 1)
        return undefined;
    const protectedRanges = canonicalRanges(input.protectedRanges);
    const result = (0, balanced_markdown_compressor_1.compressAssistantMarkdown)(input.content, {
        protectedRanges,
        targetRatio: retention,
        maxTokens: Math.max(input.tier === "compact" ? 64 : 96, Math.floor(originalEstimatedTokens * retention)),
        minTokens: input.tier === "compact" ? 64 : 96,
        omissionMarker: exports.BALANCED_V3_ASSISTANT_OMISSION
    });
    if (!result.compressed || result.content === input.content)
        return undefined;
    const protectionHash = protectionHashForRanges(protectedRanges);
    const key = artifactKey([
        exports.BALANCED_V3_PROTOCOL,
        "assistant-message",
        input.sourceIdentity,
        input.sourceContentHash,
        protectionHash,
        input.tier
    ]);
    return {
        protocol: exports.BALANCED_V3_PROTOCOL,
        key,
        sourceType: "assistant-message",
        sourceIdentity: input.sourceIdentity,
        sourceContentHash: input.sourceContentHash,
        protectionHash,
        tier: input.tier,
        content: result.content,
        originalEstimatedTokens: result.originalEstimatedTokens,
        sentEstimatedTokens: result.sentEstimatedTokens,
        deletionRatio: deletionRatio(result.originalEstimatedTokens, result.sentEstimatedTokens)
    };
}
function buildNoteFreezeArtifact(input) {
    const originalEstimatedTokens = (0, note_snapshot_1.estimateNoteTextTokens)(input.snapshot.content);
    const retention = noteRetentionRatio(originalEstimatedTokens, input.tier);
    if (retention >= 1)
        return undefined;
    const result = (0, note_snapshot_1.renderNoteSnapshot)(input.snapshot, Math.max(1, Math.floor(originalEstimatedTokens * retention)));
    if (!result.trimmed || result.content === input.snapshot.content)
        return undefined;
    const protectionHash = balancedV3TextHash(`${input.snapshot.selectionStartOffset}:${input.snapshot.selectionEndOffset}`);
    const key = artifactKey([
        exports.BALANCED_V3_PROTOCOL,
        "note-snapshot",
        input.sourceIdentity,
        input.sourceContentHash,
        protectionHash,
        input.tier
    ]);
    return {
        protocol: exports.BALANCED_V3_PROTOCOL,
        key,
        sourceType: "note-snapshot",
        sourceIdentity: input.sourceIdentity,
        sourceContentHash: input.sourceContentHash,
        protectionHash,
        tier: input.tier,
        content: result.content,
        originalEstimatedTokens: result.originalEstimatedTokens,
        sentEstimatedTokens: result.sentEstimatedTokens,
        deletionRatio: deletionRatio(result.originalEstimatedTokens, result.sentEstimatedTokens)
    };
}
function paragraphRanges(content) {
    const ranges = [];
    const pattern = /(?:^|\n\s*\n)([\s\S]*?)(?=\n\s*\n|$)/gu;
    for (const match of content.matchAll(pattern)) {
        const raw = match[1] ?? "";
        const matchStart = (match.index ?? 0) + (match[0]?.indexOf(raw) ?? 0);
        if (raw.trim().length > 0) {
            ranges.push({ start: matchStart, end: matchStart + raw.length });
        }
    }
    return ranges;
}
function containingFence(content, start) {
    const lines = content.split("\n");
    let offset = 0;
    let open;
    for (const line of lines) {
        const lineStart = offset;
        const lineEnd = lineStart + line.length;
        const fence = line.match(/^\s*(`{3,}|~{3,})/u)?.[1];
        if (open === undefined && fence !== undefined) {
            open = { start: lineStart, marker: fence[0] ?? "`" };
        }
        else if (open !== undefined &&
            new RegExp(`^\\s*${open.marker}{3,}\\s*$`, "u").test(line)) {
            const range = { start: open.start, end: lineEnd };
            if (start >= range.start && start <= range.end)
                return range;
            open = undefined;
        }
        offset = lineEnd + 1;
    }
    return undefined;
}
function nearestHeading(content, start) {
    const prefix = content.slice(0, Math.max(0, start));
    return [...prefix.matchAll(/^#{1,6}[ \t]+.*$/gmu)].at(-1)?.[0];
}
function localContext(content, startOffset, endOffset, quote) {
    let start = Math.max(0, Math.min(content.length, startOffset));
    let end = Math.max(start, Math.min(content.length, endOffset));
    if (content.slice(start, end) !== quote) {
        const exact = content.indexOf(quote);
        if (exact >= 0) {
            start = exact;
            end = exact + quote.length;
        }
    }
    const fence = containingFence(content, start);
    if (fence !== undefined)
        return content.slice(fence.start, fence.end).trim();
    const paragraphs = paragraphRanges(content);
    const selectedIndex = paragraphs.findIndex((range) => start < range.end && end > range.start);
    const pieces = [];
    const heading = nearestHeading(content, start);
    if (heading !== undefined)
        pieces.push(heading);
    if (selectedIndex >= 0) {
        for (const index of [selectedIndex - 1, selectedIndex, selectedIndex + 1]) {
            const range = paragraphs[index];
            if (range !== undefined)
                pieces.push(content.slice(range.start, range.end).trim());
        }
    }
    const unique = [...new Set(pieces.filter((piece) => piece.length > 0))];
    while (unique.length > 1 && estimateTokens(unique.join("\n\n")) > 512) {
        unique.shift();
    }
    let joined = unique.join("\n\n");
    if (estimateTokens(joined) > 512) {
        let left = 0;
        let right = joined.length;
        while (left < right && estimateTokens(joined.slice(0, right)) > 512) {
            right = Math.max(1, Math.floor(right * 0.9));
        }
        joined = joined.slice(0, right).trim();
    }
    return joined;
}
function buildRecoveryPatchArtifact(input) {
    const context = localContext(input.sourceContent, input.startOffset, input.endOffset, input.quote);
    const content = [
        "[TreeTalk 恢复引用]",
        `来源：${input.sourceLabel}`,
        "用户框选原文：",
        "---",
        input.quote,
        "---",
        ...(context.length === 0
            ? []
            : ["局部辅助上下文：", "---", context, "---"]),
        "[恢复引用结束]"
    ].join("\n");
    const protectionHash = balancedV3TextHash(`${input.startOffset}:${input.endOffset}:${balancedV3TextHash(input.quote)}`);
    const key = artifactKey([
        exports.BALANCED_V3_PROTOCOL,
        "recovery-patch",
        input.sourceIdentity,
        input.sourceContentHash,
        protectionHash,
        "standard"
    ]);
    const originalEstimatedTokens = estimateTokens(input.sourceContent);
    const sentEstimatedTokens = estimateTokens(content);
    return {
        protocol: exports.BALANCED_V3_PROTOCOL,
        key,
        sourceType: "recovery-patch",
        sourceIdentity: input.sourceIdentity,
        sourceContentHash: input.sourceContentHash,
        protectionHash,
        tier: "standard",
        content,
        originalEstimatedTokens,
        sentEstimatedTokens,
        deletionRatio: deletionRatio(originalEstimatedTokens, sentEstimatedTokens)
    };
}

},
"domain/balanced-markdown-compressor.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseStructuredMarkdown = parseStructuredMarkdown;
exports.resolveSelectionInMarkdown = resolveSelectionInMarkdown;
exports.compressAssistantMarkdown = compressAssistantMarkdown;
const HISTORY_OMISSION = "> [!note]- TreeTalk 已压缩历史内容\n> 省略了未被后续对话引用的说明。";
const CODE_OMISSION_TEXT = "TreeTalk 已压缩历史内容：省略未引用代码";
const MIN_COMPRESSIBLE_TOKENS = 160;
const MIN_MEANINGFUL_SAVINGS = 12;
function estimateTokens(text) {
    let weighted = 0;
    for (const character of text) {
        if (/\s/u.test(character))
            continue;
        if (/\p{Script=Han}|\p{Script=Hiragana}|\p{Script=Katakana}|\p{Extended_Pictographic}/u.test(character)) {
            weighted += 1;
        }
        else if (/[^\x00-\x7F]/u.test(character)) {
            weighted += 0.6;
        }
        else {
            weighted += 0.25;
        }
    }
    return Math.max(1, Math.ceil(weighted));
}
function sourceLines(markdown) {
    if (markdown.length === 0)
        return [];
    const lines = [];
    let start = 0;
    while (start < markdown.length) {
        const newline = markdown.indexOf("\n", start);
        const end = newline < 0 ? markdown.length : newline + 1;
        const raw = markdown.slice(start, end);
        lines.push({
            start,
            end,
            text: raw.replace(/\r?\n$/u, "")
        });
        start = end;
    }
    return lines;
}
function isBlank(line) {
    return line.text.trim().length === 0;
}
function fenceStart(text) {
    const match = text.match(/^\s*(`{3,}|~{3,})/u);
    const marker = match?.[1];
    if (marker === undefined)
        return undefined;
    const character = marker[0];
    if (character !== "`" && character !== "~")
        return undefined;
    return { character, length: marker.length };
}
function isFenceEnd(text, fence) {
    const escaped = fence.character === "`" ? "`" : "~";
    return new RegExp(`^\\s*${escaped}{${String(fence.length)},}\\s*$`, "u").test(text);
}
function isMathFence(text) {
    return /^\s*\$\$\s*$/u.test(text);
}
function heading(text) {
    const match = text.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/u);
    if (match === null)
        return undefined;
    return { level: match[1]?.length ?? 1, title: match[2] ?? "" };
}
function isListStart(text) {
    return /^\s*(?:[-*+]\s+|\d+[.)]\s+)/u.test(text);
}
function isQuoteStart(text) {
    return /^\s*>/u.test(text);
}
function isTableSeparator(text) {
    if (!text.includes("|"))
        return false;
    const cells = text.trim().replace(/^\|/u, "").replace(/\|$/u, "").split("|");
    return cells.length > 0 && cells.every((cell) => /^\s*:?-{3,}:?\s*$/u.test(cell));
}
function isTableStart(lines, index) {
    const current = lines[index];
    const next = lines[index + 1];
    return current !== undefined && next !== undefined && current.text.includes("|") && isTableSeparator(next.text);
}
function priorityFor(kind, content, isFirst) {
    let priority = 20;
    if (kind === "heading")
        priority = 72;
    else if (kind === "table")
        priority = 64;
    else if (kind === "math")
        priority = 62;
    else if (kind === "code")
        priority = 48;
    else if (kind === "list")
        priority = 44;
    else if (kind === "quote")
        priority = 42;
    if (/定义|结论|总结|原因|限制|前提|注意|警告|错误|关键|步骤|接口|参数|返回值|必须|禁止|不要|因此|所以/iu.test(content)) {
        priority += 28;
    }
    if (isFirst && kind !== "heading")
        priority += 18;
    return priority;
}
function intersects(left, right) {
    return left.start < right.end && right.start < left.end;
}
function parseInternal(markdown, protectedRanges) {
    const lines = sourceLines(markdown);
    const blocks = [];
    const headingTitles = [];
    const headingIndexes = [];
    let index = 0;
    let firstSubstantiveSeen = false;
    const addBlock = (kind, startLine, endLineExclusive, headingPath, blockHeadingIndexes) => {
        const first = lines[startLine];
        const last = lines[endLineExclusive - 1];
        if (first === undefined || last === undefined)
            return;
        const startOffset = first.start;
        const rawLastLine = markdown.slice(last.start, last.end);
        const trailingNewlineLength = rawLastLine.endsWith("\r\n")
            ? 2
            : rawLastLine.endsWith("\n")
                ? 1
                : 0;
        const endOffset = last.end - trailingNewlineLength;
        const content = markdown.slice(startOffset, endOffset);
        const range = { start: startOffset, end: endOffset };
        const protectedBySelection = protectedRanges.some((item) => intersects(range, item));
        const isFirst = !firstSubstantiveSeen && kind !== "heading";
        if (kind !== "heading")
            firstSubstantiveSeen = true;
        blocks.push({
            kind,
            startOffset,
            endOffset,
            content,
            headingPath: [...headingPath],
            headingIndexes: [...blockHeadingIndexes],
            protectedBySelection,
            priority: priorityFor(kind, content, isFirst),
            estimatedTokens: estimateTokens(content)
        });
    };
    while (index < lines.length) {
        const current = lines[index];
        if (current === undefined)
            break;
        if (isBlank(current)) {
            index += 1;
            continue;
        }
        const fence = fenceStart(current.text);
        if (fence !== undefined) {
            let end = index + 1;
            while (end < lines.length && !isFenceEnd(lines[end]?.text ?? "", fence))
                end += 1;
            if (end >= lines.length)
                return { ok: false, reason: "unclosed-code-fence" };
            addBlock("code", index, end + 1, headingTitles, headingIndexes);
            index = end + 1;
            continue;
        }
        if (isMathFence(current.text)) {
            let end = index + 1;
            while (end < lines.length && !isMathFence(lines[end]?.text ?? ""))
                end += 1;
            if (end >= lines.length)
                return { ok: false, reason: "unclosed-math-fence" };
            addBlock("math", index, end + 1, headingTitles, headingIndexes);
            index = end + 1;
            continue;
        }
        const currentHeading = heading(current.text);
        if (currentHeading !== undefined) {
            headingTitles.length = currentHeading.level - 1;
            headingIndexes.length = currentHeading.level - 1;
            headingTitles[currentHeading.level - 1] = currentHeading.title;
            const blockIndex = blocks.length;
            headingIndexes[currentHeading.level - 1] = blockIndex;
            addBlock("heading", index, index + 1, headingTitles, headingIndexes.slice(0, -1));
            index += 1;
            continue;
        }
        if (isQuoteStart(current.text)) {
            let end = index + 1;
            while (end < lines.length && isQuoteStart(lines[end]?.text ?? ""))
                end += 1;
            addBlock("quote", index, end, headingTitles, headingIndexes);
            index = end;
            continue;
        }
        if (isTableStart(lines, index)) {
            let end = index + 2;
            while (end < lines.length && !isBlank(lines[end] ?? { start: 0, end: 0, text: "" }) && (lines[end]?.text.includes("|") ?? false)) {
                end += 1;
            }
            addBlock("table", index, end, headingTitles, headingIndexes);
            index = end;
            continue;
        }
        if (isListStart(current.text)) {
            let end = index + 1;
            while (end < lines.length) {
                const line = lines[end];
                if (line === undefined || isBlank(line))
                    break;
                if (heading(line.text) !== undefined || fenceStart(line.text) !== undefined || isMathFence(line.text) || isQuoteStart(line.text) || isTableStart(lines, end))
                    break;
                if (!isListStart(line.text) && !/^\s{2,}\S/u.test(line.text))
                    break;
                end += 1;
            }
            addBlock("list", index, end, headingTitles, headingIndexes);
            index = end;
            continue;
        }
        let end = index + 1;
        while (end < lines.length) {
            const line = lines[end];
            if (line === undefined || isBlank(line))
                break;
            if (heading(line.text) !== undefined || fenceStart(line.text) !== undefined || isMathFence(line.text) || isQuoteStart(line.text) || isTableStart(lines, end) || isListStart(line.text))
                break;
            end += 1;
        }
        addBlock("paragraph", index, end, headingTitles, headingIndexes);
        index = end;
    }
    return { ok: true, blocks };
}
function parseStructuredMarkdown(markdown) {
    const result = parseInternal(markdown, []);
    if (!result.ok)
        return result;
    return {
        ok: true,
        blocks: result.blocks.map(({ headingIndexes: _headingIndexes, ...block }) => block)
    };
}
function commonSuffixLength(left, right) {
    const maximum = Math.min(left.length, right.length);
    let matched = 0;
    while (matched < maximum && left[left.length - 1 - matched] === right[right.length - 1 - matched])
        matched += 1;
    return matched;
}
function commonPrefixLength(left, right) {
    const maximum = Math.min(left.length, right.length);
    let matched = 0;
    while (matched < maximum && left[matched] === right[matched])
        matched += 1;
    return matched;
}
function resolveSelectionInMarkdown(markdown, anchor) {
    const searchTerms = [anchor.quote, anchor.visibleQuote]
        .filter((value) => value !== undefined && value.length > 0)
        .filter((value, index, values) => values.indexOf(value) === index);
    if (Number.isInteger(anchor.startOffset) &&
        Number.isInteger(anchor.endOffset) &&
        anchor.startOffset >= 0 &&
        anchor.endOffset > anchor.startOffset &&
        anchor.endOffset <= markdown.length) {
        const exact = markdown.slice(anchor.startOffset, anchor.endOffset);
        const visibleTerm = anchor.visibleQuote ?? anchor.quote;
        if (exact === visibleTerm) {
            return {
                status: "resolved",
                start: anchor.startOffset,
                end: anchor.endOffset
            };
        }
    }
    for (const term of searchTerms) {
        const candidates = [];
        let from = 0;
        while (from <= markdown.length - term.length) {
            const start = markdown.indexOf(term, from);
            if (start < 0)
                break;
            const end = start + term.length;
            const before = markdown.slice(Math.max(0, start - anchor.prefix.length), start);
            const after = markdown.slice(end, end + anchor.suffix.length);
            candidates.push({
                start,
                end,
                contextScore: commonSuffixLength(anchor.prefix, before) + commonPrefixLength(anchor.suffix, after),
                distance: Math.abs(start - anchor.startOffset)
            });
            from = start + Math.max(1, term.length);
        }
        if (candidates.length === 0)
            continue;
        if (candidates.length === 1) {
            const only = candidates[0];
            if (only !== undefined)
                return { status: "resolved", start: only.start, end: only.end };
        }
        candidates.sort((left, right) => right.contextScore - left.contextScore || left.distance - right.distance || left.start - right.start);
        const best = candidates[0];
        const second = candidates[1];
        if (best === undefined)
            continue;
        if (best.contextScore === 0 || (second !== undefined && second.contextScore === best.contextScore)) {
            return { status: "unresolved", quote: anchor.quote };
        }
        return { status: "resolved", start: best.start, end: best.end };
    }
    return { status: "unresolved", quote: anchor.quote };
}
function codeOmissionComment(language) {
    const normalized = language.toLowerCase();
    if (/^(?:py|python|sh|bash|zsh|fish|yaml|yml|toml|r|ruby|perl)$/u.test(normalized)) {
        return `# ${CODE_OMISSION_TEXT}`;
    }
    if (/^(?:html|xml|svg|md|markdown)$/u.test(normalized)) {
        return `<!-- ${CODE_OMISSION_TEXT} -->`;
    }
    return `// ${CODE_OMISSION_TEXT}`;
}
function looksLikeSignature(line) {
    return /^\s*(?:import|export|from|require|#include|using|package|class|interface|type|enum|struct|def|fn|func|function|public|private|protected|static|async|const\s+\w+\s*=\s*\(|let\s+\w+\s*=\s*\().*/u.test(line);
}
function compactCode(content, maxTokens) {
    if (estimateTokens(content) <= maxTokens)
        return content;
    const lines = content.split("\n");
    const opening = lines[0] ?? "```";
    const closing = lines.at(-1) ?? "```";
    const language = opening.replace(/^\s*(`{3,}|~{3,})/u, "").trim();
    const body = lines.slice(1, -1);
    const keep = new Set();
    for (let index = 0; index < Math.min(6, body.length); index += 1)
        keep.add(index);
    for (let index = Math.max(0, body.length - 4); index < body.length; index += 1)
        keep.add(index);
    for (const [lineIndex, line] of body.entries()) {
        if (looksLikeSignature(line))
            keep.add(lineIndex);
        if (keep.size >= 28)
            break;
    }
    const selected = [...keep].sort((left, right) => left - right);
    const output = [opening];
    let previous = -1;
    for (const lineIndex of selected) {
        if (previous >= 0 && lineIndex > previous + 1)
            output.push(codeOmissionComment(language));
        output.push(body[lineIndex] ?? "");
        previous = lineIndex;
    }
    output.push(closing);
    return output.join("\n");
}
function clampRatio(value) {
    if (value === undefined || !Number.isFinite(value))
        return 0.45;
    return Math.min(0.6, Math.max(0.25, value));
}
function addHeadingAncestors(blocks, selected) {
    let changed = true;
    while (changed) {
        changed = false;
        for (const index of [...selected]) {
            const block = blocks[index];
            if (block === undefined)
                continue;
            for (const headingIndex of block.headingIndexes) {
                if (!selected.has(headingIndex)) {
                    selected.add(headingIndex);
                    changed = true;
                }
            }
        }
    }
}
function compressAssistantMarkdown(markdown, options = {}) {
    const originalEstimatedTokens = estimateTokens(markdown);
    const unchanged = () => ({
        content: markdown,
        compressed: false,
        originalEstimatedTokens,
        sentEstimatedTokens: originalEstimatedTokens
    });
    if (originalEstimatedTokens <= MIN_COMPRESSIBLE_TOKENS)
        return unchanged();
    const protectedRanges = options.protectedRanges ?? [];
    const parsed = parseInternal(markdown, protectedRanges);
    if (!parsed.ok || parsed.blocks.length < 3)
        return unchanged();
    const blocks = parsed.blocks;
    const ratio = clampRatio(options.targetRatio);
    const minimumTokens = Math.max(1, Math.floor(options.minTokens ?? 96));
    const ratioTarget = Math.max(minimumTokens, Math.floor(originalEstimatedTokens * ratio));
    const target = options.maxTokens === undefined
        ? ratioTarget
        : Math.max(minimumTokens, Math.min(ratioTarget, Math.floor(options.maxTokens)));
    const omissionMarker = options.omissionMarker ?? HISTORY_OMISSION;
    const selected = new Set();
    for (const [blockIndex, block] of blocks.entries()) {
        if (block.protectedBySelection)
            selected.add(blockIndex);
    }
    const substantive = blocks
        .map((block, blockIndex) => ({ block, blockIndex }))
        .filter(({ block }) => block.kind !== "heading");
    const first = substantive[0];
    const last = substantive.at(-1);
    if (first !== undefined)
        selected.add(first.blockIndex);
    if (last !== undefined)
        selected.add(last.blockIndex);
    for (const { block, blockIndex } of substantive) {
        if (block.priority >= 70)
            selected.add(blockIndex);
    }
    for (const protectedIndex of [...selected]) {
        const protectedBlock = blocks[protectedIndex];
        if (protectedBlock?.protectedBySelection !== true)
            continue;
        for (const neighborIndex of [protectedIndex - 1, protectedIndex + 1]) {
            const neighbor = blocks[neighborIndex];
            if (neighbor !== undefined && neighbor.kind !== "heading" && neighbor.estimatedTokens <= 96) {
                selected.add(neighborIndex);
            }
        }
    }
    addHeadingAncestors(blocks, selected);
    let used = [...selected].reduce((total, blockIndex) => total + (blocks[blockIndex]?.estimatedTokens ?? 0), 0);
    const ranked = blocks
        .map((block, blockIndex) => ({ block, blockIndex }))
        .filter(({ blockIndex }) => !selected.has(blockIndex))
        .sort((left, right) => right.block.priority - left.block.priority || left.blockIndex - right.blockIndex);
    for (const { block, blockIndex } of ranked) {
        if (block.kind === "heading")
            continue;
        if (used + block.estimatedTokens > target)
            continue;
        selected.add(blockIndex);
        used += block.estimatedTokens;
    }
    addHeadingAncestors(blocks, selected);
    const pieces = [];
    let omitted = false;
    for (const [blockIndex, block] of blocks.entries()) {
        if (!selected.has(blockIndex)) {
            omitted = true;
            continue;
        }
        if (omitted && pieces.length > 0)
            pieces.push(omissionMarker);
        omitted = false;
        let content = block.content;
        if (block.kind === "code" && !block.protectedBySelection) {
            content = compactCode(content, Math.max(96, Math.floor(target * 0.45)));
        }
        pieces.push(content.trim());
    }
    if (omitted && pieces.length > 0)
        pieces.push(omissionMarker);
    const content = pieces.join("\n\n").trim();
    const sentEstimatedTokens = estimateTokens(content);
    if (content.length === 0 || sentEstimatedTokens >= originalEstimatedTokens - MIN_MEANINGFUL_SAVINGS) {
        return unchanged();
    }
    return {
        content,
        compressed: true,
        originalEstimatedTokens,
        sentEstimatedTokens
    };
}

},
"domain/context-builder.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildProviderContext = buildProviderContext;
function requiredNode(conversation, nodeId) {
    const node = conversation.nodes[nodeId];
    if (node === undefined) {
        throw new Error(`Node not found: ${nodeId}`);
    }
    return node;
}
function pathToNode(conversation, nodeId) {
    const reversed = [];
    const seen = new Set();
    let current = requiredNode(conversation, nodeId);
    while (current !== undefined) {
        if (seen.has(current.id)) {
            throw new Error("Conversation path contains a cycle");
        }
        seen.add(current.id);
        reversed.push(current);
        current = current.parentId === null ? undefined : requiredNode(conversation, current.parentId);
    }
    return reversed.reverse();
}
function providerContent(message) {
    const contexts = message.selectionContexts ?? [];
    if (contexts.length === 0)
        return message.content;
    const rendered = contexts
        .map((context, index) => [
        `[TreeTalk 引用上下文 ${String(index + 1)}]`,
        "以下内容仅作为回答参考：",
        "---",
        context.quote,
        "---",
        "[引用上下文结束]"
    ].join("\n"))
        .join("\n\n");
    return `${rendered}\n\n[当前问题]\n${message.content}`;
}
function buildProviderContext(conversation, nodeId, limits) {
    if (!Number.isFinite(limits.maxCharacters) || limits.maxCharacters <= 0) {
        throw new Error("maxCharacters must be positive");
    }
    const path = pathToNode(conversation, nodeId);
    const weighted = [];
    if (limits.systemPrompt.length > 0) {
        weighted.push({ role: "system", content: limits.systemPrompt, protected: true });
    }
    for (const [nodeIndex, node] of path.entries()) {
        const isCurrent = nodeIndex === path.length - 1;
        for (const [messageIndex, message] of node.messages.entries()) {
            weighted.push({
                role: message.role,
                content: providerContent(message),
                protected: (message.selectionContexts?.length ?? 0) > 0 ||
                    (isCurrent && messageIndex === node.messages.length - 1)
            });
        }
    }
    const size = () => weighted.reduce((total, entry) => total + entry.content.length, 0);
    while (size() > limits.maxCharacters) {
        const removableIndex = weighted.findIndex((entry, index) => !entry.protected && entry.role !== "system" && index < weighted.length - 1);
        if (removableIndex < 0)
            break;
        weighted.splice(removableIndex, 1);
    }
    return weighted.map(({ role, content }) => ({ role, content }));
}

},
"domain/context-engine.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProtectedContextTooLongError = void 0;
exports.pathToConversationNode = pathToConversationNode;
exports.providerContentForMessage = providerContentForMessage;
exports.estimateTextTokens = estimateTextTokens;
exports.estimateProviderMessagesTokens = estimateProviderMessagesTokens;
exports.splitMarkdownBlocks = splitMarkdownBlocks;
exports.trimLongFencedCode = trimLongFencedCode;
exports.trimAssistantMarkdown = trimAssistantMarkdown;
exports.compileContextPlan = compileContextPlan;
exports.cacheKeyForContextPlan = cacheKeyForContextPlan;
const balanced_freeze_v3_1 = require("./balanced-freeze-v3");
const balanced_markdown_compressor_1 = require("./balanced-markdown-compressor");
const types_1 = require("./types");
const note_snapshot_1 = require("./note-snapshot");
class ProtectedContextTooLongError extends Error {
    constructor() {
        super("受保护上下文过长，无法在不删除用户问题或引用原文的情况下发送");
        this.name = "ProtectedContextTooLongError";
    }
}
exports.ProtectedContextTooLongError = ProtectedContextTooLongError;
const OMITTED_CODE_MARKER = "TreeTalk 为控制上下文长度省略了未引用代码";
function requiredNode(conversation, nodeId) {
    const node = conversation.nodes[nodeId];
    if (node === undefined)
        throw new Error(`Node not found: ${nodeId}`);
    return node;
}
function pathToConversationNode(conversation, nodeId) {
    const reversed = [];
    const seen = new Set();
    let current = requiredNode(conversation, nodeId);
    while (current !== undefined) {
        if (seen.has(current.id))
            throw new Error("Conversation path contains a cycle");
        seen.add(current.id);
        reversed.push(current);
        current =
            current.parentId === null
                ? undefined
                : requiredNode(conversation, current.parentId);
    }
    return reversed.reverse();
}
function noteSnapshotKey(context) {
    const snapshot = context.snapshot;
    return snapshot === undefined
        ? undefined
        : `${context.filePath}\u0000${snapshot.contentHash}`;
}
function collectNoteSnapshotDescriptors(flattened) {
    const descriptors = new Map();
    for (const entry of flattened) {
        for (const context of entry.message.selectionContexts ?? []) {
            if (!(0, types_1.isNoteSelectionContext)(context) || context.snapshot === undefined) {
                continue;
            }
            const key = noteSnapshotKey(context);
            if (key === undefined)
                continue;
            const existing = descriptors.get(key);
            if (existing === undefined) {
                descriptors.set(key, {
                    key,
                    filePath: context.filePath,
                    fileName: context.fileName,
                    snapshot: structuredClone(context.snapshot)
                });
                continue;
            }
            existing.snapshot.selectionStartOffset = Math.min(existing.snapshot.selectionStartOffset, context.snapshot.selectionStartOffset);
            existing.snapshot.selectionEndOffset = Math.max(existing.snapshot.selectionEndOffset, context.snapshot.selectionEndOffset);
        }
    }
    return descriptors;
}
function noteNamesFromDescriptors(descriptors) {
    const names = [];
    for (const descriptor of descriptors.values()) {
        const filePath = descriptor.filePath.trim();
        if (filePath.length === 0)
            continue;
        const name = filePath.split(/[\\/]/u).at(-1)?.trim();
        if (name !== undefined && name.length > 0)
            names.push(name);
    }
    return names;
}
function noteRenderingState(descriptors, budgets, suppressBackgrounds = false) {
    return {
        descriptors,
        seen: new Set(),
        ...(budgets === undefined ? {} : { budgets }),
        suppressBackgrounds,
        originalEstimatedTokens: 0,
        sentEstimatedTokens: 0,
        trimmed: false
    };
}
function noteBackgroundBlock(descriptor, content) {
    return [
        "[TreeTalk 笔记背景]",
        `笔记标题：${descriptor.fileName}`,
        `笔记路径：${descriptor.filePath}`,
        "以下是本轮框选所在笔记的正文快照：",
        "---",
        content,
        "---",
        "[笔记背景结束]"
    ].join("\n");
}
function noteFocusBlock(context) {
    return [
        "[TreeTalk 框选重点]",
        `来源：${context.filePath}`,
        "---",
        context.quote,
        "---",
        "[框选重点结束]"
    ].join("\n");
}
function genericSelectionBlock(quote, index) {
    return [
        `[TreeTalk 引用上下文 ${String(index)}]`,
        "以下内容仅作为回答参考：",
        "---",
        quote,
        "---",
        "[引用上下文结束]"
    ].join("\n");
}
function providerContentForMessage(message, state) {
    const contexts = message.selectionContexts ?? [];
    if (contexts.length === 0)
        return message.content;
    const localState = state ??
        noteRenderingState(collectNoteSnapshotDescriptors([
            { nodeId: "", message, roundIndex: 0 }
        ]));
    const rendered = [];
    let genericIndex = 0;
    for (const context of contexts) {
        if ((0, types_1.isNoteSelectionContext)(context)) {
            const key = noteSnapshotKey(context);
            if (key !== undefined &&
                !localState.seen.has(key) &&
                !localState.suppressBackgrounds) {
                localState.seen.add(key);
                const descriptor = localState.descriptors.get(key);
                if (descriptor !== undefined) {
                    const budget = localState.budgets?.get(key) ??
                        (0, note_snapshot_1.estimateNoteTextTokens)(descriptor.snapshot.content);
                    const result = (0, note_snapshot_1.renderNoteSnapshot)(descriptor.snapshot, budget);
                    localState.originalEstimatedTokens += result.originalEstimatedTokens;
                    localState.sentEstimatedTokens += result.sentEstimatedTokens;
                    localState.trimmed ||= result.trimmed;
                    rendered.push(noteBackgroundBlock(descriptor, result.content));
                }
            }
            else if (key !== undefined) {
                localState.seen.add(key);
            }
            rendered.push(noteFocusBlock(context));
            continue;
        }
        genericIndex += 1;
        rendered.push(genericSelectionBlock(context.quote, genericIndex));
    }
    return `${rendered.join("\n\n")}\n\n[当前问题]\n${message.content}`;
}
function estimateTextTokens(text) {
    let weighted = 0;
    for (const character of text) {
        if (/\s/u.test(character))
            continue;
        if (/\p{Script=Han}|\p{Script=Hiragana}|\p{Script=Katakana}|\p{Extended_Pictographic}/u.test(character)) {
            weighted += 1;
        }
        else if (/[^\x00-\x7F]/u.test(character)) {
            weighted += 0.6;
        }
        else {
            weighted += 0.25;
        }
    }
    return Math.max(1, Math.ceil(weighted));
}
function estimateProviderMessagesTokens(messages) {
    return messages.reduce((total, message) => total + estimateTextTokens(message.content) + 4, 2);
}
function flattenPath(conversation, nodeId) {
    const path = pathToConversationNode(conversation, nodeId);
    const output = [];
    let roundIndex = -1;
    for (const node of path) {
        for (const message of node.messages) {
            if (message.role === "user")
                roundIndex += 1;
            output.push({ nodeId: node.id, message, roundIndex: Math.max(0, roundIndex) });
        }
    }
    return output;
}
function providerMessages(flattened, systemPrompt, noteBudgets, suppressNoteBackgrounds = false) {
    const messages = [];
    if (systemPrompt.length > 0) {
        messages.push({ role: "system", content: systemPrompt });
    }
    const state = noteRenderingState(collectNoteSnapshotDescriptors(flattened), noteBudgets, suppressNoteBackgrounds);
    for (const entry of flattened) {
        messages.push({
            role: entry.message.role,
            content: providerContentForMessage(entry.message, state)
        });
    }
    return {
        messages,
        noteContextOriginalEstimatedTokens: state.originalEstimatedTokens,
        noteContextSentEstimatedTokens: state.sentEstimatedTokens,
        noteContextTrimmed: state.trimmed
    };
}
function allocateNoteBudgets(descriptors, fullBuild, baseBuild, maxInputTokens) {
    if (descriptors.size === 0 ||
        estimateProviderMessagesTokens(fullBuild.messages) <= maxInputTokens) {
        return undefined;
    }
    const entries = [...descriptors.values()];
    const originals = entries.map((entry) => (0, note_snapshot_1.estimateNoteTextTokens)(entry.snapshot.content));
    const totalOriginal = originals.reduce((total, value) => total + value, 0);
    const baseTokens = estimateProviderMessagesTokens(baseBuild.messages);
    const minimumPerSnapshot = 128;
    const available = Math.max(minimumPerSnapshot * entries.length, maxInputTokens - baseTokens - 48 * entries.length);
    if (available >= totalOriginal)
        return undefined;
    const remaining = Math.max(0, available - minimumPerSnapshot * entries.length);
    const budgets = new Map();
    entries.forEach((entry, index) => {
        const original = originals[index] ?? minimumPerSnapshot;
        const proportional = totalOriginal === 0
            ? 0
            : Math.floor((remaining * original) / totalOriginal);
        budgets.set(entry.key, Math.min(original, minimumPerSnapshot + proportional));
    });
    return budgets;
}
function isFenceStart(line) {
    const match = line.match(/^\s*(`{3,}|~{3,})(.*)$/u);
    if (match === null)
        return undefined;
    return { marker: match[1] ?? "```", info: (match[2] ?? "").trim() };
}
function scoreBlock(kind, content, index, total) {
    let score = 25;
    if (kind === "code" || kind === "math")
        score = 90;
    else if (kind === "table")
        score = 75;
    else if (kind === "heading")
        score = 68;
    else if (kind === "list")
        score = 55;
    else if (kind === "quote")
        score = 52;
    if (/必须|不要|禁止|约束|结论|总结|定义|错误|原因|关键|注意|因此|所以|接口|签名/iu.test(content)) {
        score += 20;
    }
    if (index === 0)
        score += 28;
    if (index === total - 1)
        score += 24;
    return score;
}
function classifyPlainBlock(content) {
    const lines = content.split("\n");
    if (lines.every((line) => /^\s{0,3}#{1,6}\s+/u.test(line)))
        return "heading";
    if (lines.every((line) => /^\s*(?:[-*+] |\d+[.)]\s+)/u.test(line)))
        return "list";
    if (lines.every((line) => /^\s*>/u.test(line)))
        return "quote";
    if (lines.length >= 2 &&
        lines.some((line) => line.includes("|")) &&
        lines.some((line) => /^\s*\|?\s*:?-{3,}/u.test(line))) {
        return "table";
    }
    if (lines.length === 1 && /^\s{0,3}#{1,6}\s+/u.test(lines[0] ?? "")) {
        return "heading";
    }
    if (lines.some((line) => /^\s*(?:[-*+] |\d+[.)]\s+)/u.test(line)))
        return "list";
    if (lines.some((line) => /^\s*>/u.test(line)))
        return "quote";
    return "paragraph";
}
function splitMarkdownBlocks(markdown) {
    const lines = markdown.replace(/\r\n?/gu, "\n").split("\n");
    const raw = [];
    let paragraph = [];
    const flushParagraph = () => {
        if (paragraph.length === 0)
            return;
        const content = paragraph.join("\n").trim();
        paragraph = [];
        if (content.length > 0)
            raw.push({ kind: classifyPlainBlock(content), content });
    };
    let index = 0;
    while (index < lines.length) {
        const line = lines[index] ?? "";
        const fence = isFenceStart(line);
        if (fence !== undefined) {
            flushParagraph();
            const block = [line];
            index += 1;
            while (index < lines.length) {
                const next = lines[index] ?? "";
                block.push(next);
                index += 1;
                if (new RegExp(`^\\s*${fence.marker[0]}{${String(fence.marker.length)},}\\s*$`, "u").test(next)) {
                    break;
                }
            }
            if (block.length === 1 || !new RegExp(`^\\s*${fence.marker[0]}{${String(fence.marker.length)},}\\s*$`, "u").test(block.at(-1) ?? "")) {
                block.push(fence.marker);
            }
            raw.push({ kind: "code", content: block.join("\n") });
            continue;
        }
        if (/^\s*\$\$\s*$/u.test(line)) {
            flushParagraph();
            const block = [line];
            index += 1;
            while (index < lines.length) {
                const next = lines[index] ?? "";
                block.push(next);
                index += 1;
                if (/^\s*\$\$\s*$/u.test(next))
                    break;
            }
            if (block.length === 1 || !/^\s*\$\$\s*$/u.test(block.at(-1) ?? "")) {
                block.push("$$");
            }
            raw.push({ kind: "math", content: block.join("\n") });
            continue;
        }
        if (line.trim().length === 0) {
            flushParagraph();
            index += 1;
            continue;
        }
        paragraph.push(line);
        index += 1;
    }
    flushParagraph();
    return raw.map((block, blockIndex) => ({
        ...block,
        index: blockIndex,
        score: scoreBlock(block.kind, block.content, blockIndex, raw.length),
        tokens: estimateTextTokens(block.content)
    }));
}
function omissionComment(language) {
    const normalized = language.toLowerCase();
    if (/^(?:py|python|sh|bash|zsh|fish|yaml|yml|toml|r|ruby|perl)$/u.test(normalized)) {
        return `# ……${OMITTED_CODE_MARKER}……`;
    }
    if (/^(?:html|xml|svg|md|markdown)$/u.test(normalized)) {
        return `<!-- ……${OMITTED_CODE_MARKER}…… -->`;
    }
    return `// ……${OMITTED_CODE_MARKER}……`;
}
function looksLikeCodeSignature(line) {
    return /^\s*(?:import|export|from|require|#include|using|package|class|interface|type|enum|struct|def|fn|func|function|public|private|protected|static|async|const\s+\w+\s*=\s*\(|let\s+\w+\s*=\s*\().*/u.test(line);
}
function trimLongFencedCode(markdown, maxTokens) {
    if (estimateTextTokens(markdown) <= maxTokens)
        return markdown;
    const lines = markdown.split("\n");
    const opening = lines[0] ?? "```";
    const closing = lines.at(-1)?.match(/^\s*(`{3,}|~{3,})\s*$/u)?.[0] ?? "```";
    const language = opening.replace(/^\s*(`{3,}|~{3,})/u, "").trim();
    const body = lines.slice(1, -1);
    const keep = new Set();
    for (let index = 0; index < Math.min(14, body.length); index += 1)
        keep.add(index);
    for (let index = Math.max(0, body.length - 10); index < body.length; index += 1)
        keep.add(index);
    for (const [index, line] of body.entries()) {
        if (looksLikeCodeSignature(line))
            keep.add(index);
        if (keep.size >= 48)
            break;
    }
    const ordered = [...keep].sort((left, right) => left - right);
    const compact = [opening];
    let previous = -1;
    for (const lineIndex of ordered) {
        if (previous >= 0 && lineIndex > previous + 1) {
            compact.push(omissionComment(language));
        }
        compact.push(body[lineIndex] ?? "");
        previous = lineIndex;
    }
    compact.push(closing);
    let result = compact.join("\n");
    if (estimateTextTokens(result) <= maxTokens)
        return result;
    const head = body.slice(0, 8);
    const tail = body.slice(-6);
    result = [opening, ...head, omissionComment(language), ...tail, closing].join("\n");
    return result;
}
function trimAssistantMarkdown(markdown, maxTokens) {
    if (estimateTextTokens(markdown) <= maxTokens)
        return markdown;
    const blocks = splitMarkdownBlocks(markdown);
    if (blocks.length === 0)
        return markdown;
    const selected = new Map();
    let used = 0;
    const ranked = [...blocks].sort((left, right) => right.score - left.score || left.index - right.index);
    for (const block of ranked) {
        let content = block.content;
        let tokens = block.tokens;
        if (block.kind === "code" && tokens > Math.max(180, Math.floor(maxTokens * 0.45))) {
            content = trimLongFencedCode(content, Math.max(180, Math.floor(maxTokens * 0.45)));
            tokens = estimateTextTokens(content);
        }
        if (used + tokens > maxTokens && selected.size > 0)
            continue;
        selected.set(block.index, content);
        used += tokens;
        if (used >= maxTokens)
            break;
    }
    if (selected.size === 0) {
        const first = blocks[0];
        if (first === undefined)
            return markdown;
        return first.kind === "code"
            ? trimLongFencedCode(first.content, maxTokens)
            : first.content;
    }
    return [...selected.entries()]
        .sort(([left], [right]) => left - right)
        .map(([, content]) => content)
        .join("\n\n");
}
function fnv1a(value) {
    let hash = 0x811c9dc5;
    for (let index = 0; index < value.length; index += 1) {
        hash ^= value.charCodeAt(index);
        hash = Math.imul(hash, 0x01000193);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
}
function stablePrefixHash(messages) {
    const stable = messages.slice(0, Math.max(0, messages.length - 1));
    return fnv1a(stable.map((message) => `${message.role}\u0000${message.content}`).join("\u0001"));
}
function sourceMessageKey(nodeId, messageId) {
    return `${nodeId}\u0000${messageId}`;
}
function recentCompletedRoundIndexes(flattened) {
    const completed = [...new Set(flattened
            .filter((entry) => entry.message.role === "assistant" &&
            entry.message.status === "complete")
            .map((entry) => entry.roundIndex))].sort((left, right) => left - right);
    return new Set(completed.slice(-2));
}
function sourceMessageProtections(flattened) {
    const sourceMessages = new Map();
    for (const entry of flattened) {
        if (entry.message.role !== "assistant")
            continue;
        sourceMessages.set(sourceMessageKey(entry.nodeId, entry.message.id), entry);
    }
    const protections = new Map();
    for (const entry of flattened) {
        if (entry.message.role !== "user")
            continue;
        for (const context of entry.message.selectionContexts ?? []) {
            if (!(0, types_1.isMessageSelectionContext)(context) ||
                context.sourceRole !== "assistant") {
                continue;
            }
            const key = sourceMessageKey(context.sourceNodeId, context.messageId);
            const source = sourceMessages.get(key);
            if (source === undefined)
                continue;
            const protection = protections.get(key) ?? { ranges: [], unresolved: false };
            const resolved = (0, balanced_markdown_compressor_1.resolveSelectionInMarkdown)(source.message.content, context);
            if (resolved.status === "unresolved") {
                protection.unresolved = true;
            }
            else {
                protection.ranges.push({ start: resolved.start, end: resolved.end });
            }
            protections.set(key, protection);
        }
    }
    return protections;
}
function isCompressibleOldAssistant(entry, recentCompletedRounds, protections) {
    if (entry.message.role !== "assistant" ||
        entry.message.status !== "complete" ||
        recentCompletedRounds.has(entry.roundIndex)) {
        return false;
    }
    return protections.get(sourceMessageKey(entry.nodeId, entry.message.id))?.unresolved !== true;
}
function balancedProviderMessages(flattened, systemPrompt, recentCompletedRounds, protections, compression, noteBudgets, suppressNoteBackgrounds = false) {
    const messages = [];
    if (systemPrompt.length > 0)
        messages.push({ role: "system", content: systemPrompt });
    const state = noteRenderingState(collectNoteSnapshotDescriptors(flattened), noteBudgets, suppressNoteBackgrounds);
    for (const entry of flattened) {
        const original = providerContentForMessage(entry.message, state);
        if (!isCompressibleOldAssistant(entry, recentCompletedRounds, protections)) {
            messages.push({ role: entry.message.role, content: original });
            continue;
        }
        const protection = protections.get(sourceMessageKey(entry.nodeId, entry.message.id));
        const result = (0, balanced_markdown_compressor_1.compressAssistantMarkdown)(entry.message.content, {
            protectedRanges: protection?.ranges ?? [],
            targetRatio: compression.targetRatio,
            ...(compression.maxTokensPerOldAssistant === undefined
                ? {}
                : { maxTokens: compression.maxTokensPerOldAssistant })
        });
        messages.push({ role: entry.message.role, content: result.content });
    }
    return {
        messages,
        noteContextOriginalEstimatedTokens: state.originalEstimatedTokens,
        noteContextSentEstimatedTokens: state.sentEstimatedTokens,
        noteContextTrimmed: state.trimmed
    };
}
function hardBudgetBalancedMessages(flattened, systemPrompt, recentCompletedRounds, protections, maxInputTokens, noteBudgets) {
    const compressible = flattened.filter((entry) => isCompressibleOldAssistant(entry, recentCompletedRounds, protections));
    if (compressible.length === 0) {
        return balancedProviderMessages(flattened, systemPrompt, recentCompletedRounds, protections, { targetRatio: 0.35 }, noteBudgets);
    }
    const reserved = providerMessages(flattened.filter((entry) => !isCompressibleOldAssistant(entry, recentCompletedRounds, protections)), systemPrompt, noteBudgets);
    const reservedTokens = estimateProviderMessagesTokens(reserved.messages);
    const availableForOldAssistants = Math.max(96 * compressible.length, maxInputTokens - reservedTokens);
    const maxTokensPerOldAssistant = Math.max(96, Math.floor(availableForOldAssistants / compressible.length) - 4);
    return balancedProviderMessages(flattened, systemPrompt, recentCompletedRounds, protections, { targetRatio: 0.35, maxTokensPerOldAssistant }, noteBudgets);
}
function balancedV3NoteDescriptors(flattened) {
    const descriptors = new Map();
    for (const entry of flattened) {
        const firstMessageGroups = new Map();
        for (const context of entry.message.selectionContexts ?? []) {
            if (!(0, types_1.isNoteSelectionContext)(context) || context.snapshot === undefined) {
                continue;
            }
            const key = noteSnapshotKey(context);
            if (key === undefined || descriptors.has(key))
                continue;
            const existing = firstMessageGroups.get(key);
            if (existing === undefined) {
                firstMessageGroups.set(key, {
                    context,
                    selectionStartOffset: context.snapshot.selectionStartOffset,
                    selectionEndOffset: context.snapshot.selectionEndOffset
                });
            }
            else {
                existing.selectionStartOffset = Math.min(existing.selectionStartOffset, context.snapshot.selectionStartOffset);
                existing.selectionEndOffset = Math.max(existing.selectionEndOffset, context.snapshot.selectionEndOffset);
            }
        }
        for (const [key, group] of firstMessageGroups) {
            const snapshot = structuredClone(group.context.snapshot);
            if (snapshot === undefined)
                continue;
            snapshot.selectionStartOffset = group.selectionStartOffset;
            snapshot.selectionEndOffset = group.selectionEndOffset;
            descriptors.set(key, {
                key,
                filePath: group.context.filePath,
                fileName: group.context.fileName,
                snapshot,
                firstMessageId: entry.message.id
            });
        }
    }
    return descriptors;
}
function latestCompletedRoundIndexesV3(flattened) {
    const completed = [...new Set(flattened
            .filter((entry) => entry.message.role === "assistant" &&
            entry.message.status === "complete")
            .map((entry) => entry.roundIndex))].sort((left, right) => left - right);
    const latest = completed.at(-1);
    return latest === undefined ? new Set() : new Set([latest]);
}
function currentUserEntry(flattened) {
    return [...flattened].reverse().find((entry) => entry.message.role === "user");
}
function priorBalancedState(flattened, currentUser) {
    if (currentUser.message.balancedContextState?.protocol === balanced_freeze_v3_1.BALANCED_V3_PROTOCOL) {
        return currentUser.message.balancedContextState;
    }
    const currentIndex = flattened.indexOf(currentUser);
    for (let index = currentIndex - 1; index >= 0; index -= 1) {
        const state = flattened[index]?.message.balancedContextState;
        if (state?.protocol === balanced_freeze_v3_1.BALANCED_V3_PROTOCOL)
            return state;
    }
    return undefined;
}
function artifactCompatible(artifact, input) {
    return (artifact.protocol === balanced_freeze_v3_1.BALANCED_V3_PROTOCOL &&
        artifact.sourceType === input.sourceType &&
        artifact.sourceIdentity === input.sourceIdentity &&
        artifact.sourceContentHash === input.sourceContentHash &&
        artifact.tier === input.tier);
}
function artifactFromCandidateKeys(context, input) {
    for (const key of context.candidateKeys) {
        const artifact = context.library[key];
        if (artifact !== undefined && artifactCompatible(artifact, input)) {
            return artifact;
        }
    }
    return undefined;
}
function sameArtifact(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
}
function registerArtifact(context, artifact) {
    const existing = context.library[artifact.key] ?? context.newArtifacts.get(artifact.key);
    if (existing === undefined) {
        context.newArtifacts.set(artifact.key, artifact);
        return artifact;
    }
    if (sameArtifact(existing, artifact))
        return existing;
    const repaired = {
        ...artifact,
        key: `${artifact.key}-repair-${(0, balanced_freeze_v3_1.balancedV3TextHash)(JSON.stringify(artifact))}`
    };
    const repairedExisting = context.library[repaired.key] ?? context.newArtifacts.get(repaired.key);
    if (repairedExisting !== undefined && !sameArtifact(repairedExisting, repaired)) {
        throw new Error(`Balanced context artifact conflict: ${repaired.key}`);
    }
    if (repairedExisting === undefined)
        context.newArtifacts.set(repaired.key, repaired);
    return repairedExisting ?? repaired;
}
function recordArtifactKey(context, artifact, recovery = false) {
    if (!context.artifactKeys.includes(artifact.key)) {
        context.artifactKeys.push(artifact.key);
    }
    if (recovery && !context.recoveryPatchKeys.includes(artifact.key)) {
        context.recoveryPatchKeys.push(artifact.key);
    }
}
function resolvedAssistantArtifact(context, entry, protection, tier) {
    const sourceIdentity = sourceMessageKey(entry.nodeId, entry.message.id);
    const sourceContentHash = (0, balanced_freeze_v3_1.balancedV3TextHash)(entry.message.content);
    const existing = artifactFromCandidateKeys(context, {
        sourceType: "assistant-message",
        sourceIdentity,
        sourceContentHash,
        tier
    });
    if (existing !== undefined)
        return existing;
    const built = (0, balanced_freeze_v3_1.buildAssistantFreezeArtifact)({
        sourceIdentity,
        sourceContentHash,
        content: entry.message.content,
        protectedRanges: protection?.ranges ?? [],
        tier
    });
    return built === undefined ? undefined : registerArtifact(context, built);
}
function resolvedNoteArtifact(context, descriptor, tier) {
    const sourceIdentity = descriptor.key;
    const sourceContentHash = descriptor.snapshot.contentHash;
    const existing = artifactFromCandidateKeys(context, {
        sourceType: "note-snapshot",
        sourceIdentity,
        sourceContentHash,
        tier
    });
    if (existing !== undefined)
        return existing;
    const built = (0, balanced_freeze_v3_1.buildNoteFreezeArtifact)({
        sourceIdentity,
        sourceContentHash,
        snapshot: descriptor.snapshot,
        tier
    });
    return built === undefined ? undefined : registerArtifact(context, built);
}
function sourceMessagesByKey(flattened) {
    const output = new Map();
    for (const entry of flattened) {
        output.set(sourceMessageKey(entry.nodeId, entry.message.id), entry);
    }
    return output;
}
function resolvedRecoveryArtifact(artifactContext, selection, sources) {
    if ((0, types_1.isNoteSelectionContext)(selection)) {
        const snapshot = selection.snapshot;
        const sourceContent = snapshot?.content ?? selection.quote;
        const sourceIdentity = snapshot === undefined
            ? `${selection.filePath}\u0000${selection.contentHash}`
            : `${selection.filePath}\u0000${snapshot.contentHash}`;
        const sourceContentHash = snapshot?.contentHash ?? (0, balanced_freeze_v3_1.balancedV3TextHash)(sourceContent);
        const existing = artifactFromCandidateKeys(artifactContext, {
            sourceType: "recovery-patch",
            sourceIdentity,
            sourceContentHash,
            tier: "standard"
        });
        const built = (0, balanced_freeze_v3_1.buildRecoveryPatchArtifact)({
            sourceIdentity,
            sourceContentHash,
            sourceLabel: selection.filePath,
            sourceContent,
            startOffset: snapshot?.selectionStartOffset ?? 0,
            endOffset: snapshot?.selectionEndOffset ?? selection.quote.length,
            quote: selection.quote
        });
        if (existing !== undefined && existing.key === built.key)
            return existing;
        return registerArtifact(artifactContext, built);
    }
    const sourceIdentity = sourceMessageKey(selection.sourceNodeId, selection.messageId);
    const source = sources.get(sourceIdentity);
    const sourceContent = source?.message.content ?? selection.quote;
    const sourceContentHash = (0, balanced_freeze_v3_1.balancedV3TextHash)(sourceContent);
    const resolved = source === undefined
        ? { status: "unresolved", quote: selection.quote }
        : (0, balanced_markdown_compressor_1.resolveSelectionInMarkdown)(sourceContent, selection);
    const startOffset = resolved.status === "resolved" ? resolved.start : Math.max(0, selection.startOffset);
    const endOffset = resolved.status === "resolved"
        ? resolved.end
        : Math.max(startOffset, selection.endOffset);
    const built = (0, balanced_freeze_v3_1.buildRecoveryPatchArtifact)({
        sourceIdentity,
        sourceContentHash,
        sourceLabel: `节点 ${selection.sourceNodeId}`,
        sourceContent,
        startOffset,
        endOffset,
        quote: selection.quote
    });
    const existing = artifactContext.library[built.key];
    if (existing !== undefined && artifactCompatible(existing, {
        sourceType: "recovery-patch",
        sourceIdentity,
        sourceContentHash,
        tier: "standard"
    })) {
        return existing;
    }
    return registerArtifact(artifactContext, built);
}
function balancedV3UserContent(entry, artifactContext, noteDescriptors, seenNotes, seenRecovery, sources, compactSources, noteStats) {
    const contexts = entry.message.selectionContexts ?? [];
    if (contexts.length === 0)
        return entry.message.content;
    const rendered = [];
    for (const selection of contexts) {
        if ((0, types_1.isNoteSelectionContext)(selection)) {
            const key = noteSnapshotKey(selection);
            if (key !== undefined && !seenNotes.has(key)) {
                seenNotes.add(key);
                const descriptor = noteDescriptors.get(key);
                if (descriptor !== undefined) {
                    const tier = compactSources.has(descriptor.key) ? "compact" : "standard";
                    const artifact = resolvedNoteArtifact(artifactContext, descriptor, tier);
                    const original = (0, note_snapshot_1.estimateNoteTextTokens)(descriptor.snapshot.content);
                    const content = artifact?.content ?? descriptor.snapshot.content;
                    const sent = (0, note_snapshot_1.estimateNoteTextTokens)(content);
                    noteStats.original += original;
                    noteStats.sent += sent;
                    noteStats.trimmed ||= artifact !== undefined;
                    if (artifact !== undefined)
                        recordArtifactKey(artifactContext, artifact);
                    rendered.push(noteBackgroundBlock(descriptor, content));
                }
            }
        }
        const recovery = resolvedRecoveryArtifact(artifactContext, selection, sources);
        if (recovery !== undefined && !seenRecovery.has(recovery.key)) {
            seenRecovery.add(recovery.key);
            recordArtifactKey(artifactContext, recovery, true);
            rendered.push(recovery.content);
        }
    }
    return `${rendered.join("\n\n")}\n\n[当前问题]\n${entry.message.content}`;
}
function balancedV3ProviderMessages(conversation, flattened, systemPrompt, compactSources, candidateKeys) {
    const library = conversation.contextArtifacts?.balancedV3 ?? {};
    const artifactContext = {
        library,
        candidateKeys,
        newArtifacts: new Map(),
        artifactKeys: [],
        recoveryPatchKeys: []
    };
    const recentRounds = latestCompletedRoundIndexesV3(flattened);
    const protections = sourceMessageProtections(flattened);
    const notes = balancedV3NoteDescriptors(flattened);
    const sources = sourceMessagesByKey(flattened);
    const seenNotes = new Set();
    const seenRecovery = new Set();
    const noteStats = { original: 0, sent: 0, trimmed: false };
    const messages = [];
    if (systemPrompt.length > 0)
        messages.push({ role: "system", content: systemPrompt });
    for (const entry of flattened) {
        if (entry.message.role === "user") {
            messages.push({
                role: "user",
                content: balancedV3UserContent(entry, artifactContext, notes, seenNotes, seenRecovery, sources, compactSources, noteStats)
            });
            continue;
        }
        if (entry.message.status !== "complete" ||
            recentRounds.has(entry.roundIndex)) {
            messages.push({ role: "assistant", content: entry.message.content });
            continue;
        }
        const sourceIdentity = sourceMessageKey(entry.nodeId, entry.message.id);
        const tier = compactSources.has(sourceIdentity) ? "compact" : "standard";
        const artifact = resolvedAssistantArtifact(artifactContext, entry, protections.get(sourceIdentity), tier);
        if (artifact !== undefined)
            recordArtifactKey(artifactContext, artifact);
        messages.push({
            role: "assistant",
            content: artifact?.content ?? entry.message.content
        });
    }
    return {
        messages,
        noteContextOriginalEstimatedTokens: noteStats.original,
        noteContextSentEstimatedTokens: noteStats.sent,
        noteContextTrimmed: noteStats.trimmed,
        artifactKeys: artifactContext.artifactKeys,
        recoveryPatchKeys: artifactContext.recoveryPatchKeys,
        newArtifacts: [...artifactContext.newArtifacts.values()]
    };
}
function stateEquals(left, right) {
    return left !== undefined && JSON.stringify(left) === JSON.stringify(right);
}
function compactCandidateIdentities(flattened) {
    const recentRounds = latestCompletedRoundIndexesV3(flattened);
    const candidates = [];
    for (const entry of flattened) {
        if (entry.message.role === "assistant" &&
            entry.message.status === "complete" &&
            !recentRounds.has(entry.roundIndex)) {
            candidates.push(sourceMessageKey(entry.nodeId, entry.message.id));
        }
    }
    for (const descriptor of balancedV3NoteDescriptors(flattened).values()) {
        candidates.push(descriptor.key);
    }
    return [...new Set(candidates)];
}
function conversationWithArtifacts(conversation, artifacts) {
    if (artifacts.size === 0)
        return conversation;
    const next = structuredClone(conversation);
    next.contextArtifacts = {
        balancedV3: {
            ...(conversation.contextArtifacts?.balancedV3 ?? {}),
            ...Object.fromEntries(artifacts)
        }
    };
    return next;
}
function compileBalancedV3(conversation, flattened, systemPrompt, maxInputTokens, fullBuild, fullEstimatedTokens, referencedNoteNames) {
    const currentUser = currentUserEntry(flattened);
    if (currentUser === undefined) {
        throw new Error("Balanced context requires a current user message");
    }
    const inherited = priorBalancedState(flattened, currentUser);
    const compactSources = new Set(inherited?.compactSourceIdentities ?? []);
    const accumulatedArtifacts = new Map();
    let workingConversation = conversation;
    let build = balancedV3ProviderMessages(workingConversation, flattened, systemPrompt, compactSources, inherited?.artifactKeys ?? []);
    for (const artifact of build.newArtifacts) {
        accumulatedArtifacts.set(artifact.key, artifact);
    }
    const candidates = compactCandidateIdentities(flattened);
    let sentEstimatedTokens = estimateProviderMessagesTokens(build.messages);
    while (sentEstimatedTokens > maxInputTokens) {
        const nextCandidate = candidates.find((identity) => !compactSources.has(identity));
        if (nextCandidate === undefined)
            throw new ProtectedContextTooLongError();
        compactSources.add(nextCandidate);
        workingConversation = conversationWithArtifacts(conversation, accumulatedArtifacts);
        build = balancedV3ProviderMessages(workingConversation, flattened, systemPrompt, compactSources, [
            ...(inherited?.artifactKeys ?? []),
            ...accumulatedArtifacts.keys()
        ]);
        for (const artifact of build.newArtifacts) {
            accumulatedArtifacts.set(artifact.key, artifact);
        }
        sentEstimatedTokens = estimateProviderMessagesTokens(build.messages);
    }
    const requestState = {
        protocol: balanced_freeze_v3_1.BALANCED_V3_PROTOCOL,
        artifactKeys: [...build.artifactKeys],
        compactSourceIdentities: [...compactSources],
        recoveryPatchKeys: [...build.recoveryPatchKeys]
    };
    const reducedTokens = Math.max(0, fullEstimatedTokens - sentEstimatedTokens);
    const plan = {
        mode: "balanced",
        messages: build.messages,
        fullEstimatedTokens,
        sentEstimatedTokens,
        reducedTokens,
        reductionRatio: fullEstimatedTokens === 0 ? 0 : reducedTokens / fullEstimatedTokens,
        stablePrefixHash: stablePrefixHash(build.messages),
        trimmed: reducedTokens > 0,
        noteContextOriginalEstimatedTokens: fullBuild.noteContextOriginalEstimatedTokens,
        noteContextSentEstimatedTokens: build.noteContextSentEstimatedTokens,
        noteContextTrimmed: build.noteContextTrimmed,
        referencedNoteNames: [...referencedNoteNames]
    };
    if (accumulatedArtifacts.size > 0 ||
        !stateEquals(currentUser.message.balancedContextState, requestState)) {
        plan.persistencePatch = {
            artifacts: [...accumulatedArtifacts.values()],
            currentUserMessageId: currentUser.message.id,
            requestState
        };
    }
    return plan;
}
function compileContextPlan(conversation, nodeId, options) {
    if (!Number.isFinite(options.maxInputTokens) || options.maxInputTokens <= 0) {
        throw new Error("maxInputTokens must be positive");
    }
    const flattened = flattenPath(conversation, nodeId);
    const descriptors = collectNoteSnapshotDescriptors(flattened);
    const referencedNoteNames = noteNamesFromDescriptors(descriptors);
    const fullBuild = providerMessages(flattened, options.systemPrompt);
    const fullEstimatedTokens = estimateProviderMessagesTokens(fullBuild.messages);
    if (options.mode === "full") {
        const baseBuild = providerMessages(flattened, options.systemPrompt, undefined, true);
        const noteBudgets = allocateNoteBudgets(descriptors, fullBuild, baseBuild, options.maxInputTokens);
        const sentBuild = noteBudgets === undefined
            ? fullBuild
            : providerMessages(flattened, options.systemPrompt, noteBudgets);
        const sentEstimatedTokens = estimateProviderMessagesTokens(sentBuild.messages);
        const reducedTokens = Math.max(0, fullEstimatedTokens - sentEstimatedTokens);
        return {
            mode: "full",
            messages: sentBuild.messages,
            fullEstimatedTokens,
            sentEstimatedTokens,
            reducedTokens,
            reductionRatio: fullEstimatedTokens === 0 ? 0 : reducedTokens / fullEstimatedTokens,
            stablePrefixHash: stablePrefixHash(sentBuild.messages),
            trimmed: sentBuild.noteContextTrimmed,
            noteContextOriginalEstimatedTokens: fullBuild.noteContextOriginalEstimatedTokens,
            noteContextSentEstimatedTokens: sentBuild.noteContextSentEstimatedTokens,
            noteContextTrimmed: sentBuild.noteContextTrimmed,
            referencedNoteNames: [...referencedNoteNames]
        };
    }
    return compileBalancedV3(conversation, flattened, options.systemPrompt, options.maxInputTokens, fullBuild, fullEstimatedTokens, referencedNoteNames);
}
function cacheKeyForContextPlan(conversationId, plan) {
    return plan.mode === "balanced"
        ? `treetalk:${conversationId}:balanced:v3`
        : `treetalk:${conversationId}:full:v1`;
}

},
"domain/context-persistence.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyContextPlanPersistencePatch = applyContextPlanPersistencePatch;
const schema_1 = require("./schema");
function artifactEquals(left, right) {
    return JSON.stringify(left) === JSON.stringify(right);
}
function applyContextPlanPersistencePatch(conversation, patch, now) {
    const next = structuredClone(conversation);
    const balancedV3 = {
        ...(next.contextArtifacts?.balancedV3 ?? {})
    };
    for (const artifact of patch.artifacts) {
        const existing = balancedV3[artifact.key];
        if (existing !== undefined && !artifactEquals(existing, artifact)) {
            throw new Error(`Balanced context artifact conflict: ${artifact.key}`);
        }
        if (existing === undefined)
            balancedV3[artifact.key] = structuredClone(artifact);
    }
    let targetMessage;
    let targetNode;
    for (const node of Object.values(next.nodes)) {
        const message = node.messages.find((entry) => entry.id === patch.currentUserMessageId && entry.role === "user");
        if (message !== undefined) {
            targetMessage = message;
            targetNode = node;
            break;
        }
    }
    if (targetMessage === undefined || targetNode === undefined) {
        throw new Error(`Balanced context user message not found: ${patch.currentUserMessageId}`);
    }
    next.contextArtifacts = { balancedV3 };
    targetMessage.balancedContextState = structuredClone(patch.requestState);
    targetMessage.updatedAt = now;
    targetNode.updatedAt = now;
    next.updatedAt = now;
    next.revision += 1;
    return (0, schema_1.parseConversation)(next);
}

},
"domain/conversation-factory.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createConversation = createConversation;
const schema_1 = require("./schema");
function createConversation(title = "新对话") {
    const now = new Date().toISOString();
    const conversationId = crypto.randomUUID();
    const rootNodeId = crypto.randomUUID();
    return (0, schema_1.parseConversation)({
        schemaVersion: 1,
        id: conversationId,
        title,
        status: "active",
        revision: 0,
        checksum: "",
        createdAt: now,
        updatedAt: now,
        rootNodeId,
        currentNodeId: rootNodeId,
        nodes: {
            [rootNodeId]: {
                id: rootNodeId,
                parentId: null,
                childIds: [],
                title,
                titleSource: "question",
                messages: [],
                draft: { text: "", mode: "continue", selectionContexts: [] },
                createdAt: now,
                updatedAt: now
            }
        },
        ui: {
            expandedNodeIds: [rootNodeId],
            treeScrollTop: 0,
            messageScrollTopByNode: {}
        }
    });
}

},
"domain/draft-contexts.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.selectionContextKey = selectionContextKey;
exports.appendDraftContext = appendDraftContext;
exports.removeDraftContext = removeDraftContext;
const types_1 = require("./types");
function selectionContextKey(context) {
    if ((0, types_1.isNoteSelectionContext)(context)) {
        return [
            "note",
            context.filePath,
            context.basis,
            context.startOffset,
            context.endOffset,
            context.quote,
            context.snapshot?.contentHash ?? context.contentHash
        ].join(":");
    }
    return [
        "message",
        context.messageId,
        context.startOffset,
        context.endOffset,
        context.quote
    ].join(":");
}
function appendDraftContext(contexts, context) {
    const key = selectionContextKey(context);
    if (contexts.some((entry) => selectionContextKey(entry) === key)) {
        return [...contexts];
    }
    return [...contexts, structuredClone(context)];
}
function removeDraftContext(contexts, key) {
    return contexts
        .filter((entry) => selectionContextKey(entry) !== key)
        .map((entry) => structuredClone(entry));
}

},
"domain/full-context-protocol.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FULL_CONTEXT_BASE_SYSTEM_PROMPT = exports.FULL_CONTEXT_PROTOCOL_VERSION = void 0;
exports.buildTreeTalkSystemPrompt = buildTreeTalkSystemPrompt;
const markdown_compatibility_1 = require("./markdown-compatibility");
exports.FULL_CONTEXT_PROTOCOL_VERSION = "v1";
exports.FULL_CONTEXT_BASE_SYSTEM_PROMPT = [
    `TreeTalk Full Context Protocol ${exports.FULL_CONTEXT_PROTOCOL_VERSION}`,
    "1. 直接回答当前问题，不要先复述整段问题。",
    "2. 根据回答需要正确使用历史对话和引用上下文，不要忽略与当前问题直接相关的信息。",
    "3. 信息不足时明确说明缺少什么，不要把猜测写成确定事实。",
    "4. 清楚区分已知事实、合理推断和建议。",
    "5. 不向用户展示 TreeTalk 内部标签、上下文边界或编译结构。",
    "6. 当前用户要求与历史要求冲突时，以当前问题中的要求为准。",
    "7. 只输出对用户有用的回答内容，不解释本协议。"
].join("\n");
const OBSIDIAN_MARKDOWN_SECTION_TITLE = "[Obsidian Markdown 格式规则]";
function buildTreeTalkSystemPrompt(markdownCompatibilityEnabled) {
    if (!markdownCompatibilityEnabled)
        return exports.FULL_CONTEXT_BASE_SYSTEM_PROMPT;
    return [
        exports.FULL_CONTEXT_BASE_SYSTEM_PROMPT,
        OBSIDIAN_MARKDOWN_SECTION_TITLE,
        markdown_compatibility_1.OBSIDIAN_MARKDOWN_SYSTEM_PROMPT
    ].join("\n\n");
}

},
"domain/markdown-compatibility.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OBSIDIAN_MARKDOWN_SYSTEM_PROMPT = void 0;
exports.splitStreamingMarkdown = splitStreamingMarkdown;
exports.normalizeObsidianMarkdown = normalizeObsidianMarkdown;
exports.OBSIDIAN_MARKDOWN_SYSTEM_PROMPT = [
    "请使用严格兼容 Obsidian Markdown 的格式输出。",
    "行内公式只使用 $...$，块级公式只使用独立行的 $$...$$。",
    "不要使用 \\(...\\) 或 \\[...\\] 作为公式定界符。",
    "代码块必须使用成对的三反引号围栏，并注明语言时放在起始围栏后。",
    "标题、列表、引用、表格和代码块之间保留必要空行。",
    "表格必须包含表头分隔行。",
    "输出结束前检查所有公式定界符、反引号围栏和 Markdown 链接是否闭合。",
    "只输出回答内容，不解释这些格式要求。"
].join("\n");
function linesWithOffsets(value) {
    const lines = [];
    let start = 0;
    for (let index = 0; index <= value.length; index += 1) {
        if (index !== value.length && value.charAt(index) !== "\n")
            continue;
        const raw = value.slice(start, index);
        const content = raw.endsWith("\r") ? raw.slice(0, -1) : raw;
        const newline = index < value.length ? (raw.endsWith("\r") ? "\r\n" : "\n") : "";
        lines.push({ start, end: index < value.length ? index + 1 : index, content, newline });
        start = index + 1;
    }
    return lines;
}
function fenceRanges(markdown) {
    const ranges = [];
    let open;
    for (const line of linesWithOffsets(markdown)) {
        const match = line.content.match(/^\s*(`{3,}|~{3,})/u);
        if (match === null)
            continue;
        const marker = match[1];
        if (marker === undefined)
            continue;
        const character = marker.charAt(0);
        if (open === undefined) {
            open = { start: line.start, marker, character, length: marker.length };
            continue;
        }
        if (character === open.character && marker.length >= open.length) {
            ranges.push({
                start: open.start,
                end: line.end,
                closed: true,
                marker: open.marker
            });
            open = undefined;
        }
    }
    if (open !== undefined) {
        ranges.push({
            start: open.start,
            end: markdown.length,
            closed: false,
            marker: open.marker
        });
    }
    return ranges;
}
function inRanges(index, ranges) {
    return ranges.some((range) => index >= range.start && index < range.end);
}
function isEscaped(value, index) {
    let slashes = 0;
    for (let cursor = index - 1; cursor >= 0 && value.charAt(cursor) === "\\"; cursor -= 1) {
        slashes += 1;
    }
    return slashes % 2 === 1;
}
function unclosedMathStart(markdown, ranges) {
    let blockStart;
    let inlineStart;
    for (let index = 0; index < markdown.length; index += 1) {
        if (inRanges(index, ranges))
            continue;
        if (markdown.charAt(index) !== "$" || isEscaped(markdown, index))
            continue;
        if (markdown.charAt(index + 1) === "$") {
            if (inlineStart !== undefined)
                continue;
            blockStart = blockStart === undefined ? index : undefined;
            index += 1;
            continue;
        }
        if (blockStart !== undefined)
            continue;
        const previous = markdown.charAt(index - 1);
        const next = markdown.charAt(index + 1);
        if (inlineStart === undefined) {
            if (next.length === 0 || /\s/u.test(next))
                continue;
            inlineStart = index;
        }
        else if (previous.length > 0 && !/\s/u.test(previous)) {
            inlineStart = undefined;
        }
    }
    return blockStart ?? inlineStart;
}
const HTML_BLOCK_TAGS = new Set([
    "article",
    "blockquote",
    "details",
    "div",
    "pre",
    "section",
    "summary",
    "table"
]);
function unclosedHtmlStart(markdown, ranges) {
    const stack = [];
    const pattern = /<\/?([a-z][a-z0-9-]*)\b[^>]*>/giu;
    for (const match of markdown.matchAll(pattern)) {
        const index = match.index;
        if (inRanges(index, ranges))
            continue;
        const raw = match[0];
        const tag = match[1]?.toLowerCase();
        if (tag === undefined || !HTML_BLOCK_TAGS.has(tag) || /\/\s*>$/u.test(raw))
            continue;
        if (raw.startsWith("</")) {
            const position = stack.map((entry) => entry.tag).lastIndexOf(tag);
            if (position >= 0)
                stack.splice(position, 1);
        }
        else {
            stack.push({ tag, start: index });
        }
    }
    return stack[0]?.start;
}
function tableCellCount(line) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("|") || !trimmed.endsWith("|"))
        return 0;
    return trimmed.slice(1, -1).split(/(?<!\\)\|/u).length;
}
function isPipeRow(line) {
    const trimmed = line.trim();
    return trimmed.startsWith("|") && trimmed.endsWith("|") &&
        (trimmed.match(/(?<!\\)\|/gu)?.length ?? 0) >= 2;
}
function isTableLine(line) {
    return tableCellCount(line) >= 2;
}
function isTableSeparator(line) {
    const trimmed = line.trim();
    if (!isTableLine(trimmed))
        return false;
    return trimmed
        .slice(1, -1)
        .split(/(?<!\\)\|/u)
        .every((cell) => /^\s*:?-{3,}:?\s*$/u.test(cell));
}
function unfinishedTableStart(markdown) {
    if (markdown.length === 0 || markdown.endsWith("\n"))
        return undefined;
    const lines = linesWithOffsets(markdown);
    let cursor = lines.length - 1;
    while (cursor >= 0 && isPipeRow(lines[cursor]?.content ?? ""))
        cursor -= 1;
    const group = lines.slice(cursor + 1);
    if (group.length === 0)
        return undefined;
    const headerCells = tableCellCount(group[0]?.content ?? "");
    const lastCells = tableCellCount(group.at(-1)?.content ?? "");
    if (group.length === 1)
        return group[0]?.start;
    if (!isTableSeparator(group[1]?.content ?? ""))
        return group[0]?.start;
    if (lastCells !== headerCells)
        return group[0]?.start;
    return undefined;
}
function splitStreamingMarkdown(markdown) {
    const ranges = fenceRanges(markdown);
    const candidates = [];
    const unclosedFence = ranges.find((range) => !range.closed);
    if (unclosedFence !== undefined)
        candidates.push(unclosedFence.start);
    const mathStart = unclosedMathStart(markdown, ranges);
    if (mathStart !== undefined)
        candidates.push(mathStart);
    const htmlStart = unclosedHtmlStart(markdown, ranges);
    if (htmlStart !== undefined)
        candidates.push(htmlStart);
    const tableStart = unfinishedTableStart(markdown);
    if (tableStart !== undefined)
        candidates.push(tableStart);
    const start = candidates.length > 0 ? Math.min(...candidates) : markdown.length;
    return {
        stableMarkdown: markdown.slice(0, start),
        pendingSource: markdown.slice(start)
    };
}
function transformOutsideFences(markdown, transform) {
    const ranges = fenceRanges(markdown);
    let cursor = 0;
    let value = "";
    let unclosedFenceMarker;
    for (const range of ranges) {
        value += transform(markdown.slice(cursor, range.start));
        value += markdown.slice(range.start, range.end);
        cursor = range.end;
        if (!range.closed)
            unclosedFenceMarker = range.marker;
    }
    value += transform(markdown.slice(cursor));
    return unclosedFenceMarker === undefined
        ? { value }
        : { value, unclosedFenceMarker };
}
function convertMathDelimiters(text) {
    return text
        .replace(/(?<!\\)\\\[([\s\S]*?)(?<!\\)\\\]/gu, (_match, body) => {
        const normalized = body.trim();
        return `$$\n${normalized}\n$$`;
    })
        .replace(/(?<!\\)\\\(([^\n]*?)(?<!\\)\\\)/gu, (_match, body) => `$${body.trim()}$`);
}
function insertMissingTableSeparators(text) {
    const lines = text.split("\n");
    const output = [];
    let index = 0;
    while (index < lines.length) {
        const line = lines[index] ?? "";
        if (!isTableLine(line)) {
            output.push(line);
            index += 1;
            continue;
        }
        const group = [];
        while (index < lines.length && isTableLine(lines[index] ?? "")) {
            group.push(lines[index] ?? "");
            index += 1;
        }
        const headerCount = tableCellCount(group[0] ?? "");
        const second = group[1];
        output.push(group[0] ?? "");
        if (second !== undefined &&
            !isTableSeparator(second) &&
            tableCellCount(second) === headerCount) {
            output.push(`| ${Array.from({ length: headerCount }, () => "---").join(" | ")} |`);
        }
        output.push(...group.slice(1));
    }
    return output.join("\n");
}
function isListLine(line) {
    return /^\s*(?:[-+*]|\d+[.)])\s+/u.test(line);
}
function isQuoteLine(line) {
    return /^\s*>\s?/u.test(line);
}
function isHeadingLine(line) {
    return /^\s*#{1,6}\s+/u.test(line);
}
function addStructuralBlankLines(text) {
    const lines = text.split("\n");
    const output = [];
    for (const line of lines) {
        const previous = output.at(-1) ?? "";
        const previousNonblank = previous.trim().length > 0;
        const needsSeparation = isHeadingLine(line) ||
            (isListLine(line) && !isListLine(previous)) ||
            (isQuoteLine(line) && !isQuoteLine(previous));
        if (previousNonblank && needsSeparation)
            output.push("");
        output.push(line);
    }
    return output.join("\n");
}
function closeUnmatchedMath(text) {
    const split = splitStreamingMarkdown(text);
    if (split.pendingSource.length === 0)
        return text;
    if (split.pendingSource.startsWith("$$"))
        return `${text}\n$$`;
    if (split.pendingSource.startsWith("$"))
        return `${text}$`;
    return text;
}
function normalizeObsidianMarkdown(markdown) {
    const transformed = transformOutsideFences(markdown, (text) => addStructuralBlankLines(insertMissingTableSeparators(convertMathDelimiters(text))));
    let normalized = transformed.value;
    if (transformed.unclosedFenceMarker !== undefined) {
        const separator = normalized.endsWith("\n") ? "" : "\n";
        normalized += `${separator}${transformed.unclosedFenceMarker}`;
        return normalized;
    }
    normalized = closeUnmatchedMath(normalized);
    return normalized;
}

},
"domain/node-summary.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NODE_SUMMARY_SYSTEM_PROMPT = exports.NODE_SUMMARY_PROTOCOL = void 0;
exports.buildNodeSummaryPrompt = buildNodeSummaryPrompt;
exports.cleanNodeSummaryTitle = cleanNodeSummaryTitle;
exports.canAttemptNodeSummary = canAttemptNodeSummary;
exports.markNodeSummaryPending = markNodeSummaryPending;
exports.applyNodeSummarySuccess = applyNodeSummarySuccess;
exports.applyNodeSummaryFailure = applyNodeSummaryFailure;
const schema_1 = require("./schema");
exports.NODE_SUMMARY_PROTOCOL = "node-summary:v3";
exports.NODE_SUMMARY_SYSTEM_PROMPT = [
    "TreeTalk Node Summary Protocol v3",
    "",
    "请根据父节点主题、框选内容、当前问题和回答节选，生成一个适合树状列表回溯的短索引标题。",
    "要求：",
    "1. 只输出一行标题。",
    "2. 中文目标为 4～10 个汉字，必要时最多 12 个字符。",
    "3. 英文目标为 2～6 个单词。",
    "4. 优先保留一个核心对象和一个关键关系。",
    "5. 标题应简短、直观、能够与相邻节点区分。",
    "6. 不完整复述用户问题。",
    "7. 不使用‘如何’‘为什么’‘怎么理解’等问句开头。",
    "8. 可以使用‘原因’‘作用’‘区别’‘机制’‘流程’‘故障’‘优化’等短关系词。",
    "9. 不生成过于模糊的单个名词，如‘问题’‘说明’‘功能’。",
    "10. 父节点只用于理解语境，不要机械拼接父节点标题。",
    "11. 不使用引号、句号、冒号、序号或 Markdown。",
    "12. 不回答问题，只生成标题。"
].join("\n");
function clip(value, limit) {
    return [...value].slice(0, limit).join("");
}
function answerWithoutSources(value) {
    const boundary = value.search(/^### 参考来源\s*$/mu);
    return (boundary < 0 ? value : value.slice(0, boundary)).trim();
}
function answerExcerpt(value) {
    const clean = answerWithoutSources(value);
    const characters = [...clean];
    if (characters.length <= 1200)
        return clean;
    return `${characters.slice(0, 800).join("")}\n…\n${characters
        .slice(-400)
        .join("")}`;
}
function buildNodeSummaryPrompt(input) {
    const parentTitle = clip(input.parentTitle?.trim() || "无", 40);
    const selectionExcerpt = clip((input.question.selectionContexts ?? [])
        .map((context) => context.quote.trim())
        .filter((quote) => quote.length > 0)
        .join("\n\n"), 300);
    const questionExcerpt = clip(input.question.content.trim(), 500);
    const excerpt = answerExcerpt(input.answer.content);
    const user = [
        "[父节点提要]",
        parentTitle,
        "",
        "[框选原文]",
        selectionExcerpt || "无",
        "",
        "[当前问题]",
        questionExcerpt,
        "",
        "[AI 回答节选]",
        excerpt
    ].join("\n");
    return {
        messages: [
            { role: "system", content: exports.NODE_SUMMARY_SYSTEM_PROMPT },
            { role: "user", content: user }
        ],
        parentTitle,
        selectionExcerpt,
        questionExcerpt,
        answerExcerpt: excerpt
    };
}
function cleanNodeSummaryTitle(value) {
    const firstLine = value.split(/\r?\n/u)[0] ?? "";
    let title = firstLine
        .replace(/^\s{0,3}#{1,6}\s*/u, "")
        .replace(/^\s*(?:[-*+] |\d+[.)]\s*)/u, "")
        .trim()
        .replace(/^["'“”‘’「」『』《》]+|["'“”‘’「」『』《》]+$/gu, "")
        .trim()
        .replace(/[。！？!?；;：:、,.，]+$/gu, "")
        .replace(/\s+/gu, " ")
        .trim();
    const hasHan = /\p{Script=Han}/u.test(title);
    if (hasHan) {
        title = [...title].slice(0, 12).join("").trim();
    }
    else {
        title = title.split(/\s+/u).slice(0, 6).join(" ").trim();
        title = [...title].slice(0, 40).join("").trim();
    }
    if (title.length === 0)
        return undefined;
    if (/^(?:本节点|本段|本文|这段内容|关于)/u.test(title))
        return undefined;
    return title;
}
function canRepairLegacySummary(node) {
    return (node.summary?.protocol === "node-summary:v1" &&
        node.summary.status !== "complete");
}
function canAttemptNodeSummary(node) {
    return ((node.summary === undefined || canRepairLegacySummary(node)) &&
        node.titleSource === "question" &&
        node.messages.some((message) => message.role === "assistant" && message.status === "complete"));
}
function mutable(conversation, nodeId) {
    const next = structuredClone(conversation);
    const node = next.nodes[nodeId];
    if (node === undefined)
        throw new Error(`Node not found: ${nodeId}`);
    return { next, node };
}
function commit(conversation, node, now) {
    node.updatedAt = now;
    conversation.updatedAt = now;
    conversation.revision += 1;
    return (0, schema_1.parseConversation)(conversation);
}
function markNodeSummaryPending(conversation, input) {
    const { next, node } = mutable(conversation, input.nodeId);
    if (node.summary !== undefined && !canRepairLegacySummary(node)) {
        return (0, schema_1.parseConversation)(next);
    }
    node.summary = {
        protocol: exports.NODE_SUMMARY_PROTOCOL,
        status: "pending",
        attemptedAt: input.now,
        providerProfileId: input.providerProfileId,
        modelId: input.modelId
    };
    return commit(next, node, input.now);
}
function applyNodeSummarySuccess(conversation, input) {
    const { next, node } = mutable(conversation, input.nodeId);
    const generatedTitle = cleanNodeSummaryTitle(input.title);
    if (generatedTitle === undefined) {
        return applyNodeSummaryFailure(conversation, {
            nodeId: input.nodeId,
            now: input.now
        });
    }
    const existing = node.summary;
    if (existing === undefined)
        return (0, schema_1.parseConversation)(next);
    node.summary = {
        ...existing,
        status: "complete",
        completedAt: input.now,
        generatedTitle
    };
    if (node.titleSource !== "manual") {
        node.title = generatedTitle;
        node.titleSource = "auto";
        if (node.id === next.rootNodeId)
            next.title = generatedTitle;
    }
    return commit(next, node, input.now);
}
function applyNodeSummaryFailure(conversation, input) {
    const { next, node } = mutable(conversation, input.nodeId);
    if (node.summary === undefined)
        return (0, schema_1.parseConversation)(next);
    node.summary = {
        ...node.summary,
        status: "failed",
        completedAt: input.now
    };
    return commit(next, node, input.now);
}

},
"domain/note-selection-context.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createNoteSelectionContext = createNoteSelectionContext;
const note_snapshot_1 = require("./note-snapshot");
const CONTEXT_LENGTH = 32;
async function createNoteSelectionContext(input) {
    const { visibleText, startOffset, endOffset } = input;
    const validRange = Number.isInteger(startOffset) &&
        Number.isInteger(endOffset) &&
        startOffset >= 0 &&
        endOffset <= visibleText.length &&
        startOffset < endOffset;
    if (!validRange) {
        throw new RangeError("Note selection range is invalid");
    }
    const quote = visibleText.slice(startOffset, endOffset);
    const context = {
        sourceType: "note",
        filePath: input.filePath,
        fileName: input.fileName,
        basis: input.basis,
        startOffset,
        endOffset,
        quote,
        prefix: visibleText.slice(Math.max(0, startOffset - CONTEXT_LENGTH), startOffset),
        suffix: visibleText.slice(endOffset, endOffset + CONTEXT_LENGTH),
        contentHash: await (0, note_snapshot_1.sha256Hex)(visibleText)
    };
    const sourceText = input.sourceText ?? visibleText;
    context.snapshot = await (0, note_snapshot_1.createNoteSnapshot)({
        sourceText,
        quote,
        basis: input.basis,
        sourceStartOffset: startOffset,
        sourceEndOffset: endOffset
    });
    return context;
}

},
"domain/note-snapshot.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NOTE_OMISSION_MARKER = exports.NOTE_SNAPSHOT_VERSION = void 0;
exports.sha256Hex = sha256Hex;
exports.stripYamlFrontmatter = stripYamlFrontmatter;
exports.createNoteSnapshot = createNoteSnapshot;
exports.estimateNoteTextTokens = estimateNoteTextTokens;
exports.trimNoteSnapshotContent = trimNoteSnapshotContent;
exports.renderNoteSnapshot = renderNoteSnapshot;
exports.NOTE_SNAPSHOT_VERSION = "note-snapshot-v1";
exports.NOTE_OMISSION_MARKER = "[此处省略了距离框选位置较远的笔记内容]";
async function sha256Hex(content) {
    const bytes = new TextEncoder().encode(content);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)]
        .map((value) => value.toString(16).padStart(2, "0"))
        .join("");
}
function stripYamlFrontmatter(source) {
    const bomLength = source.startsWith("\uFEFF") ? 1 : 0;
    const body = source.slice(bomLength);
    const firstBreak = body.indexOf("\n");
    const firstLine = (firstBreak < 0 ? body : body.slice(0, firstBreak)).replace(/\r$/u, "");
    if (firstLine.trim() !== "---") {
        return { content: body, removedPrefixLength: bomLength };
    }
    const linePattern = /^(?:---|\.\.\.)\s*\r?$/gmu;
    linePattern.lastIndex = firstBreak < 0 ? body.length : firstBreak + 1;
    const closing = linePattern.exec(body);
    if (closing === null) {
        return { content: body, removedPrefixLength: bomLength };
    }
    let contentStart = closing.index + closing[0].length;
    if (body.startsWith("\r\n", contentStart))
        contentStart += 2;
    else if (body.startsWith("\n", contentStart))
        contentStart += 1;
    return {
        content: body.slice(contentStart),
        removedPrefixLength: bomLength + contentStart
    };
}
function comparableProjection(value) {
    const characters = [];
    const sourceOffsets = [];
    for (let index = 0; index < value.length; index += 1) {
        const character = value[index] ?? "";
        if (/\s/u.test(character) || /[`*_~#>\[\]()!-]/u.test(character)) {
            continue;
        }
        characters.push(character.toLocaleLowerCase());
        sourceOffsets.push(index);
    }
    return { text: characters.join(""), sourceOffsets };
}
function resolveQuoteRange(content, quote) {
    const exact = content.indexOf(quote);
    if (exact >= 0)
        return { start: exact, end: exact + quote.length };
    const source = comparableProjection(content);
    const target = comparableProjection(quote).text;
    if (target.length === 0)
        return undefined;
    const projectedStart = source.text.indexOf(target);
    if (projectedStart < 0)
        return undefined;
    const first = source.sourceOffsets[projectedStart];
    const last = source.sourceOffsets[projectedStart + target.length - 1];
    if (first === undefined || last === undefined)
        return undefined;
    return { start: first, end: last + 1 };
}
async function createNoteSnapshot(input) {
    const stripped = stripYamlFrontmatter(input.sourceText);
    let selectionStartOffset = input.sourceStartOffset - stripped.removedPrefixLength;
    let selectionEndOffset = input.sourceEndOffset - stripped.removedPrefixLength;
    const exactSourceRange = input.basis === "note-source-v1" &&
        selectionStartOffset >= 0 &&
        selectionEndOffset <= stripped.content.length &&
        stripped.content.slice(selectionStartOffset, selectionEndOffset) === input.quote;
    if (!exactSourceRange) {
        const resolved = resolveQuoteRange(stripped.content, input.quote);
        if (resolved !== undefined) {
            selectionStartOffset = resolved.start;
            selectionEndOffset = resolved.end;
        }
        else {
            selectionStartOffset = Math.max(0, Math.min(stripped.content.length, selectionStartOffset));
            selectionEndOffset = Math.max(selectionStartOffset, Math.min(stripped.content.length, selectionEndOffset));
        }
    }
    return {
        version: exports.NOTE_SNAPSHOT_VERSION,
        content: stripped.content,
        contentHash: await sha256Hex(stripped.content),
        selectionStartOffset,
        selectionEndOffset
    };
}
function estimateNoteTextTokens(text) {
    let weighted = 0;
    for (const character of text) {
        if (/\s/u.test(character))
            continue;
        if (/\p{Script=Han}|\p{Script=Hiragana}|\p{Script=Katakana}|\p{Extended_Pictographic}/u.test(character)) {
            weighted += 1;
        }
        else if (/[^\x00-\x7F]/u.test(character)) {
            weighted += 0.6;
        }
        else {
            weighted += 0.25;
        }
    }
    return Math.max(1, Math.ceil(weighted));
}
function headingSections(content) {
    const matches = [...content.matchAll(/^(#{1,6})[ \t]+.*$/gmu)];
    if (matches.length === 0) {
        return [{ start: 0, end: content.length, level: 1 }];
    }
    return matches.map((match, index) => {
        const start = match.index ?? 0;
        const level = (match[1] ?? "#").length;
        let end = content.length;
        for (let next = index + 1; next < matches.length; next += 1) {
            const candidate = matches[next];
            if (candidate === undefined)
                continue;
            const candidateLevel = (candidate[1] ?? "#").length;
            if (candidateLevel <= level) {
                end = candidate.index ?? content.length;
                break;
            }
        }
        return { start, end, level };
    });
}
function selectedSectionIndex(sections, selectionStartOffset) {
    let selected = 0;
    for (const [index, section] of sections.entries()) {
        if (section.start > selectionStartOffset)
            break;
        if (selectionStartOffset < section.end)
            selected = index;
    }
    return selected;
}
function withOmissionMarkers(content, start, end) {
    const parts = [];
    if (start > 0)
        parts.push(exports.NOTE_OMISSION_MARKER);
    parts.push(content.slice(start, end).trim());
    if (end < content.length)
        parts.push(exports.NOTE_OMISSION_MARKER);
    return parts.filter((entry) => entry.length > 0).join("\n\n");
}
function centeredWindow(content, selectionStartOffset, selectionEndOffset, maxTokens, preferredStart, preferredEnd) {
    let left = Math.max(preferredStart, selectionStartOffset - 64);
    let right = Math.min(preferredEnd, Math.max(selectionEndOffset + 64, left + 1));
    let step = Math.max(128, Math.floor((preferredEnd - preferredStart) / 4));
    while (step >= 1) {
        let expanded = false;
        const nextLeft = Math.max(preferredStart, left - step);
        const leftCandidate = withOmissionMarkers(content, nextLeft, right);
        if (estimateNoteTextTokens(leftCandidate) <= maxTokens) {
            left = nextLeft;
            expanded = true;
        }
        const nextRight = Math.min(preferredEnd, right + step);
        const rightCandidate = withOmissionMarkers(content, left, nextRight);
        if (estimateNoteTextTokens(rightCandidate) <= maxTokens) {
            right = nextRight;
            expanded = true;
        }
        if (!expanded)
            step = Math.floor(step / 2);
        if (left === preferredStart && right === preferredEnd)
            break;
    }
    return withOmissionMarkers(content, left, right);
}
function trimNoteSnapshotContent(snapshot, maxTokens) {
    const content = snapshot.content;
    if (estimateNoteTextTokens(content) <= maxTokens)
        return content;
    const sections = headingSections(content);
    const selectedFirstIndex = selectedSectionIndex(sections, snapshot.selectionStartOffset);
    const selectedLastIndex = selectedSectionIndex(sections, Math.max(snapshot.selectionStartOffset, snapshot.selectionEndOffset - 1));
    const selectedFirst = sections[selectedFirstIndex] ?? {
        start: 0,
        end: content.length,
        level: 1
    };
    const selectedLast = sections[selectedLastIndex] ?? selectedFirst;
    const selectedCandidate = withOmissionMarkers(content, selectedFirst.start, selectedLast.end);
    if (estimateNoteTextTokens(selectedCandidate) > maxTokens) {
        return centeredWindow(content, snapshot.selectionStartOffset, snapshot.selectionEndOffset, maxTokens, selectedFirst.start, selectedLast.end);
    }
    let first = selectedFirstIndex;
    let last = selectedLastIndex;
    let distance = 1;
    while (true) {
        let changed = false;
        const previous = selectedFirstIndex - distance;
        if (previous >= 0) {
            const start = sections[previous]?.start ?? 0;
            const end = sections[last]?.end ?? selectedLast.end;
            const candidate = withOmissionMarkers(content, start, end);
            if (estimateNoteTextTokens(candidate) <= maxTokens) {
                first = previous;
                changed = true;
            }
        }
        const next = selectedLastIndex + distance;
        if (next < sections.length) {
            const start = sections[first]?.start ?? selectedFirst.start;
            const end = sections[next]?.end ?? content.length;
            const candidate = withOmissionMarkers(content, start, end);
            if (estimateNoteTextTokens(candidate) <= maxTokens) {
                last = next;
                changed = true;
            }
        }
        if (previous < 0 && next >= sections.length)
            break;
        distance += 1;
        if (!changed && distance > sections.length)
            break;
    }
    return withOmissionMarkers(content, sections[first]?.start ?? selectedFirst.start, sections[last]?.end ?? selectedLast.end);
}
function renderNoteSnapshot(snapshot, maxTokens) {
    const originalEstimatedTokens = estimateNoteTextTokens(snapshot.content);
    const content = trimNoteSnapshotContent(snapshot, maxTokens);
    const sentEstimatedTokens = estimateNoteTextTokens(content);
    return {
        content,
        originalEstimatedTokens,
        sentEstimatedTokens,
        trimmed: content !== snapshot.content
    };
}

},
"domain/response-epoch.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseEpoch = void 0;
class ResponseEpoch {
    value = 0;
    capture() {
        return this.value;
    }
    invalidate() {
        this.value += 1;
    }
    isCurrent(value) {
        return value === this.value;
    }
}
exports.ResponseEpoch = ResponseEpoch;

},
"domain/schema.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateTree = validateTree;
exports.parseConversation = parseConversation;
function record(value, label) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
        throw new TypeError(`${label} must be an object`);
    }
    return value;
}
function string(value, label) {
    if (typeof value !== "string") {
        throw new TypeError(`${label} must be a string`);
    }
    return value;
}
function nonNegativeNumber(value, label) {
    if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
        throw new TypeError(`${label} must be a non-negative number`);
    }
    return value;
}
function integer(value, label) {
    const parsed = nonNegativeNumber(value, label);
    if (!Number.isInteger(parsed)) {
        throw new TypeError(`${label} must be an integer`);
    }
    return parsed;
}
function stringArray(value, label) {
    if (!Array.isArray(value)) {
        throw new TypeError(`${label} must be an array`);
    }
    return value.map((entry, index) => string(entry, `${label}[${String(index)}]`));
}
function optionalString(value, label) {
    return value === undefined ? undefined : string(value, label);
}
function optionalValidStringArray(value) {
    if (value === undefined || !Array.isArray(value))
        return undefined;
    if (!value.every((entry) => typeof entry === "string"))
        return undefined;
    return [...value];
}
function parseNodeTitleSource(value, label) {
    const source = string(value, label);
    if (source !== "question" && source !== "auto" && source !== "manual") {
        throw new TypeError(`${label} is invalid`);
    }
    return source;
}
function parseNodeSummary(value, label) {
    const source = record(value, label);
    const protocol = string(source.protocol, `${label}.protocol`);
    if (protocol !== "node-summary:v1" &&
        protocol !== "node-summary:v2" &&
        protocol !== "node-summary:v3") {
        throw new TypeError(`${label}.protocol is invalid`);
    }
    const status = string(source.status, `${label}.status`);
    if (status !== "pending" && status !== "complete" && status !== "failed") {
        throw new TypeError(`${label}.status is invalid`);
    }
    const summary = {
        protocol,
        status,
        attemptedAt: string(source.attemptedAt, `${label}.attemptedAt`),
        providerProfileId: string(source.providerProfileId, `${label}.providerProfileId`),
        modelId: string(source.modelId, `${label}.modelId`)
    };
    const completedAt = optionalString(source.completedAt, `${label}.completedAt`);
    const generatedTitle = optionalString(source.generatedTitle, `${label}.generatedTitle`);
    if (completedAt !== undefined)
        summary.completedAt = completedAt;
    if (generatedTitle !== undefined && generatedTitle.trim().length > 0) {
        summary.generatedTitle = generatedTitle;
    }
    return summary;
}
function parseSelectionAnchorFromRecord(source, label) {
    const sourceRole = optionalString(source.sourceRole, `${label}.sourceRole`);
    if (sourceRole !== undefined &&
        sourceRole !== "user" &&
        sourceRole !== "assistant") {
        throw new TypeError(`${label}.sourceRole is invalid`);
    }
    const basis = optionalString(source.basis, `${label}.basis`);
    if (basis !== undefined && basis !== "rendered-text-v1") {
        throw new TypeError(`${label}.basis is invalid`);
    }
    const anchor = {
        messageId: string(source.messageId, `${label}.messageId`),
        sourceNodeId: optionalString(source.sourceNodeId, `${label}.sourceNodeId`) ?? "",
        sourceRole: sourceRole ?? "assistant",
        basis: "rendered-text-v1",
        startOffset: integer(source.startOffset, `${label}.startOffset`),
        endOffset: integer(source.endOffset, `${label}.endOffset`),
        quote: string(source.quote, `${label}.quote`),
        prefix: string(source.prefix, `${label}.prefix`),
        suffix: string(source.suffix, `${label}.suffix`),
        contentHash: string(source.contentHash, `${label}.contentHash`)
    };
    const visibleQuote = optionalString(source.visibleQuote, `${label}.visibleQuote`);
    if (visibleQuote !== undefined)
        anchor.visibleQuote = visibleQuote;
    return anchor;
}
function parseNoteSnapshot(value, label) {
    const source = record(value, label);
    if (string(source.version, `${label}.version`) !== "note-snapshot-v1") {
        throw new TypeError(`${label}.version is invalid`);
    }
    const content = string(source.content, `${label}.content`);
    const selectionStartOffset = integer(source.selectionStartOffset, `${label}.selectionStartOffset`);
    const selectionEndOffset = integer(source.selectionEndOffset, `${label}.selectionEndOffset`);
    if (selectionStartOffset > selectionEndOffset ||
        selectionEndOffset > content.length) {
        throw new TypeError(`${label} selection range is invalid`);
    }
    return {
        version: "note-snapshot-v1",
        content,
        contentHash: string(source.contentHash, `${label}.contentHash`),
        selectionStartOffset,
        selectionEndOffset
    };
}
function parseNoteSelectionContextFromRecord(source, label) {
    const basis = string(source.basis, `${label}.basis`);
    if (basis !== "note-source-v1" && basis !== "note-rendered-text-v1") {
        throw new TypeError(`${label}.basis is invalid`);
    }
    const context = {
        sourceType: "note",
        filePath: string(source.filePath, `${label}.filePath`),
        fileName: string(source.fileName, `${label}.fileName`),
        basis,
        startOffset: integer(source.startOffset, `${label}.startOffset`),
        endOffset: integer(source.endOffset, `${label}.endOffset`),
        quote: string(source.quote, `${label}.quote`),
        prefix: string(source.prefix, `${label}.prefix`),
        suffix: string(source.suffix, `${label}.suffix`),
        contentHash: string(source.contentHash, `${label}.contentHash`)
    };
    if (source.snapshot !== undefined) {
        context.snapshot = parseNoteSnapshot(source.snapshot, `${label}.snapshot`);
    }
    return context;
}
function parseSelectionContext(value, label) {
    const source = record(value, label);
    if (source.sourceType === "note") {
        return parseNoteSelectionContextFromRecord(source, label);
    }
    if (source.sourceType !== undefined && source.sourceType !== "message") {
        throw new TypeError(`${label}.sourceType is invalid`);
    }
    return parseSelectionAnchorFromRecord(source, label);
}
function ratio(value, label) {
    const parsed = nonNegativeNumber(value, label);
    if (parsed > 1)
        throw new TypeError(`${label} must be at most 1`);
    return parsed;
}
function parseBalancedFreezeArtifact(value, label) {
    const source = record(value, label);
    if (string(source.protocol, `${label}.protocol`) !== "balanced:v3") {
        throw new TypeError(`${label}.protocol is invalid`);
    }
    const sourceType = string(source.sourceType, `${label}.sourceType`);
    if (sourceType !== "assistant-message" &&
        sourceType !== "note-snapshot" &&
        sourceType !== "recovery-patch") {
        throw new TypeError(`${label}.sourceType is invalid`);
    }
    const tier = string(source.tier, `${label}.tier`);
    if (tier !== "standard" && tier !== "compact") {
        throw new TypeError(`${label}.tier is invalid`);
    }
    return {
        protocol: "balanced:v3",
        key: string(source.key, `${label}.key`),
        sourceType,
        sourceIdentity: string(source.sourceIdentity, `${label}.sourceIdentity`),
        sourceContentHash: string(source.sourceContentHash, `${label}.sourceContentHash`),
        protectionHash: string(source.protectionHash, `${label}.protectionHash`),
        tier,
        content: string(source.content, `${label}.content`),
        originalEstimatedTokens: integer(source.originalEstimatedTokens, `${label}.originalEstimatedTokens`),
        sentEstimatedTokens: integer(source.sentEstimatedTokens, `${label}.sentEstimatedTokens`),
        deletionRatio: ratio(source.deletionRatio, `${label}.deletionRatio`)
    };
}
function parseBalancedContextState(value, label) {
    const source = record(value, label);
    if (string(source.protocol, `${label}.protocol`) !== "balanced:v3") {
        throw new TypeError(`${label}.protocol is invalid`);
    }
    return {
        protocol: "balanced:v3",
        artifactKeys: stringArray(source.artifactKeys, `${label}.artifactKeys`),
        compactSourceIdentities: stringArray(source.compactSourceIdentities, `${label}.compactSourceIdentities`),
        recoveryPatchKeys: stringArray(source.recoveryPatchKeys, `${label}.recoveryPatchKeys`)
    };
}
function parseMessage(value, label) {
    const source = record(value, label);
    const role = string(source.role, `${label}.role`);
    const status = string(source.status, `${label}.status`);
    if (role !== "user" && role !== "assistant") {
        throw new TypeError(`${label}.role is invalid`);
    }
    if (!["complete", "streaming", "interrupted", "failed"].includes(status)) {
        throw new TypeError(`${label}.status is invalid`);
    }
    const message = {
        id: string(source.id, `${label}.id`),
        role,
        content: string(source.content, `${label}.content`),
        status: status,
        createdAt: string(source.createdAt, `${label}.createdAt`),
        updatedAt: string(source.updatedAt, `${label}.updatedAt`)
    };
    const responseVersionGroupId = optionalString(source.responseVersionGroupId, `${label}.responseVersionGroupId`);
    const providerProfileId = optionalString(source.providerProfileId, `${label}.providerProfileId`);
    const modelId = optionalString(source.modelId, `${label}.modelId`);
    if (responseVersionGroupId !== undefined)
        message.responseVersionGroupId = responseVersionGroupId;
    if (providerProfileId !== undefined)
        message.providerProfileId = providerProfileId;
    if (modelId !== undefined)
        message.modelId = modelId;
    if (source.balancedContextState !== undefined) {
        message.balancedContextState = parseBalancedContextState(source.balancedContextState, `${label}.balancedContextState`);
    }
    const referencedNoteNames = optionalValidStringArray(source.referencedNoteNames);
    if (referencedNoteNames !== undefined) {
        message.referencedNoteNames = referencedNoteNames;
    }
    const rawSelectionContexts = source.selectionContexts ??
        (source.selectionContext === undefined ? [] : [source.selectionContext]);
    if (!Array.isArray(rawSelectionContexts)) {
        throw new TypeError(`${label}.selectionContexts must be an array`);
    }
    if (rawSelectionContexts.length > 0) {
        message.selectionContexts = rawSelectionContexts.map((entry, index) => parseSelectionContext(entry, `${label}.selectionContexts[${String(index)}]`));
    }
    return message;
}
function parseDraft(value, label) {
    const source = record(value, label);
    const mode = string(source.mode, `${label}.mode`);
    if (mode !== "continue" && mode !== "child") {
        throw new TypeError(`${label}.mode is invalid`);
    }
    const draft = {
        text: string(source.text, `${label}.text`),
        mode,
        selectionContexts: []
    };
    const rawSelectionContexts = source.selectionContexts ??
        (source.selectionContext === undefined ? [] : [source.selectionContext]);
    if (!Array.isArray(rawSelectionContexts)) {
        throw new TypeError(`${label}.selectionContexts must be an array`);
    }
    draft.selectionContexts = rawSelectionContexts.map((entry, index) => parseSelectionContext(entry, `${label}.selectionContexts[${String(index)}]`));
    return draft;
}
function parseNode(value, label) {
    const source = record(value, label);
    const parentId = source.parentId === null ? null : string(source.parentId, `${label}.parentId`);
    if (!Array.isArray(source.messages)) {
        throw new TypeError(`${label}.messages must be an array`);
    }
    const node = {
        id: string(source.id, `${label}.id`),
        parentId,
        childIds: stringArray(source.childIds, `${label}.childIds`),
        title: string(source.title, `${label}.title`),
        messages: source.messages.map((message, index) => parseMessage(message, `${label}.messages[${String(index)}]`)),
        draft: parseDraft(source.draft, `${label}.draft`),
        createdAt: string(source.createdAt, `${label}.createdAt`),
        updatedAt: string(source.updatedAt, `${label}.updatedAt`)
    };
    if (source.titleSource !== undefined) {
        node.titleSource = parseNodeTitleSource(source.titleSource, `${label}.titleSource`);
    }
    if (source.summary !== undefined) {
        node.summary = parseNodeSummary(source.summary, `${label}.summary`);
    }
    return node;
}
function parseUi(value) {
    const source = record(value, "ui");
    const scrollRecord = record(source.messageScrollTopByNode, "ui.messageScrollTopByNode");
    const messageScrollTopByNode = {};
    for (const [nodeId, scrollTop] of Object.entries(scrollRecord)) {
        messageScrollTopByNode[nodeId] = nonNegativeNumber(scrollTop, `ui.messageScrollTopByNode.${nodeId}`);
    }
    return {
        expandedNodeIds: stringArray(source.expandedNodeIds, "ui.expandedNodeIds"),
        treeScrollTop: nonNegativeNumber(source.treeScrollTop, "ui.treeScrollTop"),
        messageScrollTopByNode
    };
}
function validateTree(conversation) {
    const issues = [];
    const { nodes } = conversation;
    if (!(conversation.rootNodeId in nodes)) {
        issues.push({ code: "missing-root", message: "Root node does not exist" });
        return issues;
    }
    if (!(conversation.currentNodeId in nodes)) {
        issues.push({ code: "missing-current", message: "Current node does not exist" });
    }
    for (const node of Object.values(nodes)) {
        if (new Set(node.childIds).size !== node.childIds.length) {
            issues.push({ code: "duplicate-child", message: "Duplicate child ID", nodeId: node.id });
        }
        for (const childId of node.childIds) {
            const child = nodes[childId];
            if (child === undefined) {
                issues.push({ code: "missing-child", message: "Child node does not exist", nodeId: node.id });
            }
            else if (child.parentId !== node.id) {
                issues.push({
                    code: "parent-mismatch",
                    message: "Child parent does not point back to parent",
                    nodeId: childId
                });
            }
        }
        if (node.parentId !== null) {
            const parent = nodes[node.parentId];
            if (parent === undefined || !parent.childIds.includes(node.id)) {
                issues.push({
                    code: "parent-mismatch",
                    message: "Parent does not point back to child",
                    nodeId: node.id
                });
            }
        }
    }
    const visiting = new Set();
    const visited = new Set();
    const visit = (nodeId) => {
        if (visiting.has(nodeId)) {
            issues.push({ code: "cycle", message: "Tree contains a cycle", nodeId });
            return;
        }
        if (visited.has(nodeId))
            return;
        visiting.add(nodeId);
        for (const childId of nodes[nodeId]?.childIds ?? []) {
            if (nodes[childId] !== undefined)
                visit(childId);
        }
        visiting.delete(nodeId);
        visited.add(nodeId);
    };
    visit(conversation.rootNodeId);
    for (const nodeId of Object.keys(nodes)) {
        if (!visited.has(nodeId)) {
            issues.push({ code: "unreachable", message: "Node is unreachable from root", nodeId });
        }
    }
    return issues;
}
function deepFreeze(value) {
    if (typeof value !== "object" || value === null || Object.isFrozen(value))
        return value;
    for (const child of Object.values(value)) {
        deepFreeze(child);
    }
    return Object.freeze(value);
}
function parseConversation(value) {
    const source = record(value, "conversation");
    if (source.schemaVersion !== 1) {
        throw new TypeError("Unsupported schemaVersion");
    }
    const rawNodes = record(source.nodes, "nodes");
    const nodes = {};
    for (const [nodeId, rawNode] of Object.entries(rawNodes)) {
        const node = parseNode(rawNode, `nodes.${nodeId}`);
        if (node.id !== nodeId) {
            throw new TypeError(`nodes.${nodeId}.id does not match its key`);
        }
        nodes[nodeId] = node;
    }
    const status = string(source.status, "status");
    if (status !== "active" && status !== "archived") {
        throw new TypeError("status is invalid");
    }
    const conversation = {
        schemaVersion: 1,
        id: string(source.id, "id"),
        title: string(source.title, "title"),
        status,
        revision: integer(source.revision, "revision"),
        checksum: string(source.checksum, "checksum"),
        createdAt: string(source.createdAt, "createdAt"),
        updatedAt: string(source.updatedAt, "updatedAt"),
        rootNodeId: string(source.rootNodeId, "rootNodeId"),
        currentNodeId: string(source.currentNodeId, "currentNodeId"),
        nodes,
        ui: parseUi(source.ui)
    };
    if (source.contextArtifacts !== undefined) {
        const artifactsSource = record(source.contextArtifacts, "contextArtifacts");
        const contextArtifacts = {};
        if (artifactsSource.balancedV3 !== undefined) {
            const balancedSource = record(artifactsSource.balancedV3, "contextArtifacts.balancedV3");
            const balancedV3 = {};
            for (const [key, value] of Object.entries(balancedSource)) {
                const artifact = parseBalancedFreezeArtifact(value, `contextArtifacts.balancedV3.${key}`);
                if (artifact.key !== key) {
                    throw new TypeError(`contextArtifacts.balancedV3.${key}.key does not match its key`);
                }
                balancedV3[key] = artifact;
            }
            contextArtifacts.balancedV3 = balancedV3;
        }
        conversation.contextArtifacts = contextArtifacts;
    }
    const issues = validateTree(conversation);
    if (issues.length > 0) {
        throw new TypeError(issues.map((issue) => `${issue.code}: ${issue.message}`).join("; "));
    }
    return deepFreeze(conversation);
}

},
"domain/selection-anchor.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSelectionAnchor = createSelectionAnchor;
exports.resolveSelectionAnchor = resolveSelectionAnchor;
const CONTEXT_LENGTH = 32;
async function sha256(content) {
    const bytes = new TextEncoder().encode(content);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)]
        .map((value) => value.toString(16).padStart(2, "0"))
        .join("");
}
async function createSelectionAnchor(input) {
    const { messageId, sourceNodeId, sourceRole, visibleText, startOffset, endOffset } = input;
    const validRange = Number.isInteger(startOffset) &&
        Number.isInteger(endOffset) &&
        startOffset >= 0 &&
        endOffset <= visibleText.length &&
        startOffset < endOffset;
    if (!validRange) {
        throw new RangeError("Selection range is invalid");
    }
    const visibleQuote = visibleText.slice(startOffset, endOffset);
    const quote = input.quoteOverride ?? visibleQuote;
    const anchor = {
        messageId,
        sourceNodeId,
        sourceRole,
        basis: "rendered-text-v1",
        startOffset,
        endOffset,
        quote,
        prefix: visibleText.slice(Math.max(0, startOffset - CONTEXT_LENGTH), startOffset),
        suffix: visibleText.slice(endOffset, endOffset + CONTEXT_LENGTH),
        contentHash: await sha256(visibleText)
    };
    if (quote !== visibleQuote)
        anchor.visibleQuote = visibleQuote;
    return anchor;
}
function commonSuffixLength(left, right) {
    const maximum = Math.min(left.length, right.length);
    let matched = 0;
    while (matched < maximum &&
        left[left.length - 1 - matched] === right[right.length - 1 - matched]) {
        matched += 1;
    }
    return matched;
}
function commonPrefixLength(left, right) {
    const maximum = Math.min(left.length, right.length);
    let matched = 0;
    while (matched < maximum && left[matched] === right[matched]) {
        matched += 1;
    }
    return matched;
}
function resolveSelectionAnchor(content, anchor) {
    const visibleQuote = anchor.visibleQuote ?? anchor.quote;
    if (content.slice(anchor.startOffset, anchor.endOffset) === visibleQuote) {
        return {
            status: "resolved",
            start: anchor.startOffset,
            end: anchor.endOffset
        };
    }
    const candidates = [];
    let searchFrom = 0;
    while (searchFrom <= content.length - visibleQuote.length) {
        const start = content.indexOf(visibleQuote, searchFrom);
        if (start < 0)
            break;
        const end = start + visibleQuote.length;
        const before = content.slice(Math.max(0, start - anchor.prefix.length), start);
        const after = content.slice(end, end + anchor.suffix.length);
        candidates.push({
            start,
            end,
            contextScore: commonSuffixLength(anchor.prefix, before) + commonPrefixLength(anchor.suffix, after),
            distance: Math.abs(start - anchor.startOffset)
        });
        searchFrom = start + Math.max(1, visibleQuote.length);
    }
    candidates.sort((left, right) => right.contextScore - left.contextScore ||
        left.distance - right.distance ||
        left.start - right.start);
    const best = candidates[0];
    if (best === undefined) {
        return { status: "unresolved", quote: anchor.quote };
    }
    const second = candidates[1];
    if (second !== undefined &&
        second.contextScore === best.contextScore &&
        second.distance === best.distance) {
        return { status: "unresolved", quote: anchor.quote };
    }
    return {
        status: "resolved",
        start: best.start,
        end: best.end
    };
}

},
"domain/tree-commands.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.continueNode = continueNode;
exports.prepareChildDraft = prepareChildDraft;
exports.addSelectionToDraft = addSelectionToDraft;
exports.removeSelectionFromDraft = removeSelectionFromDraft;
exports.submitChildDraft = submitChildDraft;
exports.revertTreeCommand = revertTreeCommand;
const schema_1 = require("./schema");
const draft_contexts_1 = require("./draft-contexts");
function mutableClone(conversation) {
    return structuredClone(conversation);
}
function requiredNode(conversation, nodeId) {
    const node = conversation.nodes[nodeId];
    if (node === undefined) {
        throw new Error(`Node not found: ${nodeId}`);
    }
    return node;
}
function applyFirstQuestionTitle(conversation, text) {
    const hasUserMessage = Object.values(conversation.nodes).some((node) => node.messages.some((message) => message.role === "user"));
    if (hasUserMessage)
        return undefined;
    const root = requiredNode(conversation, conversation.rootNodeId);
    const previousTitles = {
        previousConversationTitle: conversation.title,
        previousRootTitle: root.title
    };
    const title = text.trim().split(/\r?\n/u)[0]?.slice(0, 80) ?? text.slice(0, 80);
    conversation.title = title;
    root.title = title;
    root.titleSource = "question";
    delete root.summary;
    return previousTitles;
}
function userMessage(id, content, now, selectionContexts) {
    const message = {
        id,
        role: "user",
        content,
        status: "complete",
        createdAt: now,
        updatedAt: now
    };
    if (selectionContexts.length > 0) {
        message.selectionContexts = structuredClone(selectionContexts);
    }
    return message;
}
function nextRevision(conversation, now) {
    conversation.revision += 1;
    conversation.updatedAt = now;
}
function continueNode(conversation, input) {
    const text = input.text.trim();
    if (text.length === 0) {
        throw new Error("Message cannot be empty");
    }
    const state = mutableClone(conversation);
    const previousTitles = applyFirstQuestionTitle(state, text);
    const node = requiredNode(state, input.nodeId);
    const previousDraft = structuredClone(node.draft);
    const previousCurrentNodeId = state.currentNodeId;
    const selectionContexts = input.selectionContexts ?? node.draft.selectionContexts;
    node.messages.push(userMessage(input.messageId, text, input.now, selectionContexts));
    node.draft = { text: "", mode: "continue", selectionContexts: [] };
    node.updatedAt = input.now;
    state.currentNodeId = input.nodeId;
    nextRevision(state, input.now);
    return {
        state: (0, schema_1.parseConversation)(state),
        operation: {
            kind: "append-message",
            nodeId: input.nodeId,
            messageId: input.messageId,
            previousDraft,
            previousCurrentNodeId,
            appliedRevision: state.revision,
            ...previousTitles
        }
    };
}
function prepareChildDraft(conversation, input) {
    const state = mutableClone(conversation);
    const node = requiredNode(state, input.nodeId);
    const draft = {
        text: node.draft.text,
        mode: "child",
        selectionContexts: structuredClone(node.draft.selectionContexts)
    };
    node.draft = draft;
    node.updatedAt = input.now;
    state.currentNodeId = input.nodeId;
    nextRevision(state, input.now);
    return (0, schema_1.parseConversation)(state);
}
function addSelectionToDraft(conversation, nodeId, anchor, now) {
    const state = mutableClone(conversation);
    const node = requiredNode(state, nodeId);
    node.draft.selectionContexts = (0, draft_contexts_1.appendDraftContext)(node.draft.selectionContexts, anchor);
    node.updatedAt = now;
    state.currentNodeId = nodeId;
    nextRevision(state, now);
    return (0, schema_1.parseConversation)(state);
}
function removeSelectionFromDraft(conversation, nodeId, key, now) {
    const state = mutableClone(conversation);
    const node = requiredNode(state, nodeId);
    node.draft.selectionContexts = (0, draft_contexts_1.removeDraftContext)(node.draft.selectionContexts, key);
    node.updatedAt = now;
    state.currentNodeId = nodeId;
    nextRevision(state, now);
    return (0, schema_1.parseConversation)(state);
}
function submitChildDraft(conversation, input) {
    const text = input.text.trim();
    if (text.length === 0) {
        throw new Error("Child message cannot be empty");
    }
    const state = mutableClone(conversation);
    if (state.nodes[input.childId] !== undefined) {
        throw new Error(`Node already exists: ${input.childId}`);
    }
    const parent = requiredNode(state, state.currentNodeId);
    if (parent.draft.mode !== "child") {
        throw new Error("Current node is not preparing a child");
    }
    const previousDraft = structuredClone(parent.draft);
    const previousChildIds = [...parent.childIds];
    const previousCurrentNodeId = state.currentNodeId;
    const previousTitles = applyFirstQuestionTitle(state, text);
    const firstMessage = userMessage(input.messageId, text, input.now, parent.draft.selectionContexts);
    const child = {
        id: input.childId,
        parentId: parent.id,
        childIds: [],
        title: text.split(/\r?\n/u)[0]?.slice(0, 80) ?? text.slice(0, 80),
        titleSource: "question",
        messages: [firstMessage],
        draft: { text: "", mode: "continue", selectionContexts: [] },
        createdAt: input.now,
        updatedAt: input.now
    };
    parent.childIds.push(child.id);
    parent.draft = { text: "", mode: "continue", selectionContexts: [] };
    parent.updatedAt = input.now;
    state.nodes[child.id] = child;
    state.currentNodeId = child.id;
    nextRevision(state, input.now);
    return {
        state: (0, schema_1.parseConversation)(state),
        operation: {
            kind: "create-child",
            childId: child.id,
            parentId: parent.id,
            previousDraft,
            previousChildIds,
            previousCurrentNodeId,
            appliedRevision: state.revision,
            ...previousTitles
        }
    };
}
function revertTreeCommand(conversation, operation) {
    if (conversation.revision !== operation.appliedRevision) {
        throw new Error("Cannot undo because the conversation revision changed");
    }
    const state = mutableClone(conversation);
    if (operation.kind === "create-child") {
        const parent = requiredNode(state, operation.parentId);
        state.nodes = Object.fromEntries(Object.entries(state.nodes).filter(([nodeId]) => nodeId !== operation.childId));
        parent.childIds = [...operation.previousChildIds];
        parent.draft = structuredClone(operation.previousDraft);
        state.currentNodeId = operation.previousCurrentNodeId;
    }
    else {
        const node = requiredNode(state, operation.nodeId);
        node.messages = node.messages.filter((message) => message.id !== operation.messageId);
        node.draft = structuredClone(operation.previousDraft);
        state.currentNodeId = operation.previousCurrentNodeId;
    }
    if (operation.previousConversationTitle !== undefined &&
        operation.previousRootTitle !== undefined) {
        state.title = operation.previousConversationTitle;
        requiredNode(state, state.rootNodeId).title = operation.previousRootTitle;
    }
    state.revision += 1;
    return (0, schema_1.parseConversation)(state);
}

},
"domain/types.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isNoteSelectionContext = isNoteSelectionContext;
exports.isMessageSelectionContext = isMessageSelectionContext;
function isNoteSelectionContext(context) {
    return "sourceType" in context;
}
function isMessageSelectionContext(context) {
    return !isNoteSelectionContext(context);
}

},
"editor/excerpt-drop-extension.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleExcerptDrop = handleExcerptDrop;
exports.createExcerptDropExtension = createExcerptDropExtension;
const view_1 = require("@codemirror/view");
const excerpt_drag_1 = require("../knowledge/excerpt-drag");
function insertAtBlockBoundary(document, position, block) {
    const before = document.slice(0, position);
    const after = document.slice(position);
    const prefix = before.length === 0
        ? ""
        : before.endsWith("\n\n")
            ? ""
            : before.endsWith("\n")
                ? "\n"
                : "\n\n";
    const suffix = after.length === 0
        ? ""
        : after.startsWith("\n\n")
            ? ""
            : after.startsWith("\n")
                ? "\n"
                : "\n\n";
    return `${prefix}${block}${suffix}`;
}
function handleExcerptDrop(view, event) {
    const serialized = event.dataTransfer?.getData(excerpt_drag_1.TREETALK_EXCERPT_MIME);
    if (serialized === undefined || serialized.length === 0)
        return false;
    const payload = (0, excerpt_drag_1.parseExcerptPayload)(serialized);
    if (payload === undefined)
        return false;
    const position = view.posAtCoords({
        x: event.clientX,
        y: event.clientY
    });
    if (position === null)
        return false;
    const inserted = insertAtBlockBoundary(view.state.doc.toString(), position, (0, excerpt_drag_1.renderExcerptCallout)(payload));
    view.dispatch({
        changes: { from: position, insert: inserted },
        selection: { anchor: position + inserted.length }
    });
    event.preventDefault();
    return true;
}
function createExcerptDropExtension() {
    return view_1.EditorView.domEventHandlers({
        drop: (event, view) => handleExcerptDrop(view, event)
    });
}

},
"editor/note-selection-capture.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.captureNoteSelection = captureNoteSelection;
exports.installNoteSelectionCapture = installNoteSelectionCapture;
const tree_commands_1 = require("../domain/tree-commands");
const note_selection_context_1 = require("../domain/note-selection-context");
const rendered_selection_1 = require("../views/rendered-selection");
async function captureNoteSelection(source, domSelection = source.contentEl.ownerDocument.defaultView?.getSelection() ?? null) {
    if (source.mode === "source") {
        const editor = source.editor;
        if (editor === undefined || editor.getSelection().trim().length === 0) {
            return undefined;
        }
        const visibleText = editor.getValue();
        const startOffset = editor.posToOffset(editor.getCursor("from"));
        const endOffset = editor.posToOffset(editor.getCursor("to"));
        if (visibleText.slice(startOffset, endOffset).trim().length === 0) {
            return undefined;
        }
        return (0, note_selection_context_1.createNoteSelectionContext)({
            filePath: source.filePath,
            fileName: source.fileName,
            basis: "note-source-v1",
            visibleText,
            sourceText: visibleText,
            startOffset,
            endOffset
        });
    }
    if (domSelection === null ||
        domSelection.rangeCount === 0 ||
        domSelection.isCollapsed) {
        return undefined;
    }
    const range = domSelection.getRangeAt(0);
    if (!source.contentEl.contains(range.startContainer) ||
        !source.contentEl.contains(range.endContainer)) {
        return undefined;
    }
    const map = (0, rendered_selection_1.mapRenderedText)(source.contentEl);
    const offsets = (0, rendered_selection_1.offsetsForDomRange)(map, range);
    if (offsets === undefined ||
        map.text.slice(offsets.start, offsets.end).trim().length === 0) {
        return undefined;
    }
    let sourceText;
    try {
        sourceText = await source.loadSourceText?.();
    }
    catch {
        // The rendered note text is still a stable fallback if the file changes mid-capture.
    }
    return (0, note_selection_context_1.createNoteSelectionContext)({
        filePath: source.filePath,
        fileName: source.fileName,
        basis: "note-rendered-text-v1",
        visibleText: map.text,
        ...(sourceText === undefined ? {} : { sourceText }),
        startOffset: offsets.start,
        endOffset: offsets.end
    });
}
function eventNode(event) {
    const target = event.target;
    return target !== null && typeof target === "object" && "nodeType" in target
        ? target
        : undefined;
}
function eventElement(node) {
    return node.nodeType === Node.ELEMENT_NODE
        ? node
        : node.parentElement ?? undefined;
}
function isTreeTalkTarget(node) {
    return (eventElement(node)?.closest(".treetalk-root, .treetalk-workspace, .treetalk-view-content") !== null);
}
function installNoteSelectionCapture(options) {
    let keyboardTimer;
    const capture = async (event) => {
        const target = eventNode(event);
        if (target === undefined || isTreeTalkTarget(target))
            return;
        const source = options.getActiveSource();
        if (source === undefined || !source.contentEl.contains(target))
            return;
        const snapshot = options.store.getSnapshot();
        if (snapshot === undefined ||
            snapshot.status !== "active" ||
            !(options.store.canMutate?.() ?? true)) {
            return;
        }
        const conversationId = snapshot.id;
        const nodeId = snapshot.currentNodeId;
        const context = await (options.captureSelection?.(source) ?? captureNoteSelection(source));
        if (context === undefined)
            return;
        try {
            options.store.update((current) => {
                if (current.id !== conversationId ||
                    current.currentNodeId !== nodeId ||
                    current.status !== "active") {
                    return current;
                }
                return (0, tree_commands_1.addSelectionToDraft)(current, nodeId, context, options.now());
            });
        }
        catch {
            // The active tab can become read-only or close while hashing the selection.
        }
    };
    const onMouseUp = (event) => {
        void capture(event);
    };
    const onKeyUp = (event) => {
        if (!event.shiftKey)
            return;
        if (keyboardTimer !== undefined)
            clearTimeout(keyboardTimer);
        keyboardTimer = setTimeout(() => {
            keyboardTimer = undefined;
            void capture(event);
        }, 120);
    };
    options.document.addEventListener("mouseup", onMouseUp);
    options.document.addEventListener("keyup", onKeyUp);
    return () => {
        if (keyboardTimer !== undefined)
            clearTimeout(keyboardTimer);
        options.document.removeEventListener("mouseup", onMouseUp);
        options.document.removeEventListener("keyup", onKeyUp);
    };
}

},
"history/history-delete-service.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HistoryDeleteService = void 0;
class HistoryDeleteService {
    folders;
    index;
    closeOpenHistory;
    reportCleanupErrors;
    constructor(folders, index, closeOpenHistory, reportCleanupErrors = () => undefined) {
        this.folders = folders;
        this.index = index;
        this.closeOpenHistory = closeOpenHistory;
        this.reportCleanupErrors = reportCleanupErrors;
    }
    async delete(entry) {
        await this.closeOpenHistory(entry.id);
        await this.folders.removeFolder(entry.folder);
        this.index.remove(entry.id);
        try {
            await this.index.rebuild();
        }
        catch (error) {
            this.reportCleanupErrors([error]);
        }
        return this.index.entries();
    }
}
exports.HistoryDeleteService = HistoryDeleteService;

},
"history/history-index.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HistoryIndex = void 0;
const schema_1 = require("../domain/schema");
const checksum_1 = require("../storage/checksum");
class HistoryIndex {
    vault;
    historyRoot;
    indexed = [];
    constructor(vault, historyRoot) {
        this.vault = vault;
        this.historyRoot = historyRoot;
    }
    async rebuild() {
        const entries = [];
        for (const path of await this.vault.list(`${this.historyRoot}/`)) {
            const relative = path.slice(`${this.historyRoot}/`.length);
            const parts = relative.split("/");
            if (parts.length !== 2 || parts[1] !== "tree.json")
                continue;
            try {
                const conversation = (0, schema_1.parseConversation)(JSON.parse(await this.vault.read(path)));
                if (conversation.status !== "archived" ||
                    !(await (0, checksum_1.verifyConversationChecksum)(conversation))) {
                    continue;
                }
                entries.push({
                    id: conversation.id,
                    title: conversation.title,
                    folder: path.slice(0, -"/tree.json".length),
                    updatedAt: conversation.updatedAt
                });
            }
            catch {
                // Corrupt canonical files remain available for repository backup recovery.
            }
        }
        entries.sort((left, right) => right.updatedAt.localeCompare(left.updatedAt));
        this.indexed = entries;
    }
    entries() {
        return this.indexed.map((entry) => ({ ...entry }));
    }
    remove(conversationId) {
        this.indexed = this.indexed.filter((entry) => entry.id !== conversationId);
    }
}
exports.HistoryIndex = HistoryIndex;

},
"history/history-manager-modal.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HistoryManagerModal = void 0;
exports.renderHistoryManager = renderHistoryManager;
exports.confirmHistoryDeletion = confirmHistoryDeletion;
const obsidian_1 = require("obsidian");
function renderHistoryManager(container, initialEntries, actions) {
    let entries = initialEntries.map((entry) => ({ ...entry }));
    let query = "";
    let disposed = false;
    const search = document.createElement("input");
    search.type = "search";
    search.className = "treetalk-history-search";
    search.placeholder = "搜索历史对话…";
    const list = document.createElement("div");
    list.className = "treetalk-history-list";
    const renderRows = () => {
        if (disposed)
            return;
        list.replaceChildren();
        const normalized = query.trim().toLocaleLowerCase();
        const visible = entries.filter((entry) => normalized.length === 0 ||
            entry.title.toLocaleLowerCase().includes(normalized));
        for (const entry of visible) {
            const row = document.createElement("div");
            row.className = "treetalk-history-row";
            row.dataset.conversationId = entry.id;
            row.setAttribute("role", "group");
            row.setAttribute("aria-label", entry.title);
            const open = document.createElement("button");
            open.type = "button";
            open.className = "treetalk-history-open";
            open.textContent = entry.title;
            open.addEventListener("click", () => {
                void actions.open(entry);
            });
            const remove = document.createElement("button");
            remove.type = "button";
            remove.className = "treetalk-history-delete";
            remove.setAttribute("aria-label", `删除历史对话 ${entry.title}`);
            (0, obsidian_1.setIcon)(remove, "trash-2");
            remove.addEventListener("click", (event) => {
                event.stopPropagation();
                void (async () => {
                    if (!(await actions.confirmDelete(entry)))
                        return;
                    remove.disabled = true;
                    try {
                        entries = await actions.delete(entry);
                        renderRows();
                    }
                    catch (error) {
                        remove.disabled = false;
                        actions.reportError(error);
                    }
                })();
            });
            row.append(open, remove);
            list.append(row);
        }
        if (visible.length === 0) {
            const empty = document.createElement("div");
            empty.className = "treetalk-history-empty";
            empty.textContent = "没有匹配的历史对话";
            list.append(empty);
        }
    };
    const onSearch = () => {
        query = search.value;
        renderRows();
    };
    search.addEventListener("input", onSearch);
    container.replaceChildren(search, list);
    renderRows();
    return () => {
        disposed = true;
        search.removeEventListener("input", onSearch);
    };
}
class HistoryManagerModal extends obsidian_1.Modal {
    entries;
    actions;
    cleanup;
    constructor(app, entries, actions) {
        super(app);
        this.entries = entries;
        this.actions = actions;
    }
    onOpen() {
        this.cleanup = renderHistoryManager(this.contentEl, this.entries, this.actions);
    }
    onClose() {
        this.cleanup?.();
        this.cleanup = undefined;
        this.contentEl.replaceChildren();
    }
}
exports.HistoryManagerModal = HistoryManagerModal;
class HistoryDeleteConfirmModal extends obsidian_1.Modal {
    entry;
    settle;
    settled = false;
    constructor(app, entry, settle) {
        super(app);
        this.entry = entry;
        this.settle = settle;
    }
    onOpen() {
        const title = document.createElement("h3");
        title.textContent = "永久删除历史对话？";
        const description = document.createElement("p");
        description.textContent = `“${this.entry.title}”删除后无法恢复。`;
        const actions = document.createElement("div");
        actions.className = "treetalk-history-confirm-actions";
        const cancel = document.createElement("button");
        cancel.type = "button";
        cancel.textContent = "取消";
        cancel.addEventListener("click", () => this.finish(false));
        const confirm = document.createElement("button");
        confirm.type = "button";
        confirm.className = "mod-warning";
        confirm.textContent = "永久删除";
        confirm.addEventListener("click", () => this.finish(true));
        actions.append(cancel, confirm);
        this.contentEl.replaceChildren(title, description, actions);
    }
    onClose() {
        if (!this.settled)
            this.finish(false, false);
        this.contentEl.replaceChildren();
    }
    finish(confirmed, close = true) {
        if (this.settled)
            return;
        this.settled = true;
        this.settle(confirmed);
        if (close)
            this.close();
    }
}
function confirmHistoryDeletion(app, entry) {
    return new Promise((resolve) => {
        new HistoryDeleteConfirmModal(app, entry, resolve).open();
    });
}

},
"knowledge/capture-service.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KnowledgeCaptureService = void 0;
const types_1 = require("../domain/types");
const markdown_branch_links_1 = require("./markdown-branch-links");
function normalizeFolder(value) {
    return value.replace(/\\/gu, "/").replace(/^\/+|\/+$/gu, "");
}
function safeFileStem(value) {
    const safe = value
        .replace(/[\\/:*?"<>|#]/gu, "-")
        .replaceAll("[", "-")
        .replaceAll("]", "-")
        .replace(/\p{Cc}/gu, " ")
        .replace(/\s+/gu, " ")
        .replace(/[. ]+$/gu, "")
        .trim()
        .slice(0, 60)
        .trim();
    return safe.length > 0 ? safe : "未命名";
}
function timestampForFile(now) {
    return now.replace(/[-:]/gu, "").replace("T", "-").slice(0, 15);
}
function requireNode(conversation, nodeId) {
    const node = conversation.nodes[nodeId];
    if (node === undefined)
        throw new Error(`Node not found: ${nodeId}`);
    return node;
}
function requireMessage(node, messageId) {
    const message = node.messages.find((entry) => entry.id === messageId);
    if (message === undefined)
        throw new Error(`Message not found: ${messageId}`);
    return message;
}
function nodeTitle(node) {
    const title = node.title.trim();
    if (title.length > 0)
        return title;
    const question = node.messages.find((message) => message.role === "user")
        ?.content.trim();
    return question !== undefined && question.length > 0 ? question : "未命名";
}
function hasStreamingResponse(conversation) {
    return Object.values(conversation.nodes).some((node) => node.messages.some((message) => message.role === "assistant" && message.status === "streaming"));
}
function orderedNodeIds(conversation) {
    const ordered = [];
    const seen = new Set();
    const visit = (nodeId) => {
        if (seen.has(nodeId))
            return;
        seen.add(nodeId);
        ordered.push(nodeId);
        const node = conversation.nodes[nodeId];
        if (node === undefined)
            return;
        for (const childId of node.childIds)
            visit(childId);
    };
    visit(conversation.rootNodeId);
    for (const nodeId of Object.keys(conversation.nodes))
        visit(nodeId);
    return ordered;
}
async function uniqueFolder(vault, root, stem) {
    const normalizedRoot = normalizeFolder(root);
    let suffix = 1;
    let folder = `${normalizedRoot}/${stem}`;
    while ((await vault.list(`${folder}/`)).length > 0) {
        suffix += 1;
        folder = `${normalizedRoot}/${stem}-${String(suffix)}`;
    }
    return folder;
}
async function uniquePath(vault, folder, stem, reserved) {
    let suffix = 1;
    let path = `${folder}/${stem}.md`;
    while (reserved.has(path) || (await vault.exists(path))) {
        suffix += 1;
        path = `${folder}/${stem} ${String(suffix)}.md`;
    }
    reserved.add(path);
    return path;
}
async function buildTreeExportPlan(vault, conversation, capturedAt, treeFolder) {
    const conversationStem = safeFileStem(conversation.title);
    const folder = await uniqueFolder(vault, treeFolder, `${timestampForFile(capturedAt)}-${conversationStem}`);
    const reserved = new Set();
    const indexPath = await uniquePath(vault, folder, "节点列表", reserved);
    const nodes = {};
    for (const nodeId of orderedNodeIds(conversation)) {
        const node = requireNode(conversation, nodeId);
        const title = nodeTitle(node);
        nodes[nodeId] = {
            nodeId,
            title,
            path: await uniquePath(vault, folder, safeFileStem(title), reserved)
        };
    }
    return { folder, indexPath, nodes };
}
function addUniqueLink(target, link) {
    if (!target.some((entry) => entry.path === link.path && entry.title === link.title)) {
        target.push(link);
    }
}
function contextKey(source, context) {
    return [
        source,
        String(context.startOffset),
        String(context.endOffset),
        context.quote
    ].join("\u0000");
}
function collectBranchGroups(conversation, plan) {
    const messageGroups = new Map();
    const noteGroups = new Map();
    const fallbackByNode = new Map();
    for (const childId of orderedNodeIds(conversation)) {
        const child = conversation.nodes[childId];
        const record = plan.nodes[childId];
        if (child === undefined || record === undefined)
            continue;
        const link = { path: record.path, title: record.title };
        let linkedAtParentSelection = false;
        for (const message of child.messages) {
            if (message.role !== "user")
                continue;
            for (const context of message.selectionContexts ?? []) {
                if ((0, types_1.isMessageSelectionContext)(context)) {
                    const key = contextKey(`${context.sourceNodeId}:${context.messageId}`, context);
                    const group = messageGroups.get(key) ?? {
                        sourceNodeId: context.sourceNodeId,
                        sourceMessageId: context.messageId,
                        context,
                        links: []
                    };
                    addUniqueLink(group.links, link);
                    messageGroups.set(key, group);
                    if (context.sourceNodeId === child.parentId) {
                        linkedAtParentSelection = true;
                    }
                }
                else if ((0, types_1.isNoteSelectionContext)(context)) {
                    const key = contextKey(context.filePath, context);
                    const group = noteGroups.get(key) ?? {
                        sourcePath: context.filePath,
                        context,
                        links: []
                    };
                    addUniqueLink(group.links, link);
                    noteGroups.set(key, group);
                }
            }
        }
        if (child.parentId !== null && !linkedAtParentSelection) {
            const links = fallbackByNode.get(child.parentId) ?? [];
            addUniqueLink(links, link);
            fallbackByNode.set(child.parentId, links);
        }
    }
    return {
        messageGroups: [...messageGroups.values()],
        noteGroups: [...noteGroups.values()],
        fallbackByNode
    };
}
function applyMessageBranchLinks(conversation, groups, fallbackByNode) {
    const insertionsByMessage = new Map();
    for (const group of groups) {
        const sourceMessage = conversation.nodes[group.sourceNodeId]?.messages.find((message) => message.id === group.sourceMessageId);
        if (sourceMessage === undefined) {
            const links = fallbackByNode.get(group.sourceNodeId) ?? [];
            for (const link of group.links)
                addUniqueLink(links, link);
            fallbackByNode.set(group.sourceNodeId, links);
            continue;
        }
        const anchor = (0, markdown_branch_links_1.resolveMarkdownAnchor)(sourceMessage.content, group.context);
        if (anchor === undefined) {
            const links = fallbackByNode.get(group.sourceNodeId) ?? [];
            for (const link of group.links)
                addUniqueLink(links, link);
            fallbackByNode.set(group.sourceNodeId, links);
            continue;
        }
        const key = `${group.sourceNodeId}\u0000${group.sourceMessageId}`;
        const insertions = insertionsByMessage.get(key) ?? [];
        insertions.push({ anchor, links: group.links });
        insertionsByMessage.set(key, insertions);
    }
    const contentByNode = {};
    for (const [key, insertions] of insertionsByMessage) {
        const separator = key.indexOf("\u0000");
        const nodeId = key.slice(0, separator);
        const messageId = key.slice(separator + 1);
        const message = conversation.nodes[nodeId]?.messages.find((entry) => entry.id === messageId);
        if (message === undefined)
            continue;
        const byMessage = contentByNode[nodeId] ?? {};
        byMessage[messageId] = (0, markdown_branch_links_1.insertMarkdownLinks)(message.content, insertions);
        contentByNode[nodeId] = byMessage;
    }
    return contentByNode;
}
function renderIndexMarkdown(conversation, plan) {
    const lines = ["# 节点列表", ""];
    const seen = new Set();
    const visit = (nodeId, depth) => {
        if (seen.has(nodeId))
            return;
        seen.add(nodeId);
        const node = conversation.nodes[nodeId];
        const record = plan.nodes[nodeId];
        if (node === undefined || record === undefined)
            return;
        lines.push(`${"  ".repeat(depth)}- ${(0, markdown_branch_links_1.markdownWikiLink)(record.path, record.title)}`);
        for (const childId of node.childIds)
            visit(childId, depth + 1);
    };
    visit(conversation.rootNodeId, 0);
    for (const nodeId of orderedNodeIds(conversation)) {
        if (!seen.has(nodeId))
            visit(nodeId, 0);
    }
    return `${lines.join("\n")}\n`;
}
function renderNodeMarkdown(node, title, messageContentById, fallbackLinks) {
    const sections = [`# ${title}`];
    for (const message of node.messages) {
        const label = message.role === "user" ? "提问" : "回答";
        sections.push(`## ${label}\n\n${messageContentById?.[message.id] ?? message.content}`);
    }
    if (fallbackLinks.length > 0) {
        sections.push(`## 分支\n\n${fallbackLinks
            .map((link) => `- ${(0, markdown_branch_links_1.markdownWikiLink)(link.path, link.title)}`)
            .join("\n")}`);
    }
    return `${sections.join("\n\n")}\n`;
}
async function updateSourceNotes(vault, groups) {
    const byPath = new Map();
    for (const group of groups) {
        const entries = byPath.get(group.sourcePath) ?? [];
        entries.push(group);
        byPath.set(group.sourcePath, entries);
    }
    for (const [path, entries] of byPath) {
        try {
            if (!(await vault.exists(path)))
                continue;
            const original = await vault.read(path);
            const insertions = [];
            for (const entry of entries) {
                const anchor = (0, markdown_branch_links_1.resolveMarkdownAnchor)(original, entry.context);
                if (anchor !== undefined) {
                    insertions.push({ anchor, links: entry.links });
                }
            }
            if (insertions.length === 0)
                continue;
            const updated = (0, markdown_branch_links_1.insertMarkdownLinks)(original, insertions);
            if (updated !== original)
                await vault.write(path, updated);
        }
        catch {
            // Source-note links are best-effort and never make the export fail.
        }
    }
}
class KnowledgeCaptureService {
    vault;
    knowledgeFolder;
    treeCaptureFolder;
    constructor(vault, knowledgeFolder, treeCaptureFolder = knowledgeFolder) {
        this.vault = vault;
        this.knowledgeFolder = knowledgeFolder;
        this.treeCaptureFolder = treeCaptureFolder;
    }
    async capture(request, capturedAt) {
        const scope = request.scope;
        if (scope !== "tree" && scope !== "answer") {
            throw new Error("Unsupported capture scope");
        }
        if (request.scope === "answer") {
            const node = requireNode(request.conversation, request.nodeId);
            const message = requireMessage(node, request.messageId);
            if (message.role !== "assistant") {
                throw new Error("Only assistant answers can be captured");
            }
            const folder = normalizeFolder(this.knowledgeFolder);
            const title = nodeTitle(node);
            const stem = safeFileStem(title);
            let suffix = 1;
            let path = `${folder}/${stem}.md`;
            while (await this.vault.exists(path)) {
                suffix += 1;
                path = `${folder}/${stem} ${String(suffix)}.md`;
            }
            await this.vault.write(path, `# ${title}\n\n${message.content}\n`);
            return path;
        }
        if (hasStreamingResponse(request.conversation)) {
            throw new Error("Cannot capture a tree while an assistant response is streaming");
        }
        const plan = await buildTreeExportPlan(this.vault, request.conversation, capturedAt, this.treeCaptureFolder);
        const { messageGroups, noteGroups, fallbackByNode } = collectBranchGroups(request.conversation, plan);
        const messageContentByNode = applyMessageBranchLinks(request.conversation, messageGroups, fallbackByNode);
        await this.vault.write(plan.indexPath, renderIndexMarkdown(request.conversation, plan));
        for (const nodeId of orderedNodeIds(request.conversation)) {
            const node = requireNode(request.conversation, nodeId);
            const record = plan.nodes[nodeId];
            if (record === undefined)
                continue;
            await this.vault.write(record.path, renderNodeMarkdown(node, record.title, messageContentByNode[nodeId], fallbackByNode.get(nodeId) ?? []));
        }
        await updateSourceNotes(this.vault, noteGroups);
        return plan.indexPath;
    }
}
exports.KnowledgeCaptureService = KnowledgeCaptureService;

},
"knowledge/excerpt-drag.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TREETALK_EXCERPT_MIME = void 0;
exports.encodeSourceAnchor = encodeSourceAnchor;
exports.decodeSourceAnchor = decodeSourceAnchor;
exports.serializeExcerptPayload = serializeExcerptPayload;
exports.parseExcerptPayload = parseExcerptPayload;
exports.writeExcerptDragData = writeExcerptDragData;
exports.renderExcerptCallout = renderExcerptCallout;
exports.TREETALK_EXCERPT_MIME = "application/x-treetalk-excerpt+json";
function nonEmptyString(value) {
    return typeof value === "string" && value.trim().length > 0;
}
function isIntegerOffset(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}
function validatedAnchor(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
        return undefined;
    }
    const source = value;
    if (!nonEmptyString(source.messageId) ||
        !nonEmptyString(source.sourceNodeId) ||
        (source.sourceRole !== "user" && source.sourceRole !== "assistant") ||
        source.basis !== "rendered-text-v1" ||
        !isIntegerOffset(source.startOffset) ||
        !isIntegerOffset(source.endOffset) ||
        source.startOffset >= source.endOffset ||
        !nonEmptyString(source.quote) ||
        typeof source.prefix !== "string" ||
        typeof source.suffix !== "string" ||
        !nonEmptyString(source.contentHash) ||
        (source.visibleQuote !== undefined &&
            typeof source.visibleQuote !== "string")) {
        return undefined;
    }
    const anchor = {
        messageId: source.messageId,
        sourceNodeId: source.sourceNodeId,
        sourceRole: source.sourceRole,
        basis: "rendered-text-v1",
        startOffset: source.startOffset,
        endOffset: source.endOffset,
        quote: source.quote,
        prefix: source.prefix,
        suffix: source.suffix,
        contentHash: source.contentHash
    };
    if (source.visibleQuote !== undefined) {
        anchor.visibleQuote = source.visibleQuote;
    }
    return anchor;
}
function validatedBase(source) {
    if (!nonEmptyString(source.conversationId) ||
        !nonEmptyString(source.conversationTitle) ||
        !nonEmptyString(source.nodeId) ||
        !nonEmptyString(source.nodeTitle) ||
        !nonEmptyString(source.messageId) ||
        (source.sourceRole !== "user" && source.sourceRole !== "assistant") ||
        !nonEmptyString(source.quote)) {
        return undefined;
    }
    return {
        conversationId: source.conversationId,
        conversationTitle: source.conversationTitle,
        nodeId: source.nodeId,
        nodeTitle: source.nodeTitle,
        messageId: source.messageId,
        sourceRole: source.sourceRole,
        quote: source.quote
    };
}
function validatedPayload(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
        return undefined;
    }
    const source = value;
    const base = validatedBase(source);
    if (base === undefined)
        return undefined;
    if (source.version === 1) {
        return { version: 1, ...base };
    }
    if (source.version !== 2)
        return undefined;
    const anchor = validatedAnchor(source.anchor);
    if (anchor === undefined ||
        anchor.messageId !== base.messageId ||
        anchor.sourceNodeId !== base.nodeId ||
        anchor.sourceRole !== base.sourceRole) {
        return undefined;
    }
    return { version: 2, ...base, anchor };
}
function bytesToBinary(bytes) {
    const chunks = [];
    const chunkSize = 0x8000;
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
        chunks.push(String.fromCharCode(...bytes.subarray(offset, offset + chunkSize)));
    }
    return chunks.join("");
}
function binaryToBytes(binary) {
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
}
function encodeSourceAnchor(anchor) {
    const validated = validatedAnchor(anchor);
    if (validated === undefined) {
        throw new TypeError("TreeTalk selection anchor is invalid");
    }
    const json = JSON.stringify(validated);
    return btoa(bytesToBinary(new TextEncoder().encode(json)))
        .replace(/\+/gu, "-")
        .replace(/\//gu, "_")
        .replace(/=+$/gu, "");
}
function decodeSourceAnchor(value) {
    if (!/^[A-Za-z0-9_-]+$/u.test(value))
        return undefined;
    try {
        const normalized = value.replace(/-/gu, "+").replace(/_/gu, "/");
        const padded = normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), "=");
        const json = new TextDecoder().decode(binaryToBytes(atob(padded)));
        return validatedAnchor(JSON.parse(json));
    }
    catch {
        return undefined;
    }
}
function serializeExcerptPayload(payload) {
    const validated = validatedPayload(payload);
    if (validated === undefined) {
        throw new TypeError("TreeTalk excerpt payload is invalid");
    }
    return JSON.stringify(validated);
}
function parseExcerptPayload(value) {
    try {
        return validatedPayload(JSON.parse(value));
    }
    catch {
        return undefined;
    }
}
function writeExcerptDragData(dataTransfer, payload) {
    dataTransfer.setData(exports.TREETALK_EXCERPT_MIME, serializeExcerptPayload(payload));
    dataTransfer.setData("text/plain", payload.quote);
}
function renderExcerptCallout(payload) {
    const validated = validatedPayload(payload);
    if (validated === undefined) {
        throw new TypeError("TreeTalk excerpt payload is invalid");
    }
    const parameters = new URLSearchParams({
        conversationId: validated.conversationId,
        nodeId: validated.nodeId,
        messageId: validated.messageId
    });
    if (validated.version === 2) {
        parameters.set("anchor", encodeSourceAnchor(validated.anchor));
    }
    const quoteLines = validated.quote
        .replace(/\r\n?/gu, "\n")
        .split("\n")
        .map((line) => (line.length === 0 ? ">" : `> ${line}`));
    return [
        "> [!quote] TreeTalk 摘录",
        ...quoteLines,
        ">",
        `> [返回 TreeTalk 来源](obsidian://treetalk-open?${parameters.toString()})`
    ].join("\n");
}

},
"knowledge/markdown-branch-links.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveMarkdownAnchor = resolveMarkdownAnchor;
exports.markdownWikiLink = markdownWikiLink;
exports.insertMarkdownLinks = insertMarkdownLinks;
const balanced_markdown_compressor_1 = require("../domain/balanced-markdown-compressor");
const selection_anchor_1 = require("../domain/selection-anchor");
const STRUCTURAL_BLOCKS = new Set([
    "heading",
    "list",
    "quote",
    "table",
    "code",
    "math"
]);
function exactMatches(content, quote) {
    if (quote.length === 0)
        return [];
    const matches = [];
    let from = 0;
    while (from <= content.length - quote.length) {
        const index = content.indexOf(quote, from);
        if (index < 0)
            break;
        matches.push(index);
        from = index + Math.max(1, quote.length);
    }
    return matches;
}
function asSelectionAnchor(context) {
    if (!("sourceType" in context))
        return context;
    return {
        messageId: `note:${context.filePath}`,
        sourceNodeId: `note:${context.filePath}`,
        sourceRole: "user",
        basis: "rendered-text-v1",
        startOffset: context.startOffset,
        endOffset: context.endOffset,
        quote: context.quote,
        prefix: context.prefix,
        suffix: context.suffix,
        contentHash: context.contentHash
    };
}
function resolveMarkdownAnchor(content, context) {
    const rawMatches = exactMatches(content, context.quote);
    if (rawMatches.length === 1) {
        const start = rawMatches[0];
        return start === undefined
            ? undefined
            : { start, end: start + context.quote.length };
    }
    const anchor = asSelectionAnchor(context);
    if (rawMatches.length > 1) {
        const resolved = (0, selection_anchor_1.resolveSelectionAnchor)(content, anchor);
        return resolved.status === "resolved"
            ? { start: resolved.start, end: resolved.end }
            : undefined;
    }
    const visibleQuote = "visibleQuote" in context
        ? context.visibleQuote ?? context.quote
        : context.quote;
    const visibleMatches = exactMatches(content, visibleQuote);
    if (visibleMatches.length === 1) {
        const start = visibleMatches[0];
        return start === undefined
            ? undefined
            : { start, end: start + visibleQuote.length };
    }
    const resolved = (0, selection_anchor_1.resolveSelectionAnchor)(content, anchor);
    return resolved.status === "resolved"
        ? { start: resolved.start, end: resolved.end }
        : undefined;
}
function notePathWithoutExtension(path) {
    return path.replace(/\\/gu, "/").replace(/\.md$/iu, "");
}
function markdownWikiLink(path, title) {
    const target = notePathWithoutExtension(path).replace(/\|/gu, "-");
    const alias = title.replace(/\|/gu, "-").replace(/[\r\n]+/gu, " ").trim();
    return `[[${target}|${alias.length > 0 ? alias : "未命名"}]]`;
}
function uniqueLinks(links) {
    const seen = new Set();
    const result = [];
    for (const link of links) {
        const rendered = markdownWikiLink(link.path, link.title);
        if (seen.has(rendered))
            continue;
        seen.add(rendered);
        result.push(link);
    }
    return result;
}
function lineBounds(content, anchor) {
    const start = content.lastIndexOf("\n", Math.max(0, anchor.start - 1)) + 1;
    const endIndex = content.indexOf("\n", anchor.end);
    return { start, end: endIndex < 0 ? content.length : endIndex };
}
function isEscaped(value, index) {
    let slashes = 0;
    for (let cursor = index - 1; cursor >= 0 && value.charAt(cursor) === "\\"; cursor -= 1) {
        slashes += 1;
    }
    return slashes % 2 === 1;
}
function insideBacktickSpan(content, anchor, start, end) {
    let cursor = start;
    while (cursor < end) {
        if (content.charAt(cursor) !== "`" || isEscaped(content, cursor)) {
            cursor += 1;
            continue;
        }
        let markerEnd = cursor + 1;
        while (markerEnd < end && content.charAt(markerEnd) === "`") {
            markerEnd += 1;
        }
        const marker = content.slice(cursor, markerEnd);
        const close = content.indexOf(marker, markerEnd);
        if (close < 0 || close >= end)
            return false;
        if (anchor.start >= markerEnd && anchor.end <= close)
            return true;
        cursor = close + marker.length;
    }
    return false;
}
function insideDollarSpan(content, anchor, start, end) {
    let cursor = start;
    while (cursor < end) {
        if (content.charAt(cursor) !== "$" || isEscaped(content, cursor)) {
            cursor += 1;
            continue;
        }
        const marker = content.charAt(cursor + 1) === "$" ? "$$" : "$";
        const openEnd = cursor + marker.length;
        let close = openEnd;
        while (close < end) {
            close = content.indexOf(marker, close);
            if (close < 0 || close >= end)
                return false;
            if (!isEscaped(content, close))
                break;
            close += marker.length;
        }
        if (close < 0 || close >= end)
            return false;
        if (anchor.start >= openEnd && anchor.end <= close)
            return true;
        cursor = close + marker.length;
    }
    return false;
}
function paragraphHasProtectedInlineSyntax(content, anchor, start, end) {
    return (insideBacktickSpan(content, anchor, start, end) ||
        insideDollarSpan(content, anchor, start, end));
}
function followingLineEnd(content, offset) {
    let cursor = offset;
    while (cursor < content.length && /\s/u.test(content.charAt(cursor))) {
        cursor += 1;
    }
    if (cursor >= content.length)
        return content.length;
    const newline = content.indexOf("\n", cursor);
    return newline < 0 ? content.length : newline;
}
function placementFor(content, anchor) {
    const parsed = (0, balanced_markdown_compressor_1.parseStructuredMarkdown)(content);
    if (parsed.ok) {
        const block = parsed.blocks.find((candidate) => anchor.start >= candidate.startOffset &&
            anchor.end <= candidate.endOffset);
        if (block !== undefined &&
            (STRUCTURAL_BLOCKS.has(block.kind) ||
                (block.kind === "paragraph" &&
                    paragraphHasProtectedInlineSyntax(content, anchor, block.startOffset, block.endOffset)))) {
            return {
                offset: block.endOffset,
                standalone: true,
                scopeStart: block.startOffset,
                scopeEnd: followingLineEnd(content, block.endOffset)
            };
        }
    }
    const line = lineBounds(content, anchor);
    return {
        offset: anchor.end,
        standalone: false,
        scopeStart: line.start,
        scopeEnd: line.end
    };
}
function newlineFor(content) {
    return content.includes("\r\n") ? "\r\n" : "\n";
}
function insertInline(content, offset, rendered) {
    const before = content.slice(0, offset);
    const after = content.slice(offset);
    const beforeSpacer = /\s$/u.test(before) ? "" : " ";
    const afterSpacer = after.length === 0 || /^(?:\s|[，。！？、；：,.!?;:)])/u.test(after)
        ? ""
        : " ";
    return `${before}${beforeSpacer}${rendered}${afterSpacer}${after}`;
}
function insertStandalone(content, offset, rendered) {
    const newline = newlineFor(content);
    const before = content.slice(0, offset);
    const after = content.slice(offset);
    const beforeSeparator = new RegExp(`(?:${newline}){2}$`, "u").test(before)
        ? ""
        : new RegExp(`${newline}$`, "u").test(before)
            ? newline
            : `${newline}${newline}`;
    const afterSeparator = new RegExp(`^(?:${newline}){2}`, "u").test(after)
        ? ""
        : new RegExp(`^${newline}`, "u").test(after)
            ? newline
            : after.length > 0
                ? `${newline}${newline}`
                : "";
    return `${before}${beforeSeparator}${rendered}${afterSeparator}${after}`;
}
function placementKey(placement) {
    return [
        String(placement.offset),
        placement.standalone ? "block" : "inline",
        String(placement.scopeStart),
        String(placement.scopeEnd)
    ].join(":");
}
function insertMarkdownLinks(content, insertions) {
    const grouped = new Map();
    for (const insertion of insertions) {
        const placement = placementFor(content, insertion.anchor);
        const key = placementKey(placement);
        const group = grouped.get(key) ?? { ...placement, links: [] };
        group.links.push(...insertion.links);
        grouped.set(key, group);
    }
    const placements = [...grouped.values()]
        .map((placement) => {
        const scope = content.slice(placement.scopeStart, placement.scopeEnd);
        return {
            ...placement,
            links: uniqueLinks(placement.links).filter((link) => !scope.includes(markdownWikiLink(link.path, link.title)))
        };
    })
        .filter((placement) => placement.links.length > 0)
        .sort((left, right) => right.offset - left.offset);
    return placements.reduce((current, placement) => {
        const rendered = placement.links
            .map((link) => markdownWikiLink(link.path, link.title))
            .join(" ");
        return placement.standalone
            ? insertStandalone(current, placement.offset, rendered)
            : insertInline(current, placement.offset, rendered);
    }, content);
}

},
"main.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMMAND_IDS = exports.PLUGIN_ID = void 0;
const obsidian_1 = require("obsidian");
const archive_service_1 = require("./archive/archive-service");
const lifecycle_queue_1 = require("./archive/lifecycle-queue");
const lifecycle_reconciler_1 = require("./archive/lifecycle-reconciler");
const context_engine_1 = require("./domain/context-engine");
const conversation_factory_1 = require("./domain/conversation-factory");
const context_persistence_1 = require("./domain/context-persistence");
const full_context_protocol_1 = require("./domain/full-context-protocol");
const markdown_compatibility_1 = require("./domain/markdown-compatibility");
const tree_commands_1 = require("./domain/tree-commands");
const excerpt_drop_extension_1 = require("./editor/excerpt-drop-extension");
const note_selection_capture_1 = require("./editor/note-selection-capture");
const history_index_1 = require("./history/history-index");
const history_delete_service_1 = require("./history/history-delete-service");
const history_manager_modal_1 = require("./history/history-manager-modal");
const capture_service_1 = require("./knowledge/capture-service");
const source_highlight_store_1 = require("./navigation/source-highlight-store");
const source_link_handler_1 = require("./navigation/source-link-handler");
const active_response_requests_1 = require("./providers/active-response-requests");
const provider_registry_1 = require("./providers/provider-registry");
const node_summary_coordinator_1 = require("./providers/node-summary-coordinator");
const streaming_transport_1 = require("./providers/streaming-transport");
const transient_usage_store_1 = require("./providers/transient-usage-store");
const transient_response_status_store_1 = require("./providers/transient-response-status-store");
const conversation_repository_1 = require("./storage/conversation-repository");
const obsidian_vault_port_1 = require("./storage/obsidian-vault-port");
const private_paths_1 = require("./storage/private-paths");
const persistence_scheduler_1 = require("./storage/persistence-scheduler");
const runtime_private_storage_1 = require("./storage/runtime-private-storage");
const session_persistence_1 = require("./storage/session-persistence");
const active_conversation_store_1 = require("./tabs/active-conversation-store");
const conversation_tabs_store_1 = require("./tabs/conversation-tabs-store");
const plugin_data_1 = require("./tabs/plugin-data");
const tab_lifecycle_controller_1 = require("./tabs/tab-lifecycle-controller");
const tab_response_router_1 = require("./tabs/tab-response-router");
const tab_workspace_operations_1 = require("./tabs/tab-workspace-operations");
const workspace_state_1 = require("./tabs/workspace-state");
const obsidian_views_1 = require("./views/obsidian-views");
const sidebar_workspace_coordinator_1 = require("./views/sidebar-workspace-coordinator");
exports.PLUGIN_ID = "treetalk";
exports.COMMAND_IDS = {
    close: "close-current-conversation-tab",
    new: "new-conversation-tab",
    next: "next-conversation-tab",
    previous: "previous-conversation-tab"
};
const SECRET_ID = "treetalk-api-key";
function mergeUsage(current, next) {
    const promptTokens = next.promptTokens ?? current?.promptTokens;
    const completionTokens = next.completionTokens ?? current?.completionTokens;
    const cacheHitTokens = next.cacheHitTokens ?? current?.cacheHitTokens;
    const cacheMissTokens = next.cacheMissTokens ?? current?.cacheMissTokens;
    return {
        ...(promptTokens === undefined ? {} : { promptTokens }),
        ...(completionTokens === undefined ? {} : { completionTokens }),
        ...(cacheHitTokens === undefined ? {} : { cacheHitTokens }),
        ...(cacheMissTokens === undefined ? {} : { cacheMissTokens }),
        providerReported: next.providerReported || (current?.providerReported ?? false)
    };
}
function addUsageTotals(current, next) {
    if (next === undefined)
        return current;
    const sum = (left, right) => left === undefined && right === undefined ? undefined : (left ?? 0) + (right ?? 0);
    const promptTokens = sum(current?.promptTokens, next.promptTokens);
    const completionTokens = sum(current?.completionTokens, next.completionTokens);
    const cacheHitTokens = sum(current?.cacheHitTokens, next.cacheHitTokens);
    const cacheMissTokens = sum(current?.cacheMissTokens, next.cacheMissTokens);
    return {
        ...(promptTokens === undefined ? {} : { promptTokens }),
        ...(completionTokens === undefined ? {} : { completionTokens }),
        ...(cacheHitTokens === undefined ? {} : { cacheHitTokens }),
        ...(cacheMissTokens === undefined ? {} : { cacheMissTokens }),
        providerReported: next.providerReported || (current?.providerReported ?? false)
    };
}
function sourceSection(sources) {
    if (sources.length === 0)
        return "";
    return [
        "### 参考来源",
        "",
        ...sources.map((source) => {
            const title = source.title
                .replace(/[\[\]\r\n]/gu, " ")
                .replace(/\s+/gu, " ")
                .trim();
            const url = source.url.replace(/[()]/gu, (character) => encodeURIComponent(character));
            return `- [${title.length > 0 ? title : source.url}](${url})`;
        })
    ].join("\n");
}
function folderFor(roots, conversation) {
    return (0, private_paths_1.conversationFolder)(roots.active, conversation.id);
}
function descriptor(folder, conversation) {
    return {
        conversationId: conversation.id,
        folder,
        conversation
    };
}
class TreeTalkPlugin extends obsidian_1.Plugin {
    pluginData = (0, plugin_data_1.parsePluginData)(undefined);
    pluginSettings = plugin_data_1.DEFAULT_SETTINGS;
    tabsStore = new conversation_tabs_store_1.ConversationTabsStore();
    store = new active_conversation_store_1.ActiveConversationStore(this.tabsStore);
    sourceHighlights = new source_highlight_store_1.SourceHighlightStore();
    responseRouter = new tab_response_router_1.TabResponseRouter(this.tabsStore);
    providers = new provider_registry_1.ProviderRegistry();
    nodeSummaries = new node_summary_coordinator_1.NodeSummaryCoordinator(this.tabsStore, this.providers, {
        request: async (request, signal) => {
            if (signal.aborted)
                throw new DOMException("Aborted", "AbortError");
            const response = await (0, obsidian_1.requestUrl)({
                url: request.url,
                method: request.method,
                headers: request.headers,
                body: JSON.stringify(request.body),
                throw: false
            });
            if (signal.aborted)
                throw new DOMException("Aborted", "AbortError");
            if (response.status >= 400) {
                throw new Error(`HTTP ${String(response.status)}`);
            }
            return response.json;
        }
    }, {
        getProfile: () => this.currentProviderProfile(),
        getModel: () => this.pluginSettings.model,
        now: () => new Date().toISOString(),
        persistPending: async (tabId) => {
            const tab = this.tabsStore.getTab(tabId);
            if (tab === undefined || this.persistence === undefined) {
                throw new Error("Session persistence is unavailable");
            }
            this.persistenceScheduler.flush();
            await this.persistence.flush(tab.folder);
        }
    });
    streamingTransport = new streaming_transport_1.StreamingProviderTransport();
    transientUsage = new transient_usage_store_1.TransientUsageStore();
    transientResponseStatus = new transient_response_status_store_1.TransientResponseStatusStore();
    activeRequests = new active_response_requests_1.ActiveResponseRequests(this.responseRouter);
    repository;
    archiveService;
    lifecycleReconciler;
    historyIndex;
    historyDeleteService;
    captureService;
    knowledgeVault;
    roots;
    persistence;
    tabLifecycle;
    lifecycleQueue = new lifecycle_queue_1.LifecycleQueue();
    persistenceScheduler = new persistence_scheduler_1.BatchedPersistenceScheduler(() => this.persistAllNow());
    coordinator;
    dataSaveTail = Promise.resolve();
    webSearchListeners = new Set();
    async onload() {
        this.registerEditorExtension((0, excerpt_drop_extension_1.createExcerptDropExtension)());
        const sourceLinkHandler = new source_link_handler_1.SourceLinkHandler({
            openActive: (source) => this.openActiveSource(source),
            openHistory: (source) => this.openHistorySource(source)
        });
        this.registerObsidianProtocolHandler("treetalk-open", (parameters) => {
            void sourceLinkHandler.open(parameters).then((result) => {
                if (result === "missing") {
                    new obsidian_1.Notice("TreeTalk 来源对话不存在");
                }
            });
        });
        this.pluginData = (0, plugin_data_1.parsePluginData)(await this.loadData());
        this.pluginSettings = this.pluginData.settings;
        const runtime = (0, runtime_private_storage_1.createPrivateStorageRuntime)(this.app.vault);
        const vaultPort = runtime.port;
        this.roots = runtime.roots;
        this.knowledgeVault = new obsidian_vault_port_1.ObsidianVaultPort(this.app.vault);
        this.captureService = new capture_service_1.KnowledgeCaptureService(this.knowledgeVault, this.pluginSettings.knowledgeFolder, this.pluginSettings.treeCaptureFolder);
        this.repository = new conversation_repository_1.ConversationRepository(vaultPort);
        this.persistence = new session_persistence_1.SessionPersistence(this.repository, () => {
            new obsidian_1.Notice("TreeTalk 自动保存遇到冲突，已保留冲突副本");
        });
        this.archiveService = new archive_service_1.ArchiveService(this.repository, vaultPort, runtime.roots);
        this.lifecycleReconciler = new lifecycle_reconciler_1.LifecycleReconciler(this.repository, vaultPort, runtime.roots);
        this.historyIndex = new history_index_1.HistoryIndex(vaultPort, runtime.roots.history);
        this.historyDeleteService = new history_delete_service_1.HistoryDeleteService(vaultPort, this.historyIndex, (conversationId) => this.closeOpenHistory(conversationId), () => {
            new obsidian_1.Notice("历史对话已永久删除，但打开视图或历史列表刷新未完全完成");
        });
        const reconciliation = await this.lifecycleQueue.run(() => this.lifecycleReconciler?.reconcile() ??
            Promise.resolve({ repaired: 0, failed: 0 }));
        if (reconciliation.repaired > 0) {
            new obsidian_1.Notice(`TreeTalk 已恢复 ${String(reconciliation.repaired)} 个中断的对话`);
        }
        if (reconciliation.failed > 0) {
            new obsidian_1.Notice("部分 TreeTalk 对话需要手动检查，原文件未被删除");
        }
        await this.restoreOpenTabs(vaultPort, runtime.roots);
        this.tabLifecycle = new tab_lifecycle_controller_1.TabLifecycleController(this.tabsStore, this.persistence, this.archiveService, this.lifecycleQueue, () => this.saveTabsWorkspace());
        this.register((0, note_selection_capture_1.installNoteSelectionCapture)({
            document,
            store: this.store,
            getActiveSource: () => this.activeMarkdownSelectionSource(),
            now: () => new Date().toISOString()
        }));
        this.registerView(sidebar_workspace_coordinator_1.TREETALK_WORKSPACE_VIEW_TYPE, (leaf) => new obsidian_views_1.TreeTalkWorkspaceView(leaf, this.store, {
            send: (text) => this.send(text),
            restore: () => this.restoreActiveTab(),
            createConversation: () => this.createConversationTab(),
            openHistory: () => this.openHistoryManager(),
            captureTree: () => this.captureTree(),
            captureAnswer: (messageId) => this.captureAnswer(messageId),
            stop: () => this.stopActiveResponse()
        }, {
            initialTreeWidth: this.pluginSettings.treeWidth,
            onTreeWidthChange: (treeWidth) => {
                void this.updateSettings({
                    ...this.pluginSettings,
                    treeWidth
                });
            }
        }, this.tabsStore, {
            create: () => this.createConversationTab(),
            close: (tabId) => this.closeTab(tabId),
            reorder: (tabId, targetIndex) => this.tabsStore.reorder(tabId, targetIndex)
        }, undefined, this.sourceHighlights, () => this.pluginSettings.obsidianMarkdownCompatibility, this.transientUsage, this.transientResponseStatus, {
            isEnabled: () => this.pluginSettings.webSearchEnabled,
            isAvailable: () => this.pluginSettings.provider === "deepseek",
            setEnabled: (enabled) => this.setWebSearchEnabled(enabled),
            subscribe: (listener) => this.subscribeWebSearch(listener)
        }));
        this.coordinator = new sidebar_workspace_coordinator_1.SidebarWorkspaceCoordinator(new sidebar_workspace_coordinator_1.ObsidianSidebarWorkspacePort(this.app.workspace));
        this.registerCommands();
        this.addSettingTab(new TreeTalkSettingTab(this.app, this));
        this.app.workspace.onLayoutReady(() => {
            void this.coordinator?.repairLegacyViews();
            this.schedulePersistAll();
        });
        this.register(this.tabsStore.subscribe(() => {
            this.schedulePersistAll();
            void this.saveTabsWorkspace();
        }));
        await this.saveTabsWorkspace();
        void this.nodeSummaries.repairOpenTabs();
    }
    onunload() {
        this.activeRequests.interruptAll(new Date().toISOString());
        this.nodeSummaries.dispose();
        this.transientUsage.clear();
        this.transientResponseStatus.clear();
        this.persistenceScheduler.flush();
        void this.persistence?.flush().catch(() => undefined);
        void this.coordinator?.close();
    }
    getSettings() {
        return this.pluginSettings;
    }
    async updateSettings(next) {
        const webSearchChanged = next.webSearchEnabled !== this.pluginSettings.webSearchEnabled ||
            next.provider !== this.pluginSettings.provider;
        this.pluginSettings = next;
        if (webSearchChanged) {
            for (const listener of this.webSearchListeners)
                listener();
        }
        this.knowledgeVault = new obsidian_vault_port_1.ObsidianVaultPort(this.app.vault);
        this.captureService = new capture_service_1.KnowledgeCaptureService(this.knowledgeVault, next.knowledgeFolder, next.treeCaptureFolder);
        this.pluginData = { ...this.pluginData, settings: next };
        await this.persistPluginData();
    }
    subscribeWebSearch(listener) {
        this.webSearchListeners.add(listener);
        return () => this.webSearchListeners.delete(listener);
    }
    setWebSearchEnabled(enabled) {
        return this.updateSettings({
            ...this.pluginSettings,
            webSearchEnabled: enabled
        });
    }
    getApiKey() {
        return this.app.secretStorage.getSecret(SECRET_ID) ?? "";
    }
    setApiKey(value) {
        const apiKey = value.trim();
        this.app.secretStorage.setSecret(SECRET_ID, apiKey);
        if (apiKey.length > 0)
            void this.nodeSummaries.repairOpenTabs();
    }
    activeMarkdownSelectionSource() {
        const view = this.app.workspace.getActiveViewOfType(obsidian_1.MarkdownView);
        if (view === null || view.file === null) {
            return undefined;
        }
        const file = view.file;
        const mode = view.getMode();
        const contentEl = view.contentEl.querySelector(mode === "source"
            ? ".markdown-source-view"
            : ".markdown-preview-view") ?? view.contentEl;
        return {
            filePath: file.path,
            fileName: file.name,
            mode,
            contentEl,
            loadSourceText: () => this.app.vault.cachedRead(file),
            ...(mode === "source" ? { editor: view.editor } : {})
        };
    }
    registerCommands() {
        this.addRibbonIcon("messages-square", "打开 TreeTalk", () => {
            void this.coordinator?.toggle();
        });
        this.addCommand({
            id: "toggle-paired-views",
            name: "打开或关闭 TreeTalk",
            callback: () => void this.coordinator?.toggle()
        });
        this.addCommand({
            id: exports.COMMAND_IDS.new,
            name: "新建对话空间",
            callback: () => void this.createConversationTab()
        });
        this.addCommand({
            id: exports.COMMAND_IDS.close,
            name: "关闭当前对话空间",
            callback: () => {
                const tabId = this.tabsStore.getSnapshot().activeTabId;
                if (tabId !== null)
                    void this.closeTab(tabId);
            }
        });
        this.addCommand({
            id: exports.COMMAND_IDS.next,
            name: "切换到下一个对话空间",
            callback: () => (0, tab_workspace_operations_1.selectAdjacentTab)(this.tabsStore, 1)
        });
        this.addCommand({
            id: exports.COMMAND_IDS.previous,
            name: "切换到上一个对话空间",
            callback: () => (0, tab_workspace_operations_1.selectAdjacentTab)(this.tabsStore, -1)
        });
        this.addCommand({
            id: "open-history",
            name: "打开历史对话",
            callback: () => void this.openHistoryManager()
        });
        this.addCommand({
            id: "restore-history",
            name: "恢复当前历史对话",
            callback: () => void this.restoreActiveTab()
        });
    }
    async restoreOpenTabs(vaultPort, roots) {
        const available = new Map();
        let latestActive;
        for (const root of [roots.active, roots.history]) {
            const paths = (await vaultPort.list(`${root}/`)).filter((path) => path.endsWith("/tree.json"));
            for (const path of paths) {
                const folder = path.slice(0, -"/tree.json".length);
                try {
                    const loaded = await this.repository?.load(folder);
                    if (loaded === undefined)
                        continue;
                    const entry = descriptor(folder, loaded.conversation);
                    if (!available.has(entry.conversationId)) {
                        available.set(entry.conversationId, entry);
                    }
                    if (loaded.conversation.status === "active" &&
                        (latestActive === undefined ||
                            loaded.conversation.updatedAt >
                                latestActive.conversation.updatedAt)) {
                        latestActive = entry;
                    }
                }
                catch {
                    // Corrupt canonical files remain untouched for repository recovery.
                }
            }
        }
        const restored = await (0, workspace_state_1.restoreTabsWorkspace)(this.pluginData.tabs, (conversationId) => Promise.resolve(available.get(conversationId)));
        for (const tab of restored.tabs) {
            this.tabsStore.open(tab);
            this.persistence?.seed(tab.folder, tab.conversation.revision);
        }
        if (restored.activeConversationId !== null) {
            this.tabsStore.select(restored.activeConversationId);
        }
        else if (restored.tabs.length === 0 &&
            latestActive !== undefined &&
            this.pluginData.tabs.openConversationIds.length === 0) {
            (0, tab_workspace_operations_1.openConversationTab)(this.tabsStore, latestActive.folder, latestActive.conversation);
            this.persistence?.seed(latestActive.folder, latestActive.conversation.revision);
        }
    }
    createConversationTab() {
        const roots = this.roots;
        if (roots === undefined)
            return Promise.resolve();
        const conversation = (0, conversation_factory_1.createConversation)();
        (0, tab_workspace_operations_1.openConversationTab)(this.tabsStore, folderFor(roots, conversation), conversation);
        return this.coordinator?.open() ?? Promise.resolve();
    }
    async closeTab(tabId) {
        const closingTab = this.tabsStore.getTab(tabId);
        if (closingTab !== undefined) {
            for (const node of Object.values(closingTab.conversation.nodes)) {
                for (const message of node.messages) {
                    this.transientUsage.delete(message.id);
                }
            }
        }
        const conversationId = closingTab?.conversationId;
        if (conversationId !== undefined) {
            this.activeRequests.interrupt(conversationId, new Date().toISOString());
        }
        this.persistenceScheduler.flush();
        try {
            await this.tabLifecycle?.close(tabId);
        }
        catch {
            new obsidian_1.Notice("关闭失败，当前对话已安全保留");
        }
    }
    async restoreActiveTab() {
        const tabId = this.tabsStore.getSnapshot().activeTabId;
        if (tabId === null)
            return;
        const tab = this.tabsStore.getTab(tabId);
        try {
            await this.tabLifecycle?.restore(tabId);
            new obsidian_1.Notice("历史对话已恢复");
        }
        catch {
            new obsidian_1.Notice("恢复失败，历史对话仍保持只读");
        }
    }
    currentProviderProfile() {
        return {
            id: "default",
            name: "默认",
            kind: this.pluginSettings.provider,
            apiKey: this.getApiKey(),
            baseUrl: this.pluginSettings.baseUrl
        };
    }
    async send(text) {
        const tab = this.tabsStore.getActiveTab();
        if (tab === undefined ||
            tab.mode !== "active" ||
            tab.lifecycle !== "idle") {
            return;
        }
        if (this.activeRequests.has(tab.conversationId)) {
            new obsidian_1.Notice("当前对话正在生成回复");
            return;
        }
        const key = this.getApiKey();
        if (key.length === 0) {
            new obsidian_1.Notice("请先在 TreeTalk 设置中填写 API Key");
            return;
        }
        const before = tab.conversation;
        const now = new Date().toISOString();
        const current = before.nodes[before.currentNodeId];
        if (current === undefined)
            return;
        const command = current.draft.mode === "child"
            ? (0, tree_commands_1.submitChildDraft)(before, {
                text,
                childId: crypto.randomUUID(),
                messageId: crypto.randomUUID(),
                now
            })
            : (0, tree_commands_1.continueNode)(before, {
                nodeId: before.currentNodeId,
                text,
                messageId: crypto.randomUUID(),
                now
            });
        this.tabsStore.updateConversation(tab.id, () => command.state);
        const responseNodeId = command.state.currentNodeId;
        const ticket = this.responseRouter.capture(tab.id, responseNodeId);
        const profile = this.currentProviderProfile();
        const adapter = this.providers.get(profile);
        const contextMode = this.pluginSettings.contextOptimizationEnabled
            ? "balanced"
            : "full";
        const systemPrompt = contextMode === "full"
            ? (0, full_context_protocol_1.buildTreeTalkSystemPrompt)(this.pluginSettings.obsidianMarkdownCompatibility)
            : this.pluginSettings.obsidianMarkdownCompatibility
                ? markdown_compatibility_1.OBSIDIAN_MARKDOWN_SYSTEM_PROMPT
                : "";
        let contextPlan;
        try {
            contextPlan = (0, context_engine_1.compileContextPlan)(command.state, responseNodeId, {
                mode: contextMode,
                systemPrompt,
                maxInputTokens: 30_000,
                recentRoundTarget: 4,
                minRecentRounds: 2,
                maxRecentRounds: 6
            });
        }
        catch (error) {
            if (error instanceof context_engine_1.ProtectedContextTooLongError) {
                new obsidian_1.Notice(error.message);
            }
            else {
                new obsidian_1.Notice("TreeTalk 上下文构建失败，本次请求未发送");
            }
            return;
        }
        if (contextPlan.persistencePatch !== undefined) {
            try {
                const persistedState = (0, context_persistence_1.applyContextPlanPersistencePatch)(command.state, contextPlan.persistencePatch, new Date().toISOString());
                this.tabsStore.updateConversation(tab.id, () => persistedState);
                if (this.persistence === undefined) {
                    throw new Error("Session persistence is unavailable");
                }
                this.persistenceScheduler.flush();
                await this.persistence.flush(tab.folder);
            }
            catch {
                new obsidian_1.Notice("TreeTalk 上下文冻结保存失败，本次请求未发送");
                return;
            }
        }
        const context = contextPlan.messages;
        const sentEstimatedTokens = contextPlan.sentEstimatedTokens;
        const fullEstimatedTokens = contextPlan.fullEstimatedTokens;
        const contextCacheKey = (0, context_engine_1.cacheKeyForContextPlan)(command.state.id, contextPlan);
        const messageId = crypto.randomUUID();
        this.responseRouter.start(ticket, {
            conversationId: ticket.conversationId,
            nodeId: ticket.nodeId,
            messageId,
            providerProfileId: "default",
            modelId: this.pluginSettings.model,
            now: new Date().toISOString()
        });
        const requestHandle = this.activeRequests.begin(tab.conversationId, ticket, messageId);
        const { controller } = requestHandle;
        const webSearchEnabled = this.pluginSettings.provider === "deepseek" &&
            this.pluginSettings.webSearchEnabled;
        this.transientResponseStatus.set(messageId, webSearchEnabled ? "deciding-web-search" : "thinking");
        let receivedText = false;
        let receivedDone = false;
        let usage;
        let anthropicContinuation;
        let continuationCount = 0;
        let lastSearchStatus;
        const sourceMap = new Map();
        try {
            while (!receivedDone) {
                let turnReceivedText = false;
                let turnFinished = false;
                let turnDone = false;
                let pauseContent;
                let turnUsage;
                let streamFailure;
                const request = adapter.buildRequest({
                    messages: context,
                    model: this.pluginSettings.model,
                    stream: true,
                    webSearchEnabled,
                    ...(anthropicContinuation === undefined
                        ? {}
                        : { anthropicContinuation }),
                    ...(contextCacheKey === undefined
                        ? {}
                        : { cacheKey: contextCacheKey })
                }, profile);
                const handleEvent = (event) => {
                    if (event.type === "delta" && event.text.length > 0) {
                        receivedText = true;
                        turnReceivedText = true;
                        this.transientResponseStatus.delete(messageId);
                        this.responseRouter.delta(ticket, {
                            conversationId: ticket.conversationId,
                            nodeId: ticket.nodeId,
                            messageId,
                            delta: event.text,
                            now: new Date().toISOString()
                        });
                        return;
                    }
                    if (event.type === "usage") {
                        turnUsage = mergeUsage(turnUsage, event.usage);
                        return;
                    }
                    if (event.type === "sources") {
                        for (const source of event.sources)
                            sourceMap.set(source.url, source);
                        return;
                    }
                    if (event.type === "search-status") {
                        if (lastSearchStatus === event.status)
                            return;
                        lastSearchStatus = event.status;
                        this.transientResponseStatus.set(messageId, event.status === "searching"
                            ? "searching-web"
                            : "organizing-web-results");
                        return;
                    }
                    if (event.type === "pause") {
                        pauseContent = event.content;
                        return;
                    }
                    if (event.type === "error")
                        throw new Error(event.message);
                    if (event.type === "finish")
                        turnFinished = true;
                    if (event.type === "done") {
                        turnDone = true;
                        turnFinished = true;
                    }
                };
                try {
                    for await (const event of this.streamingTransport.stream(adapter, request, controller.signal)) {
                        if (requestHandle.finalized)
                            break;
                        handleEvent(event);
                        if (event.type === "pause" || event.type === "done")
                            break;
                    }
                }
                catch (error) {
                    streamFailure = error;
                }
                if (requestHandle.finalized)
                    return;
                if (controller.signal.aborted)
                    break;
                if (!turnReceivedText && (0, streaming_transport_1.canUseBufferedFallback)(streamFailure)) {
                    const fallbackRequest = adapter.buildRequest({
                        messages: context,
                        model: this.pluginSettings.model,
                        stream: false,
                        webSearchEnabled,
                        ...(anthropicContinuation === undefined
                            ? {}
                            : { anthropicContinuation }),
                        ...(contextCacheKey === undefined
                            ? {}
                            : { cacheKey: contextCacheKey })
                    }, profile);
                    const response = await (0, obsidian_1.requestUrl)({
                        url: fallbackRequest.url,
                        method: fallbackRequest.method,
                        headers: fallbackRequest.headers,
                        body: JSON.stringify(fallbackRequest.body),
                        throw: false
                    });
                    if (response.status >= 400) {
                        throw new Error(`HTTP ${String(response.status)}`);
                    }
                    for (const event of adapter.parseBuffered(response.json, fallbackRequest)) {
                        handleEvent(event);
                    }
                    streamFailure = undefined;
                }
                if (streamFailure !== undefined)
                    throw streamFailure;
                usage = addUsageTotals(usage, turnUsage);
                if (pauseContent !== undefined) {
                    if (!webSearchEnabled || continuationCount >= 2) {
                        throw new Error("联网搜索未能在限定轮次内完成");
                    }
                    anthropicContinuation = [
                        ...(anthropicContinuation ?? []),
                        ...pauseContent
                    ];
                    continuationCount += 1;
                    continue;
                }
                if (turnDone || turnFinished) {
                    receivedDone = true;
                    break;
                }
                throw new Error("Streaming response ended without a completion frame");
            }
            if (controller.signal.aborted) {
                this.activeRequests.finish(requestHandle, "interrupted", new Date().toISOString());
                return;
            }
            (0, streaming_transport_1.assertStreamCompleted)(receivedText, receivedDone);
            const responseContent = this.tabsStore
                .getTab(ticket.tabId)
                ?.conversation.nodes[ticket.nodeId]
                ?.messages.find((message) => message.id === messageId)?.content ?? "";
            const references = sourceSection([...sourceMap.values()]);
            const contentWithSources = references.length === 0
                ? responseContent
                : `${responseContent.trimEnd()}\n\n${references}`;
            const finalContent = this.pluginSettings.obsidianMarkdownCompatibility
                ? (0, markdown_compatibility_1.normalizeObsidianMarkdown)(contentWithSources)
                : contentWithSources;
            this.activeRequests.finish(requestHandle, "complete", new Date().toISOString(), finalContent, contextPlan.referencedNoteNames);
            void this.nodeSummaries.trigger({
                tabId: ticket.tabId,
                conversationId: ticket.conversationId,
                nodeId: ticket.nodeId,
                answerMessageId: messageId
            });
            this.transientUsage.set(messageId, {
                mode: contextPlan.mode,
                fullEstimatedTokens,
                sentEstimatedTokens,
                reducedTokens: contextPlan.reducedTokens,
                reductionRatio: contextPlan.reductionRatio,
                noteContextOriginalEstimatedTokens: contextPlan.noteContextOriginalEstimatedTokens,
                noteContextSentEstimatedTokens: contextPlan.noteContextSentEstimatedTokens,
                noteContextTrimmed: contextPlan.noteContextTrimmed,
                ...(usage?.promptTokens === undefined
                    ? {}
                    : { promptTokens: usage.promptTokens }),
                ...(usage?.completionTokens === undefined
                    ? {}
                    : { completionTokens: usage.completionTokens }),
                ...(usage?.cacheHitTokens === undefined
                    ? {}
                    : { cacheHitTokens: usage.cacheHitTokens }),
                ...(usage?.cacheMissTokens === undefined
                    ? {}
                    : { cacheMissTokens: usage.cacheMissTokens })
            });
        }
        catch {
            const alreadyFinalized = requestHandle.finalized;
            try {
                if (!requestHandle.finalized && !receivedText) {
                    this.transientResponseStatus.delete(messageId);
                    this.responseRouter.delta(ticket, {
                        conversationId: ticket.conversationId,
                        nodeId: ticket.nodeId,
                        messageId,
                        delta: "回复失败，请重试。",
                        now: new Date().toISOString()
                    });
                }
                this.activeRequests.finish(requestHandle, "failed", new Date().toISOString());
            }
            catch {
                // Closing or archiving invalidates the ticket by design.
            }
            if (!alreadyFinalized) {
                new obsidian_1.Notice(webSearchEnabled
                    ? "TreeTalk 联网请求失败，请检查 DeepSeek 模型、地址和 API Key"
                    : "TreeTalk 请求失败，请检查模型、地址和 API Key");
            }
        }
        finally {
            this.transientResponseStatus.delete(messageId);
            this.activeRequests.release(requestHandle);
        }
    }
    stopActiveResponse() {
        const conversationId = this.tabsStore.getActiveTab()?.conversationId;
        if (conversationId !== undefined) {
            this.activeRequests.interrupt(conversationId, new Date().toISOString());
        }
        return Promise.resolve();
    }
    schedulePersistAll() {
        this.persistenceScheduler.schedule();
    }
    persistAllNow() {
        for (const tabId of this.tabsStore.getSnapshot().orderedTabIds) {
            const tab = this.tabsStore.getTab(tabId);
            if (tab === undefined)
                continue;
            this.persistence?.schedule(tab.folder, tab.conversation);
        }
    }
    async openHistoryManager() {
        const index = this.historyIndex;
        if (index === undefined)
            return;
        await this.lifecycleQueue.run(async () => {
            await this.lifecycleReconciler?.reconcile();
            await index.rebuild();
        });
        const entries = index.entries();
        if (entries.length === 0) {
            new obsidian_1.Notice("还没有历史对话");
            return;
        }
        new history_manager_modal_1.HistoryManagerModal(this.app, entries, {
            open: (entry) => this.openHistoryEntry(entry).then(() => undefined),
            confirmDelete: (entry) => (0, history_manager_modal_1.confirmHistoryDeletion)(this.app, entry),
            delete: (entry) => {
                const service = this.historyDeleteService;
                if (service === undefined) {
                    return Promise.reject(new Error("History deletion is unavailable"));
                }
                return this.lifecycleQueue.run(() => service.delete(entry));
            },
            reportError: () => {
                new obsidian_1.Notice("删除失败，历史对话仍已安全保留");
            }
        }).open();
    }
    async closeOpenHistory(conversationId) {
        const tab = Object.values(this.tabsStore.getSnapshot().tabs).find((entry) => entry.conversationId === conversationId &&
            entry.mode === "archived");
        if (tab !== undefined) {
            await this.tabLifecycle?.close(tab.id);
        }
    }
    async openHistoryEntry(entry, target) {
        const repository = this.repository;
        if (repository === undefined)
            return false;
        try {
            const loaded = await this.lifecycleQueue.run(() => repository.load(entry.folder));
            if (loaded.conversation.status !== "archived" ||
                (target !== undefined &&
                    !(0, source_link_handler_1.conversationContainsSource)(loaded.conversation, target))) {
                return false;
            }
            this.persistence?.seed(entry.folder, loaded.conversation.revision);
            const tabId = (0, tab_workspace_operations_1.openConversationTab)(this.tabsStore, entry.folder, loaded.conversation);
            if (target !== undefined) {
                this.tabsStore.updateConversation(tabId, (conversation) => ({
                    ...structuredClone(conversation),
                    currentNodeId: target.nodeId
                }));
            }
            await this.coordinator?.open();
            return true;
        }
        catch {
            new obsidian_1.Notice("无法读取这个历史对话，原数据已安全保留");
            return false;
        }
    }
    async openActiveSource(source) {
        const tab = Object.values(this.tabsStore.getSnapshot().tabs).find((entry) => entry.conversationId === source.conversationId);
        if (tab === undefined ||
            !(0, source_link_handler_1.conversationContainsSource)(tab.conversation, source)) {
            return false;
        }
        this.tabsStore.select(tab.id);
        this.tabsStore.updateConversation(tab.id, (conversation) => ({
            ...structuredClone(conversation),
            currentNodeId: source.nodeId
        }));
        await this.coordinator?.open();
        this.sourceHighlights.publish(source);
        return true;
    }
    async openHistorySource(source) {
        const index = this.historyIndex;
        if (index === undefined)
            return false;
        await this.lifecycleQueue.run(async () => {
            await this.lifecycleReconciler?.reconcile();
            await index.rebuild();
        });
        const entry = index
            .entries()
            .find((candidate) => candidate.id === source.conversationId);
        if (entry === undefined)
            return false;
        const opened = await this.openHistoryEntry(entry, source);
        if (opened)
            this.sourceHighlights.publish(source);
        return opened;
    }
    async captureTree() {
        const tab = this.tabsStore.getActiveTab();
        if (tab === undefined)
            return;
        await this.nodeSummaries.waitForNode(tab.id, tab.conversation.currentNodeId);
        const conversation = this.tabsStore.getTab(tab.id)?.conversation;
        if (conversation === undefined)
            return;
        await this.captureKnowledge({
            scope: "tree",
            conversation
        });
    }
    async captureAnswer(messageId) {
        const tab = this.tabsStore.getActiveTab();
        if (tab === undefined)
            return;
        for (const node of Object.values(tab.conversation.nodes)) {
            if (!node.messages.some((message) => message.id === messageId))
                continue;
            await this.nodeSummaries.waitForNode(tab.id, node.id);
            const conversation = this.tabsStore.getTab(tab.id)?.conversation;
            if (conversation === undefined)
                return;
            await this.captureKnowledge({
                scope: "answer",
                conversation,
                nodeId: node.id,
                messageId
            });
            return;
        }
    }
    async captureKnowledge(request) {
        try {
            const path = await this.captureService?.capture(request, new Date().toISOString());
            if (path !== undefined)
                new obsidian_1.Notice(`已沉淀到 ${path}`);
        }
        catch {
            new obsidian_1.Notice("知识沉淀失败，对话内容未受影响");
        }
    }
    saveTabsWorkspace() {
        this.pluginData = {
            ...this.pluginData,
            tabs: (0, workspace_state_1.serializeTabsWorkspace)(this.tabsStore.getSnapshot())
        };
        return this.persistPluginData();
    }
    persistPluginData() {
        this.dataSaveTail = this.dataSaveTail
            .catch(() => undefined)
            .then(() => this.saveData(this.pluginData));
        return this.dataSaveTail;
    }
}
exports.default = TreeTalkPlugin;
class TreeTalkSettingTab extends obsidian_1.PluginSettingTab {
    plugin;
    webSearchUnsubscribe;
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        this.webSearchUnsubscribe?.();
        this.webSearchUnsubscribe = undefined;
        this.containerEl.empty();
        const settings = this.plugin.getSettings();
        new obsidian_1.Setting(this.containerEl)
            .setName("服务类型")
            .addDropdown((dropdown) => dropdown
            .addOptions({
            openai: "OpenAI",
            deepseek: "DeepSeek",
            anthropic: "Anthropic",
            gemini: "Gemini",
            "openai-compatible": "OpenAI 兼容服务"
        })
            .setValue(settings.provider)
            .onChange(async (provider) => {
            const current = this.plugin.getSettings();
            const nextProvider = provider;
            let model = current.model;
            if (nextProvider === "deepseek") {
                model = model.startsWith("deepseek-")
                    ? (0, plugin_data_1.normalizeConfiguredModel)(nextProvider, model)
                    : "deepseek-v4-flash";
            }
            else if (nextProvider === "openai" &&
                model.startsWith("deepseek-")) {
                model = plugin_data_1.DEFAULT_SETTINGS.model;
            }
            await this.plugin.updateSettings({
                ...current,
                provider: nextProvider,
                model
            });
            this.display();
        }));
        new obsidian_1.Setting(this.containerEl).setName("模型").addText((text) => text.setValue(settings.model).onChange(async (model) => {
            const current = this.plugin.getSettings();
            await this.plugin.updateSettings({
                ...current,
                model: (0, plugin_data_1.normalizeConfiguredModel)(current.provider, model)
            });
        }));
        new obsidian_1.Setting(this.containerEl).setName("API 地址").addText((text) => text
            .setPlaceholder("留空使用官方地址")
            .setValue(settings.baseUrl)
            .onChange(async (baseUrl) => {
            await this.plugin.updateSettings({
                ...this.plugin.getSettings(),
                baseUrl
            });
        }));
        new obsidian_1.Setting(this.containerEl).setName("API Key").addText((text) => {
            text.inputEl.type = "password";
            text
                .setValue(this.plugin.getApiKey())
                .onChange((value) => this.plugin.setApiKey(value));
        });
        new obsidian_1.Setting(this.containerEl)
            .setName("Obsidian Markdown 兼容模式")
            .setDesc("约束 AI 输出格式、保护流式未闭合语法，并在完成后保守规范化")
            .addToggle((toggle) => toggle
            .setValue(settings.obsidianMarkdownCompatibility)
            .onChange(async (obsidianMarkdownCompatibility) => {
            await this.plugin.updateSettings({
                ...this.plugin.getSettings(),
                obsidianMarkdownCompatibility
            });
        }));
        new obsidian_1.Setting(this.containerEl)
            .setName("联网模式")
            .setDesc("开启后，DeepSeek 会根据问题自动判断是否需要搜索网页。当前仅支持 DeepSeek。")
            .addToggle((toggle) => {
            const sync = () => {
                const current = this.plugin.getSettings();
                toggle.setValue(current.webSearchEnabled);
                toggle.setDisabled(current.provider !== "deepseek");
            };
            sync();
            toggle.onChange(async (webSearchEnabled) => {
                await this.plugin.updateSettings({
                    ...this.plugin.getSettings(),
                    webSearchEnabled
                });
            });
            this.webSearchUnsubscribe = this.plugin.subscribeWebSearch(sync);
        });
        new obsidian_1.Setting(this.containerEl)
            .setName("平衡模式")
            .setDesc("开启后减少长对话的输入 Token 和费用；关闭后使用完整模式，保留当前分支的完整上下文。")
            .addToggle((toggle) => toggle
            .setValue(settings.contextOptimizationEnabled)
            .onChange(async (contextOptimizationEnabled) => {
            await this.plugin.updateSettings({
                ...this.plugin.getSettings(),
                contextOptimizationEnabled,
                contextMode: contextOptimizationEnabled ? "balanced" : "full"
            });
        }));
        new obsidian_1.Setting(this.containerEl)
            .setName("知识沉淀文件夹")
            .setDesc("单个回答将保存为可自由编辑的纯 Markdown 笔记")
            .addText((text) => text
            .setPlaceholder("TreeTalk 知识")
            .setValue(settings.knowledgeFolder)
            .onChange(async (knowledgeFolder) => {
            await this.plugin.updateSettings({
                ...this.plugin.getSettings(),
                knowledgeFolder: knowledgeFolder.trim().length > 0
                    ? knowledgeFolder.trim()
                    : plugin_data_1.DEFAULT_SETTINGS.knowledgeFolder
            });
        }));
        new obsidian_1.Setting(this.containerEl)
            .setName("沉淀对话树目录")
            .setDesc("每次沉淀会在该目录中创建纯 Markdown 对话树文件夹")
            .addText((text) => text
            .setPlaceholder("TreeTalk")
            .setValue(settings.treeCaptureFolder)
            .onChange(async (treeCaptureFolder) => {
            await this.plugin.updateSettings({
                ...this.plugin.getSettings(),
                treeCaptureFolder: treeCaptureFolder.trim().length > 0
                    ? treeCaptureFolder.trim()
                    : plugin_data_1.DEFAULT_SETTINGS.treeCaptureFolder
            });
        }));
    }
    hide() {
        this.webSearchUnsubscribe?.();
        this.webSearchUnsubscribe = undefined;
    }
}

},
"navigation/source-highlight-store.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourceHighlightStore = void 0;
class SourceHighlightStore {
    listeners = new Set();
    publish(source) {
        const snapshot = structuredClone(source);
        for (const listener of this.listeners)
            listener(snapshot);
    }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
}
exports.SourceHighlightStore = SourceHighlightStore;

},
"navigation/source-link-handler.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourceLinkHandler = void 0;
exports.conversationContainsSource = conversationContainsSource;
const excerpt_drag_1 = require("../knowledge/excerpt-drag");
function conversationContainsSource(conversation, source) {
    if (conversation.id !== source.conversationId)
        return false;
    const node = conversation.nodes[source.nodeId];
    if (node === undefined)
        return false;
    return source.messageId === undefined
        ? true
        : node.messages.some((message) => message.id === source.messageId);
}
function sourceFromParameters(parameters) {
    const conversationId = parameters.conversationId?.trim();
    const nodeId = parameters.nodeId?.trim();
    const messageId = parameters.messageId?.trim();
    const encodedAnchor = parameters.anchor?.trim();
    if (conversationId === undefined ||
        conversationId.length === 0 ||
        nodeId === undefined ||
        nodeId.length === 0) {
        return undefined;
    }
    const source = { conversationId, nodeId };
    if (messageId !== undefined && messageId.length > 0) {
        source.messageId = messageId;
    }
    if (encodedAnchor !== undefined && encodedAnchor.length > 0) {
        const anchor = (0, excerpt_drag_1.decodeSourceAnchor)(encodedAnchor);
        if (anchor === undefined ||
            source.messageId === undefined ||
            anchor.messageId !== source.messageId ||
            anchor.sourceNodeId !== nodeId) {
            return undefined;
        }
        source.anchor = anchor;
    }
    return source;
}
class SourceLinkHandler {
    workspace;
    constructor(workspace) {
        this.workspace = workspace;
    }
    async open(parameters) {
        const source = sourceFromParameters(parameters);
        if (source === undefined)
            return "missing";
        return (await this.workspace.openActive(source)) ||
            (await this.workspace.openHistory(source))
            ? "opened"
            : "missing";
    }
}
exports.SourceLinkHandler = SourceLinkHandler;

},
"providers/active-response-requests.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActiveResponseRequests = void 0;
class ActiveResponseRequests {
    router;
    requests = new Map();
    constructor(router) {
        this.router = router;
    }
    has(conversationId) {
        return this.requests.has(conversationId);
    }
    begin(conversationId, ticket, messageId) {
        if (this.requests.has(conversationId)) {
            throw new Error("A response is already active for this conversation");
        }
        const handle = {
            conversationId,
            ticket,
            messageId,
            controller: new AbortController(),
            finalized: false
        };
        this.requests.set(conversationId, handle);
        return handle;
    }
    finish(handle, status, now, finalContent, referencedNoteNames) {
        if (handle.finalized ||
            this.requests.get(handle.conversationId) !== handle) {
            return;
        }
        this.router.finish(handle.ticket, {
            conversationId: handle.ticket.conversationId,
            nodeId: handle.ticket.nodeId,
            messageId: handle.messageId,
            status,
            now,
            ...(finalContent === undefined ? {} : { finalContent }),
            ...(status !== "complete" || referencedNoteNames === undefined
                ? {}
                : { referencedNoteNames: [...referencedNoteNames] })
        });
        handle.finalized = true;
    }
    interrupt(conversationId, now) {
        const handle = this.requests.get(conversationId);
        if (handle === undefined)
            return false;
        try {
            this.finish(handle, "interrupted", now);
        }
        finally {
            handle.controller.abort();
        }
        return true;
    }
    interruptAll(now) {
        for (const conversationId of [...this.requests.keys()]) {
            this.interrupt(conversationId, now);
        }
    }
    release(handle) {
        if (this.requests.get(handle.conversationId) === handle) {
            this.requests.delete(handle.conversationId);
        }
    }
}
exports.ActiveResponseRequests = ActiveResponseRequests;

},
"providers/anthropic-provider.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnthropicProvider = void 0;
const stream_parser_1 = require("./stream-parser");
class AnthropicProvider {
    kind = "anthropic";
    buildRequest(input, profile) {
        const system = input.messages
            .filter((message) => message.role === "system")
            .map((message) => message.content)
            .join("\n\n");
        const messages = input.messages
            .filter((message) => message.role !== "system")
            .map((message) => ({
            role: message.role,
            content: [{ type: "text", text: message.content }]
        }));
        return {
            url: `${(profile.baseUrl || "https://api.anthropic.com").replace(/\/+$/u, "")}/v1/messages`,
            method: "POST",
            headers: {
                "x-api-key": profile.apiKey,
                "anthropic-version": "2023-06-01",
                "Content-Type": "application/json"
            },
            body: {
                model: input.model,
                max_tokens: input.maxOutputTokens ?? 4096,
                stream: input.stream,
                system,
                messages
            }
        };
    }
    parseBuffered(value) {
        const body = value;
        const text = body.content
            ?.filter((part) => part.type === "text" && typeof part.text === "string")
            .map((part) => part.text)
            .join("");
        return text === undefined
            ? [{ type: "error", message: "模型没有返回文本内容" }]
            : [{ type: "delta", text }, { type: "done" }];
    }
    createStreamParser() {
        return (0, stream_parser_1.createSseParser)(stream_parser_1.decodeAnthropicEvent);
    }
}
exports.AnthropicProvider = AnthropicProvider;

},
"providers/deepseek-provider.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeepSeekProvider = void 0;
const stream_parser_1 = require("./stream-parser");
function join(baseUrl, path) {
    return `${baseUrl.replace(/\/+$/u, "")}/${path.replace(/^\/+/u, "")}`;
}
function deepSeekApiRoot(baseUrl) {
    const configured = baseUrl.trim().length > 0 ? baseUrl.trim() : "https://api.deepseek.com";
    try {
        const parsed = new URL(configured);
        if (parsed.hostname.toLowerCase() === "api.deepseek.com") {
            return `${parsed.protocol}//${parsed.host}`;
        }
    }
    catch {
        // Fall through to tolerant path cleanup for custom compatible endpoints.
    }
    return configured
        .replace(/\/+$/u, "")
        .replace(/\/(?:anthropic(?:\/v1(?:\/messages)?)?|chat\/completions)$/u, "");
}
function anthropicBaseUrl(baseUrl) {
    return join(deepSeekApiRoot(baseUrl), "anthropic");
}
function anthropicMessages(input) {
    const system = input.messages
        .filter((message) => message.role === "system")
        .map((message) => message.content)
        .join("\n\n");
    const messages = input.messages.flatMap((message) => {
        if (message.role === "system")
            return [];
        return [
            {
                role: message.role,
                content: [{ type: "text", text: message.content }]
            }
        ];
    });
    if (input.anthropicContinuation !== undefined) {
        messages.push({
            role: "assistant",
            content: input.anthropicContinuation
        });
    }
    return { system, messages };
}
function parseAnthropicBuffered(value) {
    const body = value;
    if (typeof body.error?.message === "string") {
        return [{ type: "error", message: body.error.message }];
    }
    const content = Array.isArray(body.content) ? body.content : [];
    const events = [];
    const usage = (0, stream_parser_1.normalizeAnthropicUsage)(body.usage);
    if (usage !== undefined)
        events.push({ type: "usage", usage });
    for (const entry of content) {
        const block = entry;
        if (block.type === "server_tool_use" && block.name === "web_search") {
            events.push({ type: "search-status", status: "searching" });
        }
        if (block.type === "web_search_tool_result") {
            events.push({ type: "search-status", status: "complete" });
            const sources = (0, stream_parser_1.extractWebSearchSources)(block);
            if (sources.length > 0)
                events.push({ type: "sources", sources });
        }
        if (block.type === "text" && typeof block.text === "string") {
            events.push({ type: "delta", text: block.text });
        }
    }
    if (body.stop_reason === "pause_turn") {
        events.push({ type: "pause", content: structuredClone(content) });
    }
    else {
        events.push({ type: "done" });
    }
    return events;
}
function shouldUseAnthropicTransport(baseUrl) {
    const configured = baseUrl.trim();
    if (configured.length === 0)
        return true;
    try {
        return new URL(configured).hostname.toLowerCase() === "api.deepseek.com";
    }
    catch {
        return /api\.deepseek\.com/iu.test(configured);
    }
}
function anthropicRequest(input, profile) {
    const { system, messages } = anthropicMessages(input);
    const webSearch = input.webSearchEnabled === true;
    return {
        url: join(anthropicBaseUrl(profile.baseUrl), "v1/messages"),
        method: "POST",
        headers: {
            "x-api-key": profile.apiKey,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json"
        },
        body: {
            model: input.model,
            max_tokens: input.maxOutputTokens ?? 8192,
            stream: input.stream,
            system,
            messages,
            ...(input.thinkingEnabled === undefined
                ? {}
                : { thinking: { type: input.thinkingEnabled ? "enabled" : "disabled" } }),
            ...(webSearch
                ? {
                    tools: [
                        {
                            type: "web_search_20250305",
                            name: "web_search",
                            max_uses: 5
                        }
                    ],
                    tool_choice: { type: "auto" }
                }
                : {})
        },
        responseFormat: "anthropic"
    };
}
class DeepSeekProvider {
    kind = "deepseek";
    buildRequest(input, profile) {
        if (input.webSearchEnabled === true || shouldUseAnthropicTransport(profile.baseUrl)) {
            return anthropicRequest(input, profile);
        }
        const base = deepSeekApiRoot(profile.baseUrl);
        return {
            url: join(base, "chat/completions"),
            method: "POST",
            headers: {
                Authorization: `Bearer ${profile.apiKey}`,
                "Content-Type": "application/json"
            },
            body: {
                model: input.model,
                messages: input.messages,
                stream: input.stream,
                ...(input.stream ? { stream_options: { include_usage: true } } : {}),
                ...(input.maxOutputTokens === undefined
                    ? {}
                    : { max_tokens: input.maxOutputTokens }),
                ...(input.thinkingEnabled === undefined || !shouldUseAnthropicTransport(profile.baseUrl)
                    ? {}
                    : { thinking: { type: input.thinkingEnabled ? "enabled" : "disabled" } })
            },
            responseFormat: "openai"
        };
    }
    parseBuffered(value, request) {
        if (request?.responseFormat === "anthropic") {
            return parseAnthropicBuffered(value);
        }
        const body = value;
        const text = body.choices?.[0]?.message?.content;
        const events = [];
        if (typeof text === "string")
            events.push({ type: "delta", text });
        const usage = (0, stream_parser_1.normalizeOpenAiCompatibleUsage)(value);
        if (usage !== undefined)
            events.push({ type: "usage", usage });
        if (typeof text === "string")
            events.push({ type: "done" });
        return events.length > 0
            ? events
            : [{ type: "error", message: "模型没有返回文本内容" }];
    }
    createStreamParser(request) {
        return request?.responseFormat === "anthropic"
            ? (0, stream_parser_1.createAnthropicMessageParser)()
            : (0, stream_parser_1.createSseParser)(stream_parser_1.decodeOpenAiEvent);
    }
}
exports.DeepSeekProvider = DeepSeekProvider;

},
"providers/gemini-provider.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GeminiProvider = void 0;
const stream_parser_1 = require("./stream-parser");
class GeminiProvider {
    kind = "gemini";
    buildRequest(input, profile) {
        const base = (profile.baseUrl || "https://generativelanguage.googleapis.com/v1beta").replace(/\/+$/u, "");
        const system = input.messages
            .filter((message) => message.role === "system")
            .map((message) => message.content)
            .join("\n\n");
        return {
            url: `${base}/models/${encodeURIComponent(input.model)}:${input.stream ? "streamGenerateContent?alt=sse" : "generateContent"}`,
            method: "POST",
            headers: {
                "x-goog-api-key": profile.apiKey,
                "Content-Type": "application/json"
            },
            body: {
                systemInstruction: { parts: [{ text: system }] },
                ...(input.maxOutputTokens === undefined
                    ? {}
                    : { generationConfig: { maxOutputTokens: input.maxOutputTokens } }),
                contents: input.messages
                    .filter((message) => message.role !== "system")
                    .map((message) => ({
                    role: message.role === "assistant" ? "model" : "user",
                    parts: [{ text: message.content }]
                }))
            }
        };
    }
    parseBuffered(value) {
        const body = value;
        const text = body.candidates?.[0]?.content?.parts
            ?.map((part) => (typeof part.text === "string" ? part.text : ""))
            .join("");
        return text === undefined
            ? [{ type: "error", message: "模型没有返回文本内容" }]
            : [{ type: "delta", text }, { type: "done" }];
    }
    createStreamParser() {
        return (0, stream_parser_1.createSseParser)(stream_parser_1.decodeGeminiEvent);
    }
}
exports.GeminiProvider = GeminiProvider;

},
"providers/node-summary-coordinator.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NodeSummaryCoordinator = void 0;
const node_summary_1 = require("../domain/node-summary");
function key(tabId, nodeId) {
    return `${tabId}\u0000${nodeId}`;
}
function findQuestion(messages) {
    return messages.find((message) => message.role === "user");
}
function findFirstCompleteAnswer(messages) {
    return messages.find((message) => message.role === "assistant" && message.status === "complete");
}
function nodeIdsInTreeOrder(rootNodeId, nodes) {
    const ordered = [];
    const visited = new Set();
    const visit = (nodeId) => {
        if (visited.has(nodeId) || nodes[nodeId] === undefined)
            return;
        visited.add(nodeId);
        ordered.push(nodeId);
        for (const childId of nodes[nodeId].childIds)
            visit(childId);
    };
    visit(rootNodeId);
    for (const nodeId of Object.keys(nodes))
        visit(nodeId);
    return ordered;
}
class NodeSummaryCoordinator {
    tabs;
    providers;
    requests;
    runtime;
    inFlight = new Map();
    disposed = false;
    constructor(tabs, providers, requests, runtime) {
        this.tabs = tabs;
        this.providers = providers;
        this.requests = requests;
        this.runtime = runtime;
    }
    trigger(input) {
        const identity = key(input.tabId, input.nodeId);
        const existing = this.inFlight.get(identity);
        if (existing !== undefined)
            return existing.promise;
        if (this.disposed)
            return Promise.resolve();
        const controller = new AbortController();
        const promise = this.run(input, controller.signal).finally(() => {
            const current = this.inFlight.get(identity);
            if (current?.promise === promise)
                this.inFlight.delete(identity);
        });
        this.inFlight.set(identity, { promise, controller });
        return promise;
    }
    waitForNode(tabId, nodeId) {
        return this.inFlight.get(key(tabId, nodeId))?.promise ?? Promise.resolve();
    }
    async repairOpenTabs() {
        const profile = this.runtime.getProfile();
        if (profile.apiKey.trim().length === 0 || this.runtime.getModel().trim().length === 0) {
            return 0;
        }
        let attempted = 0;
        for (const tabId of this.tabs.getSnapshot().orderedTabIds) {
            const tab = this.tabs.getTab(tabId);
            if (tab === undefined ||
                tab.mode !== "active" ||
                tab.lifecycle !== "idle") {
                continue;
            }
            const nodeIds = nodeIdsInTreeOrder(tab.conversation.rootNodeId, tab.conversation.nodes);
            for (const nodeId of nodeIds) {
                const latestTab = this.tabs.getTab(tabId);
                const node = latestTab?.conversation.nodes[nodeId];
                const answer = node === undefined
                    ? undefined
                    : findFirstCompleteAnswer(node.messages);
                if (latestTab === undefined ||
                    latestTab.conversationId !== tab.conversationId ||
                    node === undefined ||
                    answer === undefined ||
                    !(0, node_summary_1.canAttemptNodeSummary)(node)) {
                    continue;
                }
                attempted += 1;
                await this.trigger({
                    tabId,
                    conversationId: tab.conversationId,
                    nodeId,
                    answerMessageId: answer.id
                });
                if (this.disposed)
                    return attempted;
            }
        }
        return attempted;
    }
    dispose() {
        this.disposed = true;
        for (const entry of this.inFlight.values())
            entry.controller.abort();
        this.inFlight.clear();
    }
    async run(input, signal) {
        const tab = this.tabs.getTab(input.tabId);
        if (tab === undefined ||
            tab.conversationId !== input.conversationId ||
            tab.mode !== "active" ||
            tab.lifecycle !== "idle") {
            return;
        }
        const node = tab.conversation.nodes[input.nodeId];
        const answer = node?.messages.find((message) => message.id === input.answerMessageId &&
            message.role === "assistant" &&
            message.status === "complete");
        const question = node === undefined ? undefined : findQuestion(node.messages);
        if (node === undefined ||
            answer === undefined ||
            question === undefined ||
            !(0, node_summary_1.canAttemptNodeSummary)(node)) {
            return;
        }
        const profile = this.runtime.getProfile();
        const model = this.runtime.getModel();
        this.tabs.updateConversation(input.tabId, (conversation) => (0, node_summary_1.markNodeSummaryPending)(conversation, {
            nodeId: input.nodeId,
            now: this.runtime.now(),
            providerProfileId: profile.id,
            modelId: model
        }));
        try {
            await this.runtime.persistPending?.(input.tabId);
            const pendingTab = this.tabs.getTab(input.tabId);
            const pendingNode = pendingTab?.conversation.nodes[input.nodeId];
            const pendingAnswer = pendingNode?.messages.find((message) => message.id === input.answerMessageId);
            const pendingQuestion = pendingNode === undefined
                ? undefined
                : findQuestion(pendingNode.messages);
            if (pendingTab === undefined ||
                pendingTab.conversationId !== input.conversationId ||
                pendingNode === undefined ||
                pendingAnswer === undefined ||
                pendingQuestion === undefined) {
                return;
            }
            const parentTitle = pendingNode.parentId === null
                ? undefined
                : pendingTab.conversation.nodes[pendingNode.parentId]?.title;
            const prompt = (0, node_summary_1.buildNodeSummaryPrompt)({
                ...(parentTitle === undefined ? {} : { parentTitle }),
                question: pendingQuestion,
                answer: pendingAnswer
            });
            const adapter = this.providers.get(profile);
            const request = adapter.buildRequest({
                messages: prompt.messages,
                model,
                stream: false,
                webSearchEnabled: false,
                maxOutputTokens: 64,
                thinkingEnabled: false
            }, profile);
            const raw = await this.requests.request(request, signal);
            if (signal.aborted || this.disposed)
                return;
            const events = adapter.parseBuffered(raw, request);
            let text = "";
            let failed = false;
            for (const event of events) {
                if (event.type === "delta")
                    text += event.text;
                if (event.type === "error")
                    failed = true;
            }
            const cleaned = failed ? undefined : (0, node_summary_1.cleanNodeSummaryTitle)(text);
            const latest = this.tabs.getTab(input.tabId);
            if (latest === undefined ||
                latest.conversationId !== input.conversationId ||
                latest.mode !== "active" ||
                latest.lifecycle !== "idle" ||
                latest.conversation.nodes[input.nodeId] === undefined ||
                signal.aborted ||
                this.disposed) {
                return;
            }
            this.tabs.updateConversation(input.tabId, (conversation) => cleaned === undefined
                ? (0, node_summary_1.applyNodeSummaryFailure)(conversation, {
                    nodeId: input.nodeId,
                    now: this.runtime.now()
                })
                : (0, node_summary_1.applyNodeSummarySuccess)(conversation, {
                    nodeId: input.nodeId,
                    title: cleaned,
                    now: this.runtime.now()
                }));
        }
        catch {
            if (signal.aborted || this.disposed)
                return;
            const latest = this.tabs.getTab(input.tabId);
            if (latest === undefined ||
                latest.conversationId !== input.conversationId ||
                latest.mode !== "active" ||
                latest.lifecycle !== "idle" ||
                latest.conversation.nodes[input.nodeId] === undefined) {
                return;
            }
            this.tabs.updateConversation(input.tabId, (conversation) => (0, node_summary_1.applyNodeSummaryFailure)(conversation, {
                nodeId: input.nodeId,
                now: this.runtime.now()
            }));
        }
    }
}
exports.NodeSummaryCoordinator = NodeSummaryCoordinator;

},
"providers/openai-provider.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAiProvider = void 0;
const stream_parser_1 = require("./stream-parser");
function join(baseUrl, path) {
    return `${baseUrl.replace(/\/+$/u, "")}/${path.replace(/^\/+/u, "")}`;
}
class OpenAiProvider {
    kind = "openai";
    buildRequest(input, profile) {
        const base = profile.baseUrl.trim().length > 0
            ? profile.baseUrl
            : "https://api.openai.com/v1";
        const official = profile.kind === "openai";
        return {
            url: join(base, "chat/completions"),
            method: "POST",
            headers: {
                Authorization: `Bearer ${profile.apiKey}`,
                "Content-Type": "application/json"
            },
            body: {
                model: input.model,
                messages: input.messages,
                stream: input.stream,
                ...(official && input.stream
                    ? { stream_options: { include_usage: true } }
                    : {}),
                ...(official && input.cacheKey !== undefined
                    ? { prompt_cache_key: input.cacheKey }
                    : {}),
                ...(input.maxOutputTokens === undefined
                    ? {}
                    : { max_tokens: input.maxOutputTokens })
            }
        };
    }
    parseBuffered(value) {
        const body = value;
        const text = body.choices?.[0]?.message?.content;
        const events = [];
        if (typeof text === "string")
            events.push({ type: "delta", text });
        const usage = (0, stream_parser_1.normalizeOpenAiCompatibleUsage)(value);
        if (usage !== undefined)
            events.push({ type: "usage", usage });
        if (typeof text === "string")
            events.push({ type: "done" });
        return events.length > 0
            ? events
            : [{ type: "error", message: "模型没有返回文本内容" }];
    }
    createStreamParser() {
        return (0, stream_parser_1.createSseParser)(stream_parser_1.decodeOpenAiEvent);
    }
}
exports.OpenAiProvider = OpenAiProvider;

},
"providers/provider-registry.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProviderRegistry = void 0;
const anthropic_provider_1 = require("./anthropic-provider");
const deepseek_provider_1 = require("./deepseek-provider");
const gemini_provider_1 = require("./gemini-provider");
const openai_provider_1 = require("./openai-provider");
class ProviderRegistry {
    openAi = new openai_provider_1.OpenAiProvider();
    deepSeek = new deepseek_provider_1.DeepSeekProvider();
    anthropic = new anthropic_provider_1.AnthropicProvider();
    gemini = new gemini_provider_1.GeminiProvider();
    get(profile) {
        if (profile.kind === "deepseek")
            return this.deepSeek;
        if (profile.kind === "anthropic")
            return this.anthropic;
        if (profile.kind === "gemini")
            return this.gemini;
        return this.openAi;
    }
}
exports.ProviderRegistry = ProviderRegistry;

},
"providers/stream-parser.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeOpenAiCompatibleUsage = normalizeOpenAiCompatibleUsage;
exports.normalizeAnthropicUsage = normalizeAnthropicUsage;
exports.extractWebSearchSources = extractWebSearchSources;
exports.createAnthropicMessageParser = createAnthropicMessageParser;
exports.decodeOpenAiEvent = decodeOpenAiEvent;
exports.decodeAnthropicEvent = decodeAnthropicEvent;
exports.decodeGeminiEvent = decodeGeminiEvent;
exports.createSseParser = createSseParser;
function asRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value)
        ? value
        : undefined;
}
function parseJson(data) {
    try {
        return asRecord(JSON.parse(data));
    }
    catch {
        return undefined;
    }
}
function textAt(value, path) {
    let current = value;
    for (const key of path) {
        current = asRecord(current)?.[key];
    }
    return typeof current === "string" ? current : undefined;
}
function numberAt(value, path) {
    let current = value;
    for (const key of path) {
        current = asRecord(current)?.[key];
    }
    return typeof current === "number" && Number.isFinite(current)
        ? current
        : undefined;
}
function normalizeOpenAiCompatibleUsage(value) {
    const source = asRecord(value);
    const usage = asRecord(source?.usage);
    if (usage === undefined)
        return undefined;
    const promptTokens = numberAt(usage, ["prompt_tokens"]);
    const completionTokens = numberAt(usage, ["completion_tokens"]);
    const deepSeekHit = numberAt(usage, ["prompt_cache_hit_tokens"]);
    const deepSeekMiss = numberAt(usage, ["prompt_cache_miss_tokens"]);
    const openAiHit = numberAt(usage, ["prompt_tokens_details", "cached_tokens"]);
    const cacheHitTokens = deepSeekHit ?? openAiHit;
    const cacheMissTokens = deepSeekMiss ??
        (promptTokens !== undefined && cacheHitTokens !== undefined
            ? Math.max(0, promptTokens - cacheHitTokens)
            : undefined);
    if (promptTokens === undefined &&
        completionTokens === undefined &&
        cacheHitTokens === undefined &&
        cacheMissTokens === undefined) {
        return undefined;
    }
    return {
        ...(promptTokens === undefined ? {} : { promptTokens }),
        ...(completionTokens === undefined ? {} : { completionTokens }),
        ...(cacheHitTokens === undefined ? {} : { cacheHitTokens }),
        ...(cacheMissTokens === undefined ? {} : { cacheMissTokens }),
        providerReported: true
    };
}
function normalizeAnthropicUsage(value) {
    const usage = asRecord(value);
    if (usage === undefined)
        return undefined;
    const inputTokens = numberAt(usage, ["input_tokens"]);
    const outputTokens = numberAt(usage, ["output_tokens"]);
    const cacheReadTokens = numberAt(usage, ["cache_read_input_tokens"]);
    const cacheCreationTokens = numberAt(usage, ["cache_creation_input_tokens"]);
    const promptParts = [inputTokens, cacheReadTokens, cacheCreationTokens].filter((entry) => entry !== undefined);
    const promptTokens = promptParts.length === 0
        ? undefined
        : promptParts.reduce((total, entry) => total + entry, 0);
    const cacheMissTokens = inputTokens === undefined && cacheCreationTokens === undefined
        ? undefined
        : (inputTokens ?? 0) + (cacheCreationTokens ?? 0);
    if (promptTokens === undefined &&
        outputTokens === undefined &&
        cacheReadTokens === undefined &&
        cacheMissTokens === undefined) {
        return undefined;
    }
    return {
        ...(promptTokens === undefined ? {} : { promptTokens }),
        ...(outputTokens === undefined ? {} : { completionTokens: outputTokens }),
        ...(cacheReadTokens === undefined
            ? {}
            : { cacheHitTokens: cacheReadTokens }),
        ...(cacheMissTokens === undefined ? {} : { cacheMissTokens }),
        providerReported: true
    };
}
function extractWebSearchSources(value) {
    const sources = new Map();
    const visit = (current) => {
        if (Array.isArray(current)) {
            for (const entry of current)
                visit(entry);
            return;
        }
        const record = asRecord(current);
        if (record === undefined)
            return;
        const url = typeof record.url === "string" ? record.url.trim() : "";
        if (/^https?:\/\//iu.test(url)) {
            const title = typeof record.title === "string" && record.title.trim().length > 0
                ? record.title.trim()
                : url;
            sources.set(url, { title, url });
        }
        for (const nested of Object.values(record))
            visit(nested);
    };
    visit(value);
    return [...sources.values()];
}
function createAnthropicMessageParser() {
    const blocks = new Map();
    const partialInputs = new Map();
    let stopReason;
    const decoder = (record) => {
        const value = parseJson(record.data);
        if (value === undefined) {
            return [{ type: "error", message: "无法解析模型流式响应" }];
        }
        if (record.event === "error" || value.type === "error") {
            return [
                {
                    type: "error",
                    message: textAt(value, ["error", "message"]) ?? "模型返回流式错误"
                }
            ];
        }
        const type = typeof value.type === "string" ? value.type : record.event;
        if (type === "message_start") {
            const usage = normalizeAnthropicUsage(asRecord(value.message)?.usage);
            return usage === undefined ? [] : [{ type: "usage", usage }];
        }
        if (type === "content_block_start") {
            const index = numberAt(value, ["index"]);
            const block = asRecord(value.content_block);
            if (index === undefined || block === undefined)
                return [];
            const copy = structuredClone(block);
            blocks.set(index, copy);
            if (copy.type === "server_tool_use" && copy.name === "web_search") {
                return [{ type: "search-status", status: "searching" }];
            }
            if (copy.type === "web_search_tool_result") {
                const sources = extractWebSearchSources(copy);
                return [
                    { type: "search-status", status: "complete" },
                    ...(sources.length === 0 ? [] : [{ type: "sources", sources }])
                ];
            }
            return [];
        }
        if (type === "content_block_delta") {
            const index = numberAt(value, ["index"]);
            const delta = asRecord(value.delta);
            if (index === undefined || delta === undefined)
                return [];
            const block = blocks.get(index);
            if (delta.type === "text_delta" && typeof delta.text === "string") {
                if (block !== undefined) {
                    block.text = `${typeof block.text === "string" ? block.text : ""}${delta.text}`;
                }
                return [{ type: "delta", text: delta.text }];
            }
            if (delta.type === "input_json_delta" &&
                typeof delta.partial_json === "string") {
                partialInputs.set(index, `${partialInputs.get(index) ?? ""}${delta.partial_json}`);
            }
            if (delta.type === "citations_delta" && block !== undefined) {
                const citations = Array.isArray(block.citations)
                    ? [...block.citations]
                    : [];
                if (delta.citation !== undefined)
                    citations.push(delta.citation);
                block.citations = citations;
            }
            return [];
        }
        if (type === "content_block_stop") {
            const index = numberAt(value, ["index"]);
            if (index === undefined)
                return [];
            const partial = partialInputs.get(index);
            const block = blocks.get(index);
            if (partial !== undefined && block !== undefined) {
                try {
                    block.input = JSON.parse(partial);
                }
                catch {
                    block.input = partial;
                }
            }
            return [];
        }
        if (type === "message_delta") {
            const events = [];
            const usage = normalizeAnthropicUsage(value.usage);
            if (usage !== undefined)
                events.push({ type: "usage", usage });
            const candidate = textAt(value, ["delta", "stop_reason"]);
            if (candidate !== undefined) {
                stopReason = candidate;
                if (candidate !== "pause_turn")
                    events.push({ type: "finish" });
            }
            return events;
        }
        if (type === "message_stop") {
            const content = [...blocks.entries()]
                .sort(([left], [right]) => left - right)
                .map(([, block]) => structuredClone(block));
            if (stopReason === "pause_turn")
                return [{ type: "pause", content }];
            return [{ type: "done" }];
        }
        return [];
    };
    return createSseParser(decoder);
}
function decodeOpenAiEvent(record) {
    if (record.data.trim() === "[DONE]")
        return [{ type: "done" }];
    const value = parseJson(record.data);
    if (value === undefined) {
        return [{ type: "error", message: "无法解析模型流式响应" }];
    }
    const error = textAt(value, ["error", "message"]);
    if (error !== undefined)
        return [{ type: "error", message: error }];
    const events = [];
    const usage = normalizeOpenAiCompatibleUsage(value);
    if (usage !== undefined)
        events.push({ type: "usage", usage });
    const choices = value.choices;
    if (!Array.isArray(choices))
        return events;
    const first = asRecord(choices[0]);
    const text = textAt(first, ["delta", "content"]);
    if (text !== undefined)
        events.push({ type: "delta", text });
    if (typeof first?.finish_reason === "string") {
        events.push({ type: "finish" });
    }
    return events;
}
function decodeAnthropicEvent(record) {
    const value = parseJson(record.data);
    if (value === undefined) {
        return [{ type: "error", message: "无法解析模型流式响应" }];
    }
    if (record.event === "error" || value.type === "error") {
        return [
            {
                type: "error",
                message: textAt(value, ["error", "message"]) ?? "模型返回流式错误"
            }
        ];
    }
    if (record.event === "message_stop" || value.type === "message_stop") {
        return [{ type: "done" }];
    }
    const text = textAt(value, ["delta", "text"]);
    return text === undefined ? [] : [{ type: "delta", text }];
}
function decodeGeminiEvent(record) {
    const value = parseJson(record.data);
    if (value === undefined) {
        return [{ type: "error", message: "无法解析模型流式响应" }];
    }
    const error = textAt(value, ["error", "message"]);
    if (error !== undefined)
        return [{ type: "error", message: error }];
    const candidates = value.candidates;
    if (!Array.isArray(candidates))
        return [];
    const first = asRecord(candidates[0]);
    const content = asRecord(first?.content);
    const parts = content?.parts;
    const partText = Array.isArray(parts) ? asRecord(parts[0])?.text : undefined;
    const events = [];
    if (typeof partText === "string") {
        events.push({ type: "delta", text: partText });
    }
    if (typeof first?.finishReason === "string") {
        events.push({ type: "done" });
    }
    return events;
}
function decodeBlock(block, decoder) {
    let event = "";
    const data = [];
    for (const line of block.split(/\r?\n/u)) {
        if (line.startsWith("event:"))
            event = line.slice(6).trim();
        if (line.startsWith("data:"))
            data.push(line.slice(5).trimStart());
    }
    if (data.length === 0)
        return [];
    return decoder({ event, data: data.join("\n") });
}
function createSseParser(decoder) {
    let buffer = "";
    const drain = (flush) => {
        const events = [];
        const blocks = buffer.split(/\r?\n\r?\n/u);
        buffer = flush ? "" : (blocks.pop() ?? "");
        for (const block of blocks) {
            events.push(...decodeBlock(block, decoder));
        }
        if (flush && buffer.length > 0) {
            events.push(...decodeBlock(buffer, decoder));
            buffer = "";
        }
        return events;
    };
    return {
        push(chunk) {
            buffer += chunk;
            return drain(false);
        },
        finish() {
            const final = buffer;
            buffer = "";
            return final.length === 0 ? [] : decodeBlock(final, decoder);
        }
    };
}

},
"providers/streaming-transport.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StreamingProviderTransport = exports.StreamingUnavailableError = void 0;
exports.canUseBufferedFallback = canUseBufferedFallback;
exports.assertStreamCompleted = assertStreamCompleted;
class StreamingUnavailableError extends Error {
    constructor(message = "Streaming response has no readable body") {
        super(message);
        this.name = "StreamingUnavailableError";
    }
}
exports.StreamingUnavailableError = StreamingUnavailableError;
function canUseBufferedFallback(error) {
    return error instanceof StreamingUnavailableError;
}
function assertStreamCompleted(receivedText, receivedDone) {
    if (!receivedText)
        throw new Error("Empty streaming response");
    if (!receivedDone)
        throw new Error("Streaming response ended without a completion frame");
}
class StreamingProviderTransport {
    fetcher;
    constructor(fetcher = (url, init) => fetch(url, init)) {
        this.fetcher = fetcher;
    }
    async *stream(adapter, request, signal) {
        const response = await this.fetcher(request.url, {
            method: request.method,
            headers: request.headers,
            body: JSON.stringify(request.body),
            signal
        });
        if (!response.ok)
            throw new Error(`HTTP ${String(response.status)}`);
        if (response.body === null)
            throw new StreamingUnavailableError();
        const parser = adapter.createStreamParser(request);
        const decoder = new TextDecoder();
        const reader = response.body.getReader();
        try {
            let chunk = await reader.read();
            while (!chunk.done) {
                const text = decoder.decode(chunk.value, { stream: true });
                for (const event of parser.push(text))
                    yield event;
                chunk = await reader.read();
            }
            const tail = decoder.decode();
            if (tail.length > 0) {
                for (const event of parser.push(tail))
                    yield event;
            }
            for (const event of parser.finish())
                yield event;
        }
        finally {
            reader.releaseLock();
        }
    }
}
exports.StreamingProviderTransport = StreamingProviderTransport;

},
"providers/transient-response-status-store.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransientResponseStatusStore = void 0;
class TransientResponseStatusStore {
    records = new Map();
    listeners = new Set();
    get(messageId) {
        return this.records.get(messageId);
    }
    set(messageId, status) {
        if (this.records.get(messageId) === status)
            return;
        this.records.set(messageId, status);
        this.emit();
    }
    delete(messageId) {
        if (!this.records.delete(messageId))
            return;
        this.emit();
    }
    clear() {
        if (this.records.size === 0)
            return;
        this.records.clear();
        this.emit();
    }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
    emit() {
        for (const listener of this.listeners)
            listener();
    }
}
exports.TransientResponseStatusStore = TransientResponseStatusStore;

},
"providers/transient-usage-store.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransientUsageStore = void 0;
exports.shouldDisplayTokenStats = shouldDisplayTokenStats;
function shouldDisplayTokenStats(input) {
    if (input.mode === "full") {
        return ((input.sentEstimatedTokens ?? 0) > 0 ||
            input.promptTokens !== undefined ||
            input.completionTokens !== undefined ||
            (input.cacheHitTokens ?? 0) > 0);
    }
    return (input.reducedTokens >= 256 ||
        input.reductionRatio >= 0.05 ||
        (input.cacheHitTokens ?? 0) > 0);
}
class TransientUsageStore {
    records = new Map();
    listeners = new Set();
    get(messageId) {
        const record = this.records.get(messageId);
        return record === undefined ? undefined : { ...record };
    }
    set(messageId, record) {
        this.records.set(messageId, { ...record });
        for (const listener of this.listeners)
            listener();
    }
    delete(messageId) {
        if (!this.records.delete(messageId))
            return;
        for (const listener of this.listeners)
            listener();
    }
    clear() {
        if (this.records.size === 0)
            return;
        this.records.clear();
        for (const listener of this.listeners)
            listener();
    }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
}
exports.TransientUsageStore = TransientUsageStore;

},
"providers/transport.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProviderTransport = void 0;
class ProviderTransport {
    bufferedRequest;
    timeoutMilliseconds;
    constructor(bufferedRequest, timeoutMilliseconds = 60_000) {
        this.bufferedRequest = bufferedRequest;
        this.timeoutMilliseconds = timeoutMilliseconds;
    }
    async complete(adapter, request, signal) {
        const controller = new AbortController();
        const relay = () => controller.abort();
        signal?.addEventListener("abort", relay, { once: true });
        const timeout = window.setTimeout(() => controller.abort(), this.timeoutMilliseconds);
        try {
            const value = await this.bufferedRequest.request(request, controller.signal);
            return adapter.parseBuffered(value, request);
        }
        catch (error) {
            const message = error instanceof Error && error.name === "AbortError"
                ? "请求已取消或超时"
                : "模型请求失败，请检查服务配置";
            return [{ type: "error", message }];
        }
        finally {
            window.clearTimeout(timeout);
            signal?.removeEventListener("abort", relay);
        }
    }
}
exports.ProviderTransport = ProviderTransport;

},
"providers/types.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

},
"state/conversation-session-store.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationSessionStore = void 0;
const schema_1 = require("../domain/schema");
class ConversationSessionStore {
    conversation;
    listeners = new Set();
    constructor(initial) {
        this.conversation = (0, schema_1.parseConversation)(structuredClone(initial));
    }
    getSnapshot() {
        return this.conversation;
    }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
    update(updater) {
        const next = (0, schema_1.parseConversation)(updater(this.conversation));
        if (next === this.conversation)
            return;
        this.conversation = next;
        for (const listener of this.listeners)
            listener();
    }
    replace(conversation) {
        this.update(() => conversation);
    }
    selectNode(nodeId) {
        if (this.conversation.nodes[nodeId] === undefined) {
            throw new Error(`Node not found: ${nodeId}`);
        }
        this.update((conversation) => ({
            ...structuredClone(conversation),
            currentNodeId: nodeId
        }));
    }
}
exports.ConversationSessionStore = ConversationSessionStore;

},
"storage/checksum.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checksumConversation = checksumConversation;
exports.verifyConversationChecksum = verifyConversationChecksum;
function canonicalize(value) {
    if (value === null || typeof value !== "object") {
        return JSON.stringify(value);
    }
    if (Array.isArray(value)) {
        return `[${value.map((entry) => canonicalize(entry)).join(",")}]`;
    }
    const source = value;
    const entries = Object.keys(source)
        .sort()
        .map((key) => `${JSON.stringify(key)}:${canonicalize(source[key])}`);
    return `{${entries.join(",")}}`;
}
function checksumPayload(conversation) {
    return canonicalize({
        ...conversation,
        checksum: ""
    });
}
async function sha256(value) {
    const bytes = new TextEncoder().encode(value);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    return [...new Uint8Array(digest)]
        .map((byte) => byte.toString(16).padStart(2, "0"))
        .join("");
}
async function checksumConversation(conversation) {
    return sha256(checksumPayload(conversation));
}
async function verifyConversationChecksum(conversation) {
    return conversation.checksum === (await checksumConversation(conversation));
}

},
"storage/conversation-index.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationIndex = void 0;
const schema_1 = require("../domain/schema");
class ConversationIndex {
    vault;
    root;
    foldersByConversationId = new Map();
    constructor(vault, root) {
        this.vault = vault;
        this.root = root;
    }
    async rebuild() {
        const next = new Map();
        const paths = await this.vault.list(`${this.root}/`);
        for (const path of paths) {
            if (!path.endsWith("/tree.json"))
                continue;
            try {
                const conversation = (0, schema_1.parseConversation)(JSON.parse(await this.vault.read(path)));
                next.set(conversation.id, path.slice(0, -"/tree.json".length));
            }
            catch {
                // Invalid conversation files remain available for repository recovery.
            }
        }
        this.foldersByConversationId.clear();
        for (const [id, folder] of next) {
            this.foldersByConversationId.set(id, folder);
        }
    }
    resolve(conversationId) {
        return this.foldersByConversationId.get(conversationId);
    }
    onRename(oldPath, newPath) {
        for (const [conversationId, folder] of this.foldersByConversationId) {
            if (folder === oldPath || folder.startsWith(`${oldPath}/`)) {
                this.foldersByConversationId.set(conversationId, `${newPath}${folder.slice(oldPath.length)}`);
            }
        }
    }
}
exports.ConversationIndex = ConversationIndex;

},
"storage/conversation-repository.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationRepository = exports.RepositoryError = void 0;
const schema_1 = require("../domain/schema");
const checksum_1 = require("./checksum");
class RepositoryError extends Error {
    code;
    constructor(code, message, options) {
        super(message, options);
        this.code = code;
        this.name = "RepositoryError";
    }
}
exports.RepositoryError = RepositoryError;
async function readValidConversation(vault, path, source) {
    if (!(await vault.exists(path)))
        return undefined;
    try {
        const parsed = (0, schema_1.parseConversation)(JSON.parse(await vault.read(path)));
        if (!(await (0, checksum_1.verifyConversationChecksum)(parsed)))
            return undefined;
        return { conversation: parsed, source };
    }
    catch {
        return undefined;
    }
}
function serialize(conversation) {
    return `${JSON.stringify(conversation, null, 2)}\n`;
}
class ConversationRepository {
    vault;
    queues = new Map();
    constructor(vault) {
        this.vault = vault;
    }
    async load(folder) {
        const candidates = (await Promise.all([
            readValidConversation(this.vault, `${folder}/tree.json`, "canonical"),
            readValidConversation(this.vault, `${folder}/tree.backup.json`, "backup")
        ])).filter((candidate) => candidate !== undefined);
        if (candidates.length === 0) {
            throw new RepositoryError("conversation-not-found", `No valid conversation data exists in ${folder}`);
        }
        candidates.sort((left, right) => {
            const revisionDifference = right.conversation.revision - left.conversation.revision;
            if (revisionDifference !== 0)
                return revisionDifference;
            return left.source === "canonical" ? -1 : 1;
        });
        const selected = candidates[0];
        if (selected === undefined) {
            throw new RepositoryError("invalid-conversation", "Unable to choose conversation data");
        }
        return selected;
    }
    async save(folder, conversation, expectedRevision) {
        let result;
        await this.enqueue(folder, async () => {
            result = await this.saveNow(folder, conversation, expectedRevision);
        });
        if (result === undefined) {
            throw new RepositoryError("invalid-conversation", "Conversation was not saved");
        }
        return result;
    }
    async saveNow(folder, conversation, expectedRevision) {
        const canonicalPath = `${folder}/tree.json`;
        const backupPath = `${folder}/tree.backup.json`;
        const temporaryPath = `${folder}/tree.tmp.json`;
        const existing = await readValidConversation(this.vault, canonicalPath, "canonical");
        if (existing !== undefined && existing.conversation.revision !== expectedRevision) {
            const conflictPath = `${folder}/tree.conflict-r${String(conversation.revision)}.json`;
            await this.vault.write(conflictPath, serialize(conversation));
            throw new RepositoryError("revision-conflict", `Expected revision ${String(expectedRevision)}, found ${String(existing.conversation.revision)}`);
        }
        const candidateValue = structuredClone(conversation);
        candidateValue.checksum = await (0, checksum_1.checksumConversation)(candidateValue);
        const candidate = (0, schema_1.parseConversation)(candidateValue);
        const serialized = serialize(candidate);
        await this.vault.write(temporaryPath, serialized);
        const verifiedTemporary = await readValidConversation(this.vault, temporaryPath, "canonical");
        if (verifiedTemporary === undefined) {
            throw new RepositoryError("invalid-conversation", "Temporary conversation failed validation");
        }
        try {
            if (await this.vault.exists(canonicalPath)) {
                await this.vault.write(backupPath, await this.vault.read(canonicalPath));
            }
            await this.vault.write(canonicalPath, serialized);
        }
        finally {
            if (await this.vault.exists(temporaryPath)) {
                try {
                    await this.vault.remove(temporaryPath);
                }
                catch {
                    // The canonical file is already verified and committed. A stale
                    // temporary file is safe to overwrite during the next save.
                }
            }
        }
        return candidate;
    }
    async enqueue(folder, operation) {
        const previous = this.queues.get(folder) ?? Promise.resolve();
        const current = previous.catch(() => undefined).then(operation);
        this.queues.set(folder, current);
        try {
            await current;
        }
        finally {
            if (this.queues.get(folder) === current) {
                this.queues.delete(folder);
            }
        }
    }
}
exports.ConversationRepository = ConversationRepository;

},
"storage/obsidian-private-storage-port.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObsidianPrivateStoragePort = void 0;
const obsidian_1 = require("obsidian");
function parentDirectory(path) {
    const slash = path.lastIndexOf("/");
    return slash < 0 ? "" : path.slice(0, slash);
}
async function ensureFolder(adapter, path) {
    const normalized = (0, obsidian_1.normalizePath)(path);
    if (normalized.length === 0)
        return;
    const pieces = normalized.split("/");
    let current = "";
    for (const piece of pieces) {
        current = current.length === 0 ? piece : `${current}/${piece}`;
        if (!(await adapter.exists(current))) {
            await adapter.mkdir(current);
        }
    }
}
class ObsidianPrivateStoragePort {
    adapter;
    constructor(adapter) {
        this.adapter = adapter;
    }
    exists(path) {
        return this.adapter.exists((0, obsidian_1.normalizePath)(path));
    }
    read(path) {
        return this.adapter.read((0, obsidian_1.normalizePath)(path));
    }
    async write(path, content) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        await ensureFolder(this.adapter, parentDirectory(normalized));
        await this.adapter.write(normalized, content);
    }
    async process(path, update) {
        await this.adapter.process((0, obsidian_1.normalizePath)(path), update);
    }
    async remove(path) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        if (await this.adapter.exists(normalized)) {
            await this.adapter.remove(normalized);
        }
    }
    async list(prefix) {
        const root = (0, obsidian_1.normalizePath)(prefix).replace(/\/+$/u, "");
        if (!(await this.adapter.exists(root)))
            return [];
        const files = [];
        const visit = async (folder) => {
            const listed = await this.adapter.list(folder);
            files.push(...listed.files);
            for (const child of listed.folders) {
                await visit(child);
            }
        };
        await visit(root);
        return files.sort();
    }
    async move(source, destination) {
        const normalizedSource = (0, obsidian_1.normalizePath)(source);
        const normalizedDestination = (0, obsidian_1.normalizePath)(destination);
        if (await this.adapter.exists(normalizedDestination)) {
            throw new Error(`Destination already exists: ${destination}`);
        }
        if (!(await this.adapter.exists(normalizedSource))) {
            throw new Error(`Folder not found: ${source}`);
        }
        await ensureFolder(this.adapter, parentDirectory(normalizedDestination));
        await this.adapter.rename(normalizedSource, normalizedDestination);
    }
    async removeFolder(path) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        if (await this.adapter.exists(normalized)) {
            await this.adapter.rmdir(normalized, true);
        }
    }
}
exports.ObsidianPrivateStoragePort = ObsidianPrivateStoragePort;

},
"storage/obsidian-vault-port.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObsidianVaultPort = void 0;
const obsidian_1 = require("obsidian");
async function ensureFolder(vault, path) {
    const pieces = (0, obsidian_1.normalizePath)(path).split("/");
    let current = "";
    for (const piece of pieces) {
        current = current.length === 0 ? piece : `${current}/${piece}`;
        if (vault.getAbstractFileByPath(current) === null) {
            await vault.createFolder(current);
        }
    }
}
async function listAdapterFiles(vault, prefix) {
    const normalized = (0, obsidian_1.normalizePath)(prefix).replace(/\/+$/u, "");
    const excludedRoots = new Set([
        (0, obsidian_1.normalizePath)(vault.configDir),
        ".git",
        ".trash"
    ]);
    const files = [];
    const queue = [normalized];
    while (queue.length > 0) {
        const folder = queue.shift();
        if (folder === undefined)
            continue;
        let listed;
        try {
            listed = await vault.adapter.list(folder);
        }
        catch {
            continue;
        }
        files.push(...listed.files.map((path) => (0, obsidian_1.normalizePath)(path)));
        for (const child of listed.folders.map((path) => (0, obsidian_1.normalizePath)(path))) {
            const root = child.split("/")[0] ?? child;
            if (excludedRoots.has(child) || excludedRoots.has(root))
                continue;
            queue.push(child);
        }
    }
    return [...new Set(files)].sort();
}
class ObsidianVaultPort {
    vault;
    fileManager;
    constructor(vault, fileManager) {
        this.vault = vault;
        this.fileManager = fileManager;
    }
    async exists(path) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        if (this.vault.getAbstractFileByPath(normalized) !== null)
            return true;
        return this.vault.adapter.exists(normalized);
    }
    async read(path) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        const file = this.vault.getAbstractFileByPath(normalized);
        if (file instanceof obsidian_1.TFile)
            return this.vault.read(file);
        if (await this.vault.adapter.exists(normalized)) {
            return this.vault.adapter.read(normalized);
        }
        throw new Error(`File not found: ${path}`);
    }
    async write(path, content) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        const existing = this.vault.getAbstractFileByPath(normalized);
        if (existing instanceof obsidian_1.TFile) {
            await this.vault.modify(existing, content);
            return;
        }
        const slash = normalized.lastIndexOf("/");
        if (slash > 0)
            await ensureFolder(this.vault, normalized.slice(0, slash));
        const fileName = normalized.slice(slash + 1);
        if (fileName.startsWith(".") || (await this.vault.adapter.exists(normalized))) {
            await this.vault.adapter.write(normalized, content);
            return;
        }
        await this.vault.create(normalized, content);
    }
    async process(path, update) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        const file = this.vault.getAbstractFileByPath(normalized);
        if (file instanceof obsidian_1.TFile) {
            await this.vault.process(file, update);
            return;
        }
        if (!(await this.vault.adapter.exists(normalized))) {
            throw new Error(`File not found: ${path}`);
        }
        await this.vault.adapter.process(normalized, update);
    }
    async remove(path) {
        const normalized = (0, obsidian_1.normalizePath)(path);
        const file = this.vault.getAbstractFileByPath(normalized);
        if (file !== null) {
            await this.vault.delete(file);
            return;
        }
        if (await this.vault.adapter.exists(normalized)) {
            await this.vault.adapter.remove(normalized);
        }
    }
    list(prefix) {
        const normalized = (0, obsidian_1.normalizePath)(prefix).replace(/\/+$/u, "");
        const directoryPrefix = normalized.length === 0 ? "" : `${normalized}/`;
        return Promise.resolve(this.vault
            .getFiles()
            .map((file) => file.path)
            .filter((path) => path.startsWith(directoryPrefix))
            .sort());
    }
    listAll(prefix) {
        return listAdapterFiles(this.vault, prefix);
    }
    async move(source, destination) {
        const normalizedSource = (0, obsidian_1.normalizePath)(source);
        const normalizedDestination = (0, obsidian_1.normalizePath)(destination);
        const target = this.vault.getAbstractFileByPath(normalizedSource);
        if (target === null)
            throw new Error(`Folder not found: ${source}`);
        if (this.fileManager === undefined) {
            throw new Error("FileManager is required for link-safe folder moves");
        }
        const slash = normalizedDestination.lastIndexOf("/");
        if (slash > 0)
            await ensureFolder(this.vault, normalizedDestination.slice(0, slash));
        if (this.vault.getAbstractFileByPath(normalizedDestination) !== null) {
            throw new Error(`Destination already exists: ${destination}`);
        }
        await this.fileManager.renameFile(target, normalizedDestination);
    }
}
exports.ObsidianVaultPort = ObsidianVaultPort;

},
"storage/persistence-scheduler.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchedPersistenceScheduler = void 0;
class BatchedPersistenceScheduler {
    persist;
    delayMilliseconds;
    timer;
    constructor(persist, delayMilliseconds = 100) {
        this.persist = persist;
        this.delayMilliseconds = delayMilliseconds;
    }
    schedule() {
        if (this.timer !== undefined)
            return;
        this.timer = setTimeout(() => {
            this.timer = undefined;
            this.persist();
        }, this.delayMilliseconds);
    }
    flush() {
        if (this.timer === undefined)
            return;
        clearTimeout(this.timer);
        this.timer = undefined;
        this.persist();
    }
}
exports.BatchedPersistenceScheduler = BatchedPersistenceScheduler;

},
"storage/private-paths.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.privateConversationRoots = privateConversationRoots;
exports.conversationFolder = conversationFolder;
function normalizeDirectory(path) {
    return path.replace(/\\/gu, "/").replace(/\/+$/u, "");
}
function privateConversationRoots(configDir) {
    const normalizedConfigDir = normalizeDirectory(configDir);
    const root = `${normalizedConfigDir}/treetalk-data`;
    return {
        root,
        active: `${root}/active`,
        history: `${root}/history`
    };
}
function conversationFolder(root, conversationId) {
    if (conversationId.length === 0 ||
        conversationId === "." ||
        conversationId === ".." ||
        conversationId.includes("/") ||
        conversationId.includes("\\")) {
        throw new Error(`Invalid conversation id: ${conversationId}`);
    }
    return `${normalizeDirectory(root)}/${conversationId}`;
}

},
"storage/runtime-private-storage.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPrivateStorageRuntime = createPrivateStorageRuntime;
const obsidian_private_storage_port_1 = require("./obsidian-private-storage-port");
const private_paths_1 = require("./private-paths");
function createPrivateStorageRuntime(vault) {
    return {
        roots: (0, private_paths_1.privateConversationRoots)(vault.configDir),
        port: new obsidian_private_storage_port_1.ObsidianPrivateStoragePort(vault.adapter)
    };
}

},
"storage/session-persistence.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionPersistence = void 0;
function asError(value) {
    return value instanceof Error ? value : new Error(String(value));
}
class SessionPersistence {
    repository;
    onError;
    revisions = new Map();
    renamedFolders = new Map();
    queues = new Map();
    failures = new Map();
    constructor(repository, onError) {
        this.repository = repository;
        this.onError = onError;
    }
    seed(folder, revision) {
        this.revisions.set(folder, revision);
    }
    forget(folder) {
        this.revisions.delete(folder);
        this.failures.delete(folder);
    }
    renameFolder(oldFolder, newFolder) {
        const resolvedOld = this.resolveFolder(oldFolder);
        this.renamedFolders.delete(newFolder);
        for (const [source, destination] of this.renamedFolders) {
            if (destination === resolvedOld) {
                this.renamedFolders.set(source, newFolder);
            }
        }
        this.renamedFolders.set(resolvedOld, newFolder);
        this.renamedFolders.set(oldFolder, newFolder);
        const revision = this.revisions.get(resolvedOld) ?? this.revisions.get(oldFolder);
        const failure = this.failures.get(resolvedOld) ?? this.failures.get(oldFolder);
        this.revisions.delete(resolvedOld);
        this.revisions.delete(oldFolder);
        this.failures.delete(resolvedOld);
        this.failures.delete(oldFolder);
        if (revision !== undefined)
            this.revisions.set(newFolder, revision);
        if (failure !== undefined)
            this.failures.set(newFolder, failure);
    }
    schedule(folder, conversation) {
        const pending = {
            folder,
            conversation: structuredClone(conversation)
        };
        const queueFolder = this.resolveFolder(folder);
        const previousQueues = this.queuesFor(queueFolder);
        const previous = Promise.all(previousQueues.map((queue) => queue.catch(() => undefined))).then(() => undefined);
        const next = previous.then(async () => {
            try {
                await this.persist(pending);
                this.failures.delete(this.resolveFolder(pending.folder));
            }
            catch (error) {
                const failure = asError(error);
                this.failures.set(this.resolveFolder(pending.folder), failure);
                this.onError?.(error);
            }
        });
        this.queues.set(queueFolder, next);
    }
    async flush(folder) {
        const queues = folder === undefined
            ? [...this.queues.values()]
            : this.queuesFor(this.resolveFolder(folder));
        await Promise.all(queues);
        const failures = folder === undefined
            ? [...this.failures.values()]
            : [...this.failures.entries()]
                .filter(([candidate]) => this.resolveFolder(candidate) === this.resolveFolder(folder))
                .map(([, error]) => error);
        const failure = failures[0];
        if (failure !== undefined)
            throw failure;
    }
    async persist(pending) {
        const folder = this.resolveFolder(pending.folder);
        const savedRevision = this.revisions.get(folder);
        if (savedRevision === pending.conversation.revision) {
            return;
        }
        const expectedRevision = savedRevision ?? pending.conversation.revision;
        let saved = await this.repository.save(folder, pending.conversation, expectedRevision);
        this.revisions.set(folder, saved.revision);
        const finalFolder = this.resolveFolder(pending.folder);
        if (finalFolder !== folder) {
            const finalRevision = this.revisions.get(finalFolder);
            saved = await this.repository.save(finalFolder, saved, finalRevision ?? saved.revision);
            this.revisions.set(finalFolder, saved.revision);
        }
    }
    resolveFolder(folder) {
        let current = folder;
        const visited = new Set();
        while (!visited.has(current)) {
            visited.add(current);
            const renamed = this.renamedFolders.get(current);
            if (renamed === undefined)
                break;
            current = renamed;
        }
        return current;
    }
    queuesFor(folder) {
        return [...this.queues.entries()]
            .filter(([candidate]) => this.resolveFolder(candidate) === folder)
            .map(([, queue]) => queue);
    }
}
exports.SessionPersistence = SessionPersistence;

},
"tabs/active-conversation-store.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActiveConversationStore = void 0;
const schema_1 = require("../domain/schema");
class ActiveConversationStore {
    tabs;
    constructor(tabs) {
        this.tabs = tabs;
    }
    getSnapshot() {
        return this.tabs.getActiveTab()?.conversation;
    }
    subscribe(listener) {
        let previous = this.viewSignature();
        return this.tabs.subscribe(() => {
            const next = this.viewSignature();
            if (next === previous)
                return;
            previous = next;
            listener();
        });
    }
    getMode() {
        return this.tabs.getActiveTab()?.mode;
    }
    canMutate() {
        const tab = this.tabs.getActiveTab();
        return (tab !== undefined &&
            tab.mode === "active" &&
            tab.lifecycle === "idle");
    }
    update(updater) {
        const tab = this.requireMutableActiveTab();
        this.tabs.updateConversation(tab.id, (conversation) => (0, schema_1.parseConversation)(updater(conversation)));
    }
    selectNode(nodeId) {
        const tab = this.tabs.getActiveTab();
        if (tab === undefined)
            throw new Error("No active conversation tab");
        if (tab.lifecycle !== "idle") {
            throw new Error("Conversation tab is busy");
        }
        if (tab.conversation.nodes[nodeId] === undefined) {
            throw new Error(`Node not found: ${nodeId}`);
        }
        this.tabs.updateConversation(tab.id, (current) => ({
            ...structuredClone(current),
            currentNodeId: nodeId
        }));
    }
    requireMutableActiveTab() {
        const tab = this.tabs.getActiveTab();
        if (tab === undefined)
            throw new Error("No active conversation tab");
        if (tab.mode !== "active" || tab.lifecycle !== "idle") {
            throw new Error("Active conversation tab is read-only");
        }
        return tab;
    }
    viewSignature() {
        const tab = this.tabs.getActiveTab();
        return tab === undefined
            ? "empty"
            : [
                tab.id,
                tab.mode,
                tab.lifecycle,
                tab.conversation.currentNodeId,
                tab.conversation.revision
            ].join("|");
    }
}
exports.ActiveConversationStore = ActiveConversationStore;

},
"tabs/conversation-tabs-store.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationTabsStore = void 0;
const schema_1 = require("../domain/schema");
function deepFreeze(value) {
    if (typeof value !== "object" || value === null || Object.isFrozen(value)) {
        return value;
    }
    for (const child of Object.values(value))
        deepFreeze(child);
    return Object.freeze(value);
}
function normalizeTab(tab) {
    const conversation = (0, schema_1.parseConversation)(structuredClone(tab.conversation));
    if (tab.id.length === 0 || tab.conversationId.length === 0) {
        throw new Error("Tab identity cannot be empty");
    }
    if (conversation.id !== tab.conversationId) {
        throw new Error("Tab conversation ID does not match its conversation");
    }
    if ((tab.mode === "active" && conversation.status !== "active") ||
        (tab.mode === "archived" && conversation.status !== "archived")) {
        throw new Error("Tab mode does not match conversation status");
    }
    return deepFreeze({
        ...structuredClone(tab),
        title: tab.title.trim().length > 0 ? tab.title : conversation.title,
        conversation
    });
}
function emptyState() {
    return deepFreeze({
        schemaVersion: 1,
        activeTabId: null,
        orderedTabIds: [],
        tabs: {}
    });
}
function validateState(state) {
    if (new Set(state.orderedTabIds).size !== state.orderedTabIds.length) {
        throw new Error("Tab order contains duplicate IDs");
    }
    const tabIds = Object.keys(state.tabs);
    if (tabIds.length !== state.orderedTabIds.length ||
        tabIds.some((tabId) => !state.orderedTabIds.includes(tabId))) {
        throw new Error("Tab order does not match the tabs record");
    }
    if (state.activeTabId !== null &&
        state.tabs[state.activeTabId] === undefined) {
        throw new Error("Active tab does not exist");
    }
}
class ConversationTabsStore {
    state = emptyState();
    listeners = new Set();
    getSnapshot() {
        return this.state;
    }
    getTab(tabId) {
        return this.state.tabs[tabId];
    }
    getActiveTab() {
        return this.state.activeTabId === null
            ? undefined
            : this.state.tabs[this.state.activeTabId];
    }
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
    open(tab) {
        const existing = Object.values(this.state.tabs).find((entry) => entry.conversationId === tab.conversationId);
        if (existing !== undefined) {
            this.select(existing.id);
            return existing.id;
        }
        const normalized = normalizeTab(tab);
        if (this.state.tabs[normalized.id] !== undefined) {
            throw new Error(`Tab already exists: ${normalized.id}`);
        }
        this.replace({
            ...structuredClone(this.state),
            activeTabId: normalized.id,
            orderedTabIds: [...this.state.orderedTabIds, normalized.id],
            tabs: { ...this.state.tabs, [normalized.id]: normalized }
        });
        return normalized.id;
    }
    select(tabId) {
        const selected = this.state.tabs[tabId];
        if (selected === undefined)
            throw new Error(`Tab not found: ${tabId}`);
        if (this.state.activeTabId === tabId && !selected.unread)
            return;
        this.replace({
            ...structuredClone(this.state),
            activeTabId: tabId,
            tabs: {
                ...this.state.tabs,
                [tabId]: normalizeTab({ ...structuredClone(selected), unread: false })
            }
        });
    }
    remove(tabId) {
        if (this.state.tabs[tabId] === undefined) {
            throw new Error(`Tab not found: ${tabId}`);
        }
        const previousOrder = this.state.orderedTabIds;
        const removedIndex = previousOrder.indexOf(tabId);
        const orderedTabIds = previousOrder.filter((id) => id !== tabId);
        const tabs = Object.fromEntries(Object.entries(this.state.tabs).filter(([id]) => id !== tabId));
        let activeTabId = this.state.activeTabId;
        if (activeTabId === tabId) {
            activeTabId =
                orderedTabIds[removedIndex] ??
                    orderedTabIds[removedIndex - 1] ??
                    null;
        }
        this.replace({
            schemaVersion: 1,
            activeTabId,
            orderedTabIds,
            tabs
        });
    }
    reorder(tabId, targetIndex) {
        const sourceIndex = this.state.orderedTabIds.indexOf(tabId);
        if (sourceIndex < 0)
            throw new Error(`Tab not found: ${tabId}`);
        const boundedTarget = Math.max(0, Math.min(Math.trunc(targetIndex), this.state.orderedTabIds.length - 1));
        if (sourceIndex === boundedTarget)
            return;
        const orderedTabIds = [...this.state.orderedTabIds];
        orderedTabIds.splice(sourceIndex, 1);
        orderedTabIds.splice(boundedTarget, 0, tabId);
        this.replace({ ...structuredClone(this.state), orderedTabIds });
    }
    updateTab(tabId, updater) {
        const current = this.state.tabs[tabId];
        if (current === undefined)
            throw new Error(`Tab not found: ${tabId}`);
        const updated = normalizeTab(updater(structuredClone(current)));
        if (updated.id !== tabId || updated.conversationId !== current.conversationId) {
            throw new Error("Tab updater cannot change tab identity");
        }
        this.replace({
            ...structuredClone(this.state),
            tabs: { ...this.state.tabs, [tabId]: updated }
        });
    }
    updateConversation(tabId, updater) {
        this.updateTab(tabId, (tab) => {
            const conversation = (0, schema_1.parseConversation)(updater(tab.conversation));
            return {
                ...tab,
                title: conversation.title,
                mode: conversation.status,
                conversation
            };
        });
    }
    replace(next) {
        validateState(next);
        this.state = deepFreeze(structuredClone(next));
        for (const listener of this.listeners)
            listener();
    }
}
exports.ConversationTabsStore = ConversationTabsStore;

},
"tabs/plugin-data.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EMPTY_TABS_WORKSPACE = exports.DEFAULT_SETTINGS = void 0;
exports.normalizeConfiguredModel = normalizeConfiguredModel;
exports.parsePluginData = parsePluginData;
const workspace_state_1 = require("./workspace-state");
exports.DEFAULT_SETTINGS = {
    provider: "openai",
    model: "gpt-5-mini",
    baseUrl: "",
    treeWidth: 220,
    knowledgeFolder: "TreeTalk 知识",
    treeCaptureFolder: "TreeTalk",
    obsidianMarkdownCompatibility: true,
    contextOptimizationEnabled: false,
    contextMode: "full",
    webSearchEnabled: false
};
exports.EMPTY_TABS_WORKSPACE = {
    schemaVersion: 1,
    activeConversationId: null,
    openConversationIds: []
};
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isProviderKind(value) {
    return (value === "openai" ||
        value === "deepseek" ||
        value === "openai-compatible" ||
        value === "anthropic" ||
        value === "gemini");
}
function normalizeConfiguredModel(provider, model) {
    const trimmed = model.trim();
    if (provider === "deepseek" &&
        (trimmed === "deepseek-chat" || trimmed === "deepseek-reasoner")) {
        return "deepseek-v4-flash";
    }
    if (trimmed.length > 0)
        return trimmed;
    return provider === "deepseek" ? "deepseek-v4-flash" : exports.DEFAULT_SETTINGS.model;
}
function parseSettings(value) {
    if (!isRecord(value))
        return { ...exports.DEFAULT_SETTINGS };
    const contextOptimizationEnabled = typeof value.contextOptimizationEnabled === "boolean"
        ? value.contextOptimizationEnabled
        : exports.DEFAULT_SETTINGS.contextOptimizationEnabled;
    const provider = isProviderKind(value.provider)
        ? value.provider
        : exports.DEFAULT_SETTINGS.provider;
    const model = normalizeConfiguredModel(provider, typeof value.model === "string" ? value.model : exports.DEFAULT_SETTINGS.model);
    return {
        provider,
        model,
        baseUrl: typeof value.baseUrl === "string"
            ? value.baseUrl
            : exports.DEFAULT_SETTINGS.baseUrl,
        treeWidth: typeof value.treeWidth === "number" &&
            Number.isFinite(value.treeWidth) &&
            value.treeWidth > 0
            ? value.treeWidth
            : exports.DEFAULT_SETTINGS.treeWidth,
        knowledgeFolder: typeof value.knowledgeFolder === "string" &&
            value.knowledgeFolder.trim().length > 0
            ? value.knowledgeFolder.trim()
            : exports.DEFAULT_SETTINGS.knowledgeFolder,
        treeCaptureFolder: typeof value.treeCaptureFolder === "string" &&
            value.treeCaptureFolder.trim().length > 0
            ? value.treeCaptureFolder.trim()
            : exports.DEFAULT_SETTINGS.treeCaptureFolder,
        obsidianMarkdownCompatibility: typeof value.obsidianMarkdownCompatibility === "boolean"
            ? value.obsidianMarkdownCompatibility
            : exports.DEFAULT_SETTINGS.obsidianMarkdownCompatibility,
        contextOptimizationEnabled,
        contextMode: contextOptimizationEnabled ? "balanced" : "full",
        webSearchEnabled: typeof value.webSearchEnabled === "boolean"
            ? value.webSearchEnabled
            : exports.DEFAULT_SETTINGS.webSearchEnabled
    };
}
function parsePluginData(value) {
    const source = isRecord(value) ? value : {};
    const settingsSource = isRecord(source.settings) ? source.settings : source;
    let tabs = { ...exports.EMPTY_TABS_WORKSPACE };
    try {
        tabs = (0, workspace_state_1.parseTabsWorkspaceData)(source.tabs);
    }
    catch {
        // Invalid UI workspace state never invalidates canonical Vault data.
    }
    return {
        settings: parseSettings(settingsSource),
        tabs
    };
}

},
"tabs/tab-lifecycle-controller.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TabLifecycleController = void 0;
const archive_service_1 = require("../archive/archive-service");
class TabLifecycleController {
    tabs;
    persistence;
    archive;
    queue;
    saveWorkspace;
    constructor(tabs, persistence, archive, queue, saveWorkspace) {
        this.tabs = tabs;
        this.persistence = persistence;
        this.archive = archive;
        this.queue = queue;
        this.saveWorkspace = saveWorkspace;
    }
    async close(tabId) {
        const initial = this.requireIdle(tabId);
        const requestEpoch = initial.requestEpoch + 1;
        if (initial.mode === "archived") {
            this.tabs.updateTab(tabId, (tab) => ({ ...tab, requestEpoch }));
            this.tabs.remove(tabId);
            await this.saveWorkspace();
            return;
        }
        this.tabs.updateTab(tabId, (tab) => ({
            ...tab,
            lifecycle: "closing",
            requestEpoch
        }));
        try {
            await this.persistence.flush(initial.folder);
            const current = this.requireLifecycle(tabId, "closing", requestEpoch);
            const archived = await this.queue.run(() => this.archive.archive(current.folder, current.conversation));
            this.persistence.renameFolder(current.folder, archived.folder);
            this.persistence.seed(archived.folder, archived.conversation.revision);
            this.tabs.remove(tabId);
            await this.saveWorkspace();
        }
        catch (error) {
            this.recover(tabId, requestEpoch, error);
            throw error;
        }
    }
    async restore(tabId) {
        const initial = this.requireIdle(tabId);
        if (initial.mode !== "archived") {
            throw new Error("Only a historical tab can be restored");
        }
        const requestEpoch = initial.requestEpoch + 1;
        this.tabs.updateTab(tabId, (tab) => ({
            ...tab,
            lifecycle: "restoring",
            requestEpoch
        }));
        try {
            await this.persistence.flush(initial.folder);
            const current = this.requireLifecycle(tabId, "restoring", requestEpoch);
            const restored = await this.queue.run(() => this.archive.restore(current.folder, current.conversation));
            this.persistence.renameFolder(current.folder, restored.folder);
            this.persistence.seed(restored.folder, restored.conversation.revision);
            this.tabs.updateTab(tabId, (tab) => ({
                ...tab,
                folder: restored.folder,
                title: restored.conversation.title,
                mode: "active",
                lifecycle: "idle",
                conversation: restored.conversation
            }));
            await this.saveWorkspace();
        }
        catch (error) {
            this.recover(tabId, requestEpoch, error);
            throw error;
        }
    }
    requireIdle(tabId) {
        const tab = this.tabs.getTab(tabId);
        if (tab === undefined)
            throw new Error(`Tab not found: ${tabId}`);
        if (tab.lifecycle !== "idle") {
            throw new Error(`Tab lifecycle is already ${tab.lifecycle}`);
        }
        return tab;
    }
    requireLifecycle(tabId, lifecycle, requestEpoch) {
        const tab = this.tabs.getTab(tabId);
        if (tab === undefined ||
            tab.lifecycle !== lifecycle ||
            tab.requestEpoch !== requestEpoch) {
            throw new Error("Tab lifecycle operation is stale");
        }
        return tab;
    }
    recover(tabId, requestEpoch, error) {
        const current = this.tabs.getTab(tabId);
        if (current === undefined || current.requestEpoch !== requestEpoch)
            return;
        if (error instanceof archive_service_1.ArchiveError && error.recovery !== undefined) {
            const recovery = error.recovery;
            if (current.folder !== recovery.folder) {
                this.persistence.renameFolder(current.folder, recovery.folder);
            }
            this.persistence.seed(recovery.folder, recovery.conversation.revision);
            this.tabs.updateTab(tabId, (tab) => ({
                ...tab,
                folder: recovery.folder,
                title: recovery.conversation.title,
                mode: recovery.conversation.status,
                lifecycle: "idle",
                conversation: recovery.conversation
            }));
            return;
        }
        this.tabs.updateTab(tabId, (tab) => ({
            ...tab,
            lifecycle: "idle"
        }));
    }
}
exports.TabLifecycleController = TabLifecycleController;

},
"tabs/tab-response-router.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TabResponseRouter = void 0;
const assistant_response_1 = require("../domain/assistant-response");
class TabResponseRouter {
    store;
    constructor(store) {
        this.store = store;
    }
    capture(tabId, nodeId) {
        const tab = this.store.getTab(tabId);
        if (tab === undefined ||
            tab.mode !== "active" ||
            tab.lifecycle !== "idle" ||
            tab.conversation.nodes[nodeId] === undefined) {
            throw new Error("Cannot capture a response ticket for an inactive tab");
        }
        return Object.freeze({
            tabId,
            conversationId: tab.conversationId,
            nodeId,
            requestEpoch: tab.requestEpoch
        });
    }
    append(ticket, response) {
        this.update(ticket, response, (conversation) => (0, assistant_response_1.appendAssistantResponse)(conversation, response));
    }
    start(ticket, response) {
        this.update(ticket, response, (conversation) => (0, assistant_response_1.startAssistantResponse)(conversation, response));
    }
    delta(ticket, response) {
        this.update(ticket, response, (conversation) => (0, assistant_response_1.appendAssistantDelta)(conversation, response));
    }
    finish(ticket, response) {
        this.update(ticket, response, (conversation) => (0, assistant_response_1.finishAssistantResponse)(conversation, response));
    }
    update(ticket, response, mutate) {
        const tab = this.store.getTab(ticket.tabId);
        if (tab === undefined ||
            tab.conversationId !== ticket.conversationId ||
            tab.mode !== "active" ||
            tab.lifecycle !== "idle" ||
            tab.requestEpoch !== ticket.requestEpoch ||
            tab.conversation.nodes[ticket.nodeId] === undefined ||
            response.conversationId !== ticket.conversationId ||
            response.nodeId !== ticket.nodeId) {
            throw new Error("Response ticket is stale");
        }
        const hidden = this.store.getSnapshot().activeTabId !== ticket.tabId;
        this.store.updateTab(ticket.tabId, (current) => {
            const conversation = mutate(current.conversation);
            return {
                ...current,
                title: conversation.title,
                unread: current.unread || hidden,
                conversation
            };
        });
    }
}
exports.TabResponseRouter = TabResponseRouter;

},
"tabs/tab-workspace-operations.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.openConversationTab = openConversationTab;
exports.selectAdjacentTab = selectAdjacentTab;
exports.updateTabsForRename = updateTabsForRename;
function openConversationTab(store, folder, conversation) {
    return store.open({
        id: conversation.id,
        conversationId: conversation.id,
        folder,
        title: conversation.title,
        mode: conversation.status,
        lifecycle: "idle",
        unread: false,
        requestEpoch: 0,
        conversation
    });
}
function selectAdjacentTab(store, direction) {
    const state = store.getSnapshot();
    if (state.orderedTabIds.length === 0)
        return;
    const currentIndex = state.activeTabId === null
        ? 0
        : state.orderedTabIds.indexOf(state.activeTabId);
    const nextIndex = (currentIndex + direction + state.orderedTabIds.length) %
        state.orderedTabIds.length;
    const nextTabId = state.orderedTabIds[nextIndex];
    if (nextTabId !== undefined)
        store.select(nextTabId);
}
function updateTabsForRename(store, persistence, oldPath, newPath) {
    let changed = 0;
    for (const tabId of store.getSnapshot().orderedTabIds) {
        const tab = store.getTab(tabId);
        if (tab === undefined ||
            (tab.folder !== oldPath && !tab.folder.startsWith(`${oldPath}/`))) {
            continue;
        }
        const previousFolder = tab.folder;
        const renamedFolder = `${newPath}${previousFolder.slice(oldPath.length)}`;
        persistence.renameFolder(previousFolder, renamedFolder);
        store.updateTab(tabId, (current) => ({
            ...current,
            folder: renamedFolder
        }));
        changed += 1;
    }
    return changed;
}

},
"tabs/types.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

},
"tabs/workspace-state.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTabsWorkspaceData = parseTabsWorkspaceData;
exports.serializeTabsWorkspace = serializeTabsWorkspace;
exports.restoreTabsWorkspace = restoreTabsWorkspace;
const schema_1 = require("../domain/schema");
function requireObject(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
        throw new TypeError("Tabs workspace data must be an object");
    }
    return value;
}
function parseTabsWorkspaceData(value) {
    const source = requireObject(value);
    if (source.schemaVersion !== 1) {
        throw new TypeError("Unsupported tabs workspace schema");
    }
    if (source.activeConversationId !== null &&
        typeof source.activeConversationId !== "string") {
        throw new TypeError("activeConversationId must be a string or null");
    }
    if (!Array.isArray(source.openConversationIds) ||
        source.openConversationIds.some((id) => typeof id !== "string")) {
        throw new TypeError("openConversationIds must be a string array");
    }
    const openConversationIds = source.openConversationIds;
    if (new Set(openConversationIds).size !== openConversationIds.length) {
        throw new TypeError("openConversationIds contains duplicate IDs");
    }
    return {
        schemaVersion: 1,
        activeConversationId: source.activeConversationId,
        openConversationIds: [...openConversationIds]
    };
}
function serializeTabsWorkspace(state) {
    const activeTab = state.activeTabId === null ? undefined : state.tabs[state.activeTabId];
    return {
        schemaVersion: 1,
        activeConversationId: activeTab?.conversationId ?? null,
        openConversationIds: state.orderedTabIds.flatMap((tabId) => {
            const tab = state.tabs[tabId];
            return tab === undefined ? [] : [tab.conversationId];
        })
    };
}
async function restoreTabsWorkspace(data, load) {
    const parsed = parseTabsWorkspaceData(data);
    const tabs = [];
    for (const conversationId of parsed.openConversationIds) {
        try {
            const descriptor = await load(conversationId);
            if (descriptor === undefined ||
                descriptor.conversationId !== conversationId) {
                continue;
            }
            const conversation = (0, schema_1.parseConversation)(descriptor.conversation);
            if (conversation.id !== conversationId)
                continue;
            tabs.push({
                id: conversationId,
                conversationId,
                folder: descriptor.folder,
                title: conversation.title,
                mode: conversation.status,
                lifecycle: "idle",
                unread: false,
                requestEpoch: 0,
                conversation
            });
        }
        catch {
            // Missing or corrupt conversations remain untouched in the Vault.
        }
    }
    const restoredIds = new Set(tabs.map((tab) => tab.conversationId));
    return {
        activeConversationId: parsed.activeConversationId !== null &&
            restoredIds.has(parsed.activeConversationId)
            ? parsed.activeConversationId
            : tabs[0]?.conversationId ?? null,
        tabs
    };
}

},
"views/conversation-switcher.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderConversationSwitcher = renderConversationSwitcher;
function renderConversationSwitcher(container, store, actions) {
    let expanded = false;
    let draggedConversationId;
    const render = () => {
        const state = store.getSnapshot();
        const active = store.getActiveTab();
        container.replaceChildren();
        container.className = "treetalk-space-switcher";
        if (active === undefined)
            return;
        const trigger = document.createElement("button");
        trigger.type = "button";
        trigger.className = "treetalk-space-trigger";
        trigger.setAttribute("aria-expanded", String(expanded));
        trigger.title = "对话列表";
        const direction = document.createElement("span");
        direction.className = "treetalk-space-direction";
        direction.setAttribute("aria-hidden", "true");
        direction.textContent = "›";
        const triggerLabel = document.createElement("span");
        triggerLabel.className = "treetalk-space-label";
        triggerLabel.textContent = "对话列表";
        trigger.append(direction, triggerLabel);
        trigger.addEventListener("click", () => {
            expanded = !expanded;
            render();
        });
        container.append(trigger);
        if (!expanded)
            return;
        const list = document.createElement("div");
        list.className = "treetalk-space-list";
        for (const [index, tabId] of state.orderedTabIds.entries()) {
            const tab = state.tabs[tabId];
            if (tab === undefined)
                continue;
            const row = document.createElement("div");
            row.className = "treetalk-space-row";
            row.dataset.conversationId = tab.id;
            row.draggable = tab.lifecycle === "idle";
            if (state.activeTabId === tab.id)
                row.classList.add("is-active");
            if (tab.unread)
                row.classList.add("has-unread");
            if (tab.lifecycle !== "idle") {
                row.classList.add(`is-${tab.lifecycle}`);
            }
            const select = document.createElement("button");
            select.type = "button";
            select.className = "treetalk-space-select";
            select.title = tab.title;
            select.setAttribute("aria-current", state.activeTabId === tab.id ? "page" : "false");
            const dot = document.createElement("span");
            dot.className = "treetalk-space-dot";
            dot.setAttribute("aria-hidden", "true");
            const label = document.createElement("span");
            label.className = "treetalk-space-label";
            label.textContent = tab.title;
            select.append(dot, label);
            select.addEventListener("click", () => {
                store.select(tab.id);
            });
            const close = document.createElement("button");
            close.type = "button";
            close.className = "treetalk-space-close";
            close.setAttribute("aria-label", `关闭 ${tab.title}`);
            close.textContent = "×";
            close.disabled = tab.lifecycle !== "idle";
            close.addEventListener("click", (event) => {
                event.stopPropagation();
                void actions.close(tab.id);
            });
            row.addEventListener("dragstart", () => {
                draggedConversationId = tab.id;
            });
            row.addEventListener("dragover", (event) => event.preventDefault());
            row.addEventListener("drop", (event) => {
                event.preventDefault();
                if (draggedConversationId !== undefined &&
                    draggedConversationId !== tab.id) {
                    actions.reorder(draggedConversationId, index);
                }
                draggedConversationId = undefined;
            });
            row.addEventListener("dragend", () => {
                draggedConversationId = undefined;
            });
            row.append(select, close);
            list.append(row);
        }
        const create = document.createElement("button");
        create.type = "button";
        create.className = "treetalk-space-create";
        create.textContent = "新建对话";
        create.addEventListener("click", () => {
            void actions.create();
        });
        list.append(create);
        container.append(list);
    };
    const unsubscribe = store.subscribe(render);
    render();
    return unsubscribe;
}

},
"views/conversation-view.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toggleDraftMode = toggleDraftMode;
exports.selectionTracesForMessage = selectionTracesForMessage;
exports.attachSelectionContext = attachSelectionContext;
exports.responseProgressLabel = responseProgressLabel;
exports.shouldShowResponseProgress = shouldShowResponseProgress;
exports.renderConversationPanel = renderConversationPanel;
const draft_contexts_1 = require("../domain/draft-contexts");
const markdown_compatibility_1 = require("../domain/markdown-compatibility");
const selection_anchor_1 = require("../domain/selection-anchor");
const tree_commands_1 = require("../domain/tree-commands");
const types_1 = require("../domain/types");
const transient_usage_store_1 = require("../providers/transient-usage-store");
const excerpt_drag_1 = require("../knowledge/excerpt-drag");
const message_renderer_1 = require("./message-renderer");
const rendered_selection_1 = require("./rendered-selection");
function toggleDraftMode(mode) {
    return mode === "continue" ? "child" : "continue";
}
function findMessage(store, messageId) {
    const conversation = store.getSnapshot();
    if (conversation === undefined)
        throw new Error("No active conversation");
    for (const node of Object.values(conversation.nodes)) {
        const message = node.messages.find((entry) => entry.id === messageId);
        if (message !== undefined)
            return { nodeId: node.id, message };
    }
    throw new Error(`Message not found: ${messageId}`);
}
function selectionTracesForMessage(conversation, messageId) {
    const traces = [];
    const seen = new Set();
    for (const node of Object.values(conversation.nodes)) {
        for (const userMessage of node.messages) {
            if (userMessage.role !== "user")
                continue;
            for (const context of userMessage.selectionContexts ?? []) {
                if (!(0, types_1.isMessageSelectionContext)(context) ||
                    context.messageId !== messageId) {
                    continue;
                }
                const key = `${node.id}:${(0, draft_contexts_1.selectionContextKey)(context)}`;
                if (seen.has(key))
                    continue;
                seen.add(key);
                traces.push({ anchor: context, targetNodeId: node.id });
            }
        }
    }
    return traces.sort((left, right) => right.anchor.startOffset - left.anchor.startOffset ||
        right.anchor.endOffset - left.anchor.endOffset);
}
async function attachSelectionContext(store, messageId, visibleText, startOffset, endOffset, quoteOverride) {
    const conversation = store.getSnapshot();
    if (conversation === undefined)
        throw new Error("No active conversation");
    if (conversation.status === "archived") {
        throw new Error("Archived conversations are read-only");
    }
    const targetConversationId = conversation.id;
    const located = findMessage(store, messageId);
    const targetNodeId = located.nodeId;
    const anchor = await (0, selection_anchor_1.createSelectionAnchor)({
        messageId,
        sourceNodeId: located.nodeId,
        sourceRole: located.message.role,
        visibleText,
        startOffset,
        endOffset,
        ...(quoteOverride === undefined ? {} : { quoteOverride })
    });
    store.update((current) => {
        const sourceStillExists = current.nodes[targetNodeId]?.messages.some((message) => message.id === messageId);
        if (current.id !== targetConversationId || sourceStillExists !== true) {
            return current;
        }
        const now = new Date().toISOString();
        const selected = (0, tree_commands_1.addSelectionToDraft)(current, targetNodeId, anchor, now);
        return (0, tree_commands_1.prepareChildDraft)(selected, { nodeId: targetNodeId, now });
    });
    return anchor;
}
function installSelectionDrag(contentElement, store, messageId) {
    const onDragStart = (event) => {
        if (event.dataTransfer === null)
            return;
        const selection = contentElement.ownerDocument.defaultView?.getSelection();
        if (selection === null ||
            selection === undefined ||
            selection.rangeCount === 0 ||
            selection.isCollapsed) {
            return;
        }
        const range = selection.getRangeAt(0);
        if (!contentElement.contains(range.startContainer) ||
            !contentElement.contains(range.endContainer)) {
            return;
        }
        const selectionContext = (0, rendered_selection_1.selectionForDomRange)(contentElement, range);
        if (selectionContext === undefined)
            return;
        const conversation = store.getSnapshot();
        if (conversation === undefined)
            return;
        let located;
        try {
            located = findMessage(store, messageId);
        }
        catch {
            return;
        }
        const sourceNode = conversation.nodes[located.nodeId];
        if (sourceNode === undefined)
            return;
        const currentNode = conversation.nodes[conversation.currentNodeId];
        const matchingAnchor = currentNode?.draft.selectionContexts.find((context) => (0, types_1.isMessageSelectionContext)(context) &&
            context.messageId === messageId &&
            context.startOffset === selectionContext.startOffset &&
            context.endOffset === selectionContext.endOffset &&
            context.quote === selectionContext.sourceText);
        const payload = matchingAnchor === undefined
            ? {
                version: 1,
                conversationId: conversation.id,
                conversationTitle: conversation.title,
                nodeId: located.nodeId,
                nodeTitle: sourceNode.title,
                messageId,
                sourceRole: located.message.role,
                quote: selectionContext.sourceText
            }
            : {
                version: 2,
                conversationId: conversation.id,
                conversationTitle: conversation.title,
                nodeId: located.nodeId,
                nodeTitle: sourceNode.title,
                messageId,
                sourceRole: located.message.role,
                quote: matchingAnchor.quote,
                anchor: matchingAnchor
            };
        (0, excerpt_drag_1.writeExcerptDragData)(event.dataTransfer, payload);
    };
    contentElement.addEventListener("dragstart", onDragStart);
    return () => contentElement.removeEventListener("dragstart", onDragStart);
}
function installMessageTraces(contentElement, conversation, traces, selectNode) {
    const renderedText = (0, rendered_selection_1.canonicalRenderedText)(contentElement);
    const ranges = traces.flatMap((trace) => {
        const resolved = (0, selection_anchor_1.resolveSelectionAnchor)(renderedText, trace.anchor);
        return resolved.status === "resolved"
            ? [{
                    start: resolved.start,
                    end: resolved.end,
                    targetId: trace.targetNodeId
                }]
            : [];
    });
    (0, rendered_selection_1.installSourceAwareTraceRanges)(contentElement, ranges, (targetIds, traceElement) => {
        if (targetIds.length === 1) {
            const targetId = targetIds[0];
            if (targetId !== undefined)
                selectNode(targetId);
            return;
        }
        contentElement
            .querySelector(".treetalk-trace-targets")
            ?.remove();
        const choices = document.createElement("div");
        choices.className =
            "treetalk-trace-targets treetalk-control";
        choices.setAttribute("role", "menu");
        for (const targetId of targetIds) {
            const choice = document.createElement("button");
            choice.type = "button";
            choice.dataset.targetNodeId = targetId;
            choice.textContent =
                conversation.nodes[targetId]?.title ?? "对话分支";
            choice.addEventListener("click", (event) => {
                event.stopPropagation();
                choices.remove();
                selectNode(targetId);
            });
            choices.append(choice);
        }
        traceElement.after(choices);
    });
}
function renderDraftContexts(mount, store) {
    const conversation = store.getSnapshot();
    mount.replaceChildren();
    if (conversation === undefined)
        return;
    const node = conversation.nodes[conversation.currentNodeId];
    if (node === undefined)
        return;
    for (const context of node.draft.selectionContexts) {
        const chip = document.createElement("div");
        chip.className = "treetalk-selection-chip";
        const body = document.createElement("span");
        body.className = "treetalk-selection-chip-body";
        if ((0, types_1.isNoteSelectionContext)(context)) {
            const source = document.createElement("span");
            source.className = "treetalk-selection-chip-source";
            source.textContent = context.fileName;
            source.title = context.filePath;
            body.append(source);
        }
        const quote = document.createElement("span");
        quote.className = "treetalk-selection-chip-text";
        quote.textContent = `“${context.quote}”`;
        body.append(quote);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className =
            "treetalk-selection-chip-remove treetalk-control";
        remove.setAttribute("aria-label", "删除引用上下文");
        remove.textContent = "×";
        remove.addEventListener("click", () => {
            store.update((current) => (0, tree_commands_1.removeSelectionFromDraft)(current, current.currentNodeId, (0, draft_contexts_1.selectionContextKey)(context), new Date().toISOString()));
        });
        if ((0, types_1.isMessageSelectionContext)(context)) {
            const sourceNode = conversation.nodes[context.sourceNodeId] ??
                Object.values(conversation.nodes).find((candidate) => candidate.messages.some((message) => message.id === context.messageId));
            if (sourceNode !== undefined) {
                const payload = {
                    version: 2,
                    conversationId: conversation.id,
                    conversationTitle: conversation.title,
                    nodeId: sourceNode.id,
                    nodeTitle: sourceNode.title,
                    messageId: context.messageId,
                    sourceRole: context.sourceRole,
                    quote: context.quote,
                    anchor: context
                };
                chip.draggable = true;
                chip.addEventListener("dragstart", (event) => {
                    if (event.dataTransfer !== null) {
                        (0, excerpt_drag_1.writeExcerptDragData)(event.dataTransfer, payload);
                    }
                });
            }
        }
        chip.append(body, remove);
        mount.append(chip);
    }
}
function emptyState(container, actions) {
    const empty = document.createElement("div");
    empty.className = "treetalk-empty-state";
    const actionsContainer = document.createElement("div");
    actionsContainer.className = "treetalk-empty-actions";
    const create = document.createElement("button");
    create.type = "button";
    create.className = "treetalk-empty-action";
    create.textContent = "新建对话";
    create.disabled = actions?.createConversation === undefined;
    create.addEventListener("click", () => {
        if (actions?.createConversation !== undefined) {
            void actions.createConversation();
        }
    });
    const history = document.createElement("button");
    history.type = "button";
    history.className = "treetalk-empty-action";
    history.textContent = "打开历史对话";
    history.disabled = actions?.openHistory === undefined;
    history.addEventListener("click", () => {
        if (actions?.openHistory !== undefined)
            void actions.openHistory();
    });
    actionsContainer.append(create, history);
    empty.append(actionsContainer);
    container.append(empty);
}
function scheduleAnimationFrame(document, callback) {
    const view = document.defaultView;
    if (view?.requestAnimationFrame !== undefined) {
        const frame = view.requestAnimationFrame(callback);
        return () => view.cancelAnimationFrame(frame);
    }
    const timer = setTimeout(callback, 0);
    return () => clearTimeout(timer);
}
function messageTraceKey(traces) {
    return traces
        .map((trace) => `${trace.targetNodeId}:${(0, draft_contexts_1.selectionContextKey)(trace.anchor)}`)
        .join("|");
}
function isNearBottom(element) {
    return element.scrollHeight - element.scrollTop - element.clientHeight <= 48;
}
function responseProgressLabel(status) {
    switch (status) {
        case "thinking":
            return "正在思考…";
        case "deciding-web-search":
            return "正在判断是否需要联网…";
        case "searching-web":
            return "正在搜索网页…";
        case "organizing-web-results":
            return "正在整理搜索结果…";
    }
}
function shouldShowResponseProgress(message, status) {
    return (message.role === "assistant" &&
        message.status === "streaming" &&
        message.content.length === 0 &&
        status !== undefined);
}
function formatTokenCount(value) {
    return value === undefined ? "未提供" : value.toLocaleString("zh-CN");
}
function tokenStatsTitle(record) {
    if (record.mode === "full") {
        const input = record.promptTokens ?? record.sentEstimatedTokens;
        const label = record.promptTokens === undefined ? "本轮估算" : "本轮输入";
        return `${label} ${formatTokenCount(input)} Token`;
    }
    const parts = [];
    if (record.reducedTokens >= 256 || record.reductionRatio >= 0.05) {
        parts.push(`本轮减少 ${formatTokenCount(record.reducedTokens)} Token`);
    }
    if ((record.cacheHitTokens ?? 0) > 0) {
        parts.push(`缓存命中 ${formatTokenCount(record.cacheHitTokens)} Token`);
    }
    if (parts.length === 0) {
        parts.push(`本轮输入 ${formatTokenCount(record.promptTokens ?? record.sentEstimatedTokens)} Token`);
    }
    return parts.join(" · ");
}
function referencedNoteNamesLabel(message) {
    const names = message.referencedNoteNames ?? [];
    return names.length === 0 ? "无" : names.join("、");
}
function createTokenStatsDetails(document, record, message) {
    const details = document.createElement("details");
    details.className = "treetalk-token-stats";
    const summary = document.createElement("summary");
    summary.textContent =
        record === undefined
            ? `引用笔记：${referencedNoteNamesLabel(message)}`
            : tokenStatsTitle(record);
    const rows = document.createElement("div");
    rows.className = "treetalk-token-stats-rows";
    const values = [];
    if (record !== undefined) {
        const total = record.promptTokens === undefined && record.completionTokens === undefined
            ? undefined
            : (record.promptTokens ?? 0) + (record.completionTokens ?? 0);
        values.push(["实际输入", formatTokenCount(record.promptTokens)], ["实际输出", formatTokenCount(record.completionTokens)], ["本轮合计", formatTokenCount(total)], ["缓存命中", formatTokenCount(record.cacheHitTokens)], ["缓存未命中", formatTokenCount(record.cacheMissTokens)], ["上下文估算", formatTokenCount(record.sentEstimatedTokens)]);
        if ((record.noteContextOriginalEstimatedTokens ?? 0) > 0) {
            values.push(["笔记上下文", record.noteContextTrimmed ? "已裁剪" : "完整"], [
                "笔记原始估算",
                formatTokenCount(record.noteContextOriginalEstimatedTokens)
            ], [
                "笔记实际发送",
                formatTokenCount(record.noteContextSentEstimatedTokens)
            ]);
        }
        if (record.mode === "balanced") {
            values.push(["完整模式估算", formatTokenCount(record.fullEstimatedTokens)], ["减少输入", formatTokenCount(record.reducedTokens)], ["减少比例", `${(record.reductionRatio * 100).toFixed(1)}%`]);
        }
    }
    values.push(["引用笔记", referencedNoteNamesLabel(message)]);
    for (const [label, value] of values) {
        const row = document.createElement("div");
        row.className = "treetalk-token-stats-row";
        const name = document.createElement("span");
        name.textContent = label;
        const amount = document.createElement("span");
        amount.textContent = value;
        row.append(name, amount);
        rows.append(row);
    }
    details.append(summary, rows);
    return details;
}
function renderConversationPanel(container, store, actions, rendererFactory = message_renderer_1.plainTextMessageRendererFactory, highlights, options) {
    let disposed = false;
    let suppressSync = false;
    let shellKey = "";
    let messagesMount;
    let composer;
    let followBottom = true;
    const messageViews = new Map();
    let shellCleanups = [];
    let sourceRangeCleanup;
    const sourceTimerCancels = [];
    const removeVisualSourceHighlight = () => {
        sourceRangeCleanup?.();
        sourceRangeCleanup = undefined;
        for (const element of container.querySelectorAll(".treetalk-source-message-flash")) {
            element.classList.remove("treetalk-source-message-flash");
        }
    };
    const clearSourceHighlight = () => {
        for (const cancel of sourceTimerCancels.splice(0))
            cancel();
        removeVisualSourceHighlight();
    };
    const scheduleSourceTimer = (callback, delay) => {
        const timer = setTimeout(callback, delay);
        sourceTimerCancels.push(() => clearTimeout(timer));
    };
    const applySourceHighlight = (source, attempt = 0) => {
        if (disposed)
            return;
        const conversation = store.getSnapshot();
        if (conversation === undefined ||
            conversation.id !== source.conversationId ||
            conversation.currentNodeId !== source.nodeId ||
            source.messageId === undefined) {
            return;
        }
        const messageView = messageViews.get(source.messageId);
        if (messageView === undefined ||
            messageView.renderedContent === undefined) {
            const delays = [16, 48, 96, 180, 320];
            const delay = delays[attempt];
            if (delay !== undefined) {
                scheduleSourceTimer(() => applySourceHighlight(source, attempt + 1), delay);
            }
            return;
        }
        removeVisualSourceHighlight();
        messageView.article.classList.add("treetalk-source-message-flash");
        if (typeof messageView.article.scrollIntoView === "function") {
            messageView.article.scrollIntoView({
                block: "center",
                behavior: "smooth"
            });
        }
        if (source.anchor !== undefined &&
            source.anchor.messageId === source.messageId) {
            const resolved = (0, selection_anchor_1.resolveSelectionAnchor)((0, rendered_selection_1.canonicalRenderedText)(messageView.content), source.anchor);
            if (resolved.status === "resolved") {
                const installed = (0, rendered_selection_1.installSourceRangeHighlight)(messageView.content, resolved.start, resolved.end);
                if (installed.elements.length > 0) {
                    sourceRangeCleanup = () => installed.cleanup();
                    const firstElement = installed.elements[0];
                    if (firstElement !== undefined &&
                        typeof firstElement.scrollIntoView === "function") {
                        firstElement.scrollIntoView({
                            block: "center",
                            behavior: "smooth"
                        });
                    }
                }
            }
        }
        scheduleSourceTimer(removeVisualSourceHighlight, 1800);
    };
    const disposeMessageView = (view) => {
        view.renderVersion += 1;
        view.cancelScheduled?.();
        for (const cleanup of view.cleanups)
            cleanup();
        view.renderer.dispose();
        view.article.remove();
    };
    const disposeShell = () => {
        clearSourceHighlight();
        for (const view of messageViews.values())
            disposeMessageView(view);
        messageViews.clear();
        for (const cleanup of shellCleanups)
            cleanup();
        shellCleanups = [];
        messagesMount = undefined;
        composer = undefined;
        shellKey = "";
    };
    const toggleMode = () => {
        const snapshot = store.getSnapshot();
        if (snapshot === undefined ||
            snapshot.status !== "active" ||
            !(store.canMutate?.() ?? true)) {
            return;
        }
        const inputText = composer?.input.value;
        store.update((current) => {
            const next = structuredClone(current);
            const node = next.nodes[next.currentNodeId];
            if (node === undefined)
                return next;
            const now = new Date().toISOString();
            if (inputText !== undefined)
                node.draft.text = inputText;
            node.draft.mode = toggleDraftMode(node.draft.mode);
            node.updatedAt = now;
            next.updatedAt = now;
            next.revision += 1;
            return next;
        });
    };
    const handleBranchShortcut = (event, requireActiveLeaf) => {
        if (event.defaultPrevented ||
            event.isComposing ||
            event.repeat ||
            !event.altKey ||
            event.ctrlKey ||
            event.metaKey ||
            event.shiftKey ||
            event.key.toLowerCase() !== "f") {
            return;
        }
        if (requireActiveLeaf) {
            const targetInside = event.target instanceof Node && container.contains(event.target);
            const activeLeaf = container.closest(".workspace-leaf.mod-active");
            if (!targetInside && activeLeaf === null)
                return;
        }
        const snapshot = store.getSnapshot();
        if (snapshot === undefined ||
            snapshot.status !== "active" ||
            !(store.canMutate?.() ?? true)) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        toggleMode();
    };
    const createComposer = () => {
        const root = document.createElement("div");
        const contextMount = document.createElement("div");
        const inputRow = document.createElement("div");
        const input = document.createElement("textarea");
        const webSearch = document.createElement("button");
        const send = document.createElement("button");
        root.className = "treetalk-composer";
        contextMount.className = "treetalk-selection-contexts";
        inputRow.className = "treetalk-input-row";
        input.rows = 2;
        input.placeholder = "输入问题…";
        webSearch.type = "button";
        webSearch.className = "treetalk-web-search-toggle treetalk-control";
        webSearch.textContent = "🌐";
        send.type = "button";
        input.addEventListener("input", () => {
            suppressSync = true;
            try {
                store.update((current) => {
                    const next = structuredClone(current);
                    const node = next.nodes[next.currentNodeId];
                    if (node === undefined)
                        return next;
                    const now = new Date().toISOString();
                    node.draft.text = input.value;
                    node.updatedAt = now;
                    next.updatedAt = now;
                    next.revision += 1;
                    return next;
                });
            }
            finally {
                suppressSync = false;
            }
        });
        inputRow.append(input, webSearch, send);
        root.append(contextMount, inputRow);
        return { root, contextMount, input, webSearch, send };
    };
    const syncCaptureButton = (view, message) => {
        const shouldShow = message.role === "assistant" &&
            message.status === "complete" &&
            actions?.captureAnswer !== undefined;
        if (!shouldShow) {
            view.captureButton?.remove();
            delete view.captureButton;
            return;
        }
        if (view.captureButton === undefined) {
            const button = document.createElement("button");
            button.type = "button";
            button.className = "treetalk-capture-answer treetalk-control";
            button.textContent = "沉淀回答";
            button.addEventListener("click", () => {
                void actions.captureAnswer?.(message.id);
            });
            view.captureButton = button;
        }
        view.article.append(view.captureButton);
    };
    const syncResponseProgress = (view, message) => {
        const status = options?.transientResponseStatus?.get(message.id);
        if (!shouldShowResponseProgress(message, status)) {
            view.responseProgress?.remove();
            delete view.responseProgress;
            return;
        }
        if (view.responseProgress === undefined) {
            const progress = container.ownerDocument.createElement("div");
            progress.className = "treetalk-response-progress";
            progress.setAttribute("role", "status");
            progress.setAttribute("aria-live", "polite");
            progress.setAttribute("aria-atomic", "true");
            view.responseProgress = progress;
            view.article.insertBefore(progress, view.content);
        }
        view.responseProgress.textContent = responseProgressLabel(status);
    };
    const syncTokenStats = (view, message) => {
        const record = options?.transientUsage?.get(message.id);
        const shouldShow = message.role === "assistant" && message.status === "complete";
        if (!shouldShow) {
            view.tokenStats?.remove();
            delete view.tokenStats;
            return;
        }
        const displayRecord = record !== undefined && (0, transient_usage_store_1.shouldDisplayTokenStats)(record) ? record : undefined;
        const open = view.tokenStats?.open ?? false;
        view.tokenStats?.remove();
        view.tokenStats = createTokenStatsDetails(container.ownerDocument, displayRecord, message);
        view.tokenStats.open = open;
        view.article.append(view.tokenStats);
    };
    const performMessageRender = async (view, version, pending) => {
        const staging = container.ownerDocument.createElement("div");
        const compatibilityEnabled = pending.message.role === "assistant" &&
            pending.message.status === "streaming" &&
            (options?.isObsidianMarkdownCompatibilityEnabled?.() ?? false);
        const split = compatibilityEnabled
            ? (0, markdown_compatibility_1.splitStreamingMarkdown)(pending.message.content)
            : { stableMarkdown: pending.message.content, pendingSource: "" };
        const renderedMount = container.ownerDocument.createElement("div");
        renderedMount.className = "treetalk-streaming-rendered";
        if (split.stableMarkdown.length > 0) {
            try {
                await view.renderer.render(split.stableMarkdown, renderedMount);
            }
            catch {
                renderedMount.textContent = split.stableMarkdown;
            }
            (0, message_renderer_1.enhanceRenderedMarkdown)(renderedMount, split.stableMarkdown);
            staging.append(renderedMount);
        }
        if (split.pendingSource.length > 0) {
            const pendingSource = container.ownerDocument.createElement("pre");
            pendingSource.className = "treetalk-streaming-source-tail";
            pendingSource.textContent = split.pendingSource;
            staging.append(pendingSource);
        }
        installMessageTraces(staging, pending.conversation, pending.traces, (nodeId) => store.selectNode(nodeId));
        if (disposed ||
            version !== view.renderVersion ||
            !messageViews.has(pending.message.id)) {
            return;
        }
        view.content.replaceChildren(...staging.childNodes);
        view.content.classList.add("is-rendered");
        view.renderedContent = pending.message.content;
        view.renderedTraceKey = pending.traceKey;
        view.renderedStatus = pending.message.status;
        if (followBottom && messagesMount !== undefined) {
            messagesMount.scrollTop = messagesMount.scrollHeight;
        }
    };
    const scheduleMessageRender = (view, pending) => {
        view.renderVersion += 1;
        view.pending = pending;
        if (view.cancelScheduled !== undefined)
            return;
        view.cancelScheduled = scheduleAnimationFrame(container.ownerDocument, () => {
            delete view.cancelScheduled;
            const latest = view.pending;
            if (latest === undefined)
                return;
            const version = view.renderVersion;
            void performMessageRender(view, version, latest);
        });
    };
    const createMessageView = (message, mutable) => {
        const article = document.createElement("article");
        const content = document.createElement("div");
        article.dataset.messageId = message.id;
        content.className = "treetalk-message-content";
        article.append(content);
        const cleanups = [installSelectionDrag(content, store, message.id)];
        if (mutable) {
            const onMouseUp = () => {
                const selection = content.ownerDocument.defaultView?.getSelection();
                if (selection === null ||
                    selection === undefined ||
                    selection.rangeCount === 0 ||
                    selection.isCollapsed) {
                    return;
                }
                const range = selection.getRangeAt(0);
                if (!content.contains(range.startContainer) ||
                    !content.contains(range.endContainer)) {
                    return;
                }
                const selectionContext = (0, rendered_selection_1.selectionForDomRange)(content, range);
                if (selectionContext === undefined)
                    return;
                void attachSelectionContext(store, message.id, selectionContext.visibleText, selectionContext.startOffset, selectionContext.endOffset, selectionContext.sourceText).catch(() => undefined);
            };
            content.addEventListener("mouseup", onMouseUp);
            cleanups.push(() => content.removeEventListener("mouseup", onMouseUp));
        }
        return {
            article,
            content,
            renderer: rendererFactory.create(),
            renderVersion: 0,
            cleanups
        };
    };
    const syncMessages = (conversation, mutable) => {
        const node = conversation.nodes[conversation.currentNodeId];
        if (node === undefined || messagesMount === undefined)
            return;
        const currentIds = new Set(node.messages.map((message) => message.id));
        for (const [messageId, view] of messageViews) {
            if (!currentIds.has(messageId)) {
                disposeMessageView(view);
                messageViews.delete(messageId);
            }
        }
        for (const message of node.messages) {
            let view = messageViews.get(message.id);
            if (view === undefined) {
                view = createMessageView(message, mutable);
                messageViews.set(message.id, view);
            }
            view.article.className =
                `treetalk-message is-${message.role} is-${message.status}`;
            if (view.article.parentElement !== messagesMount) {
                messagesMount.append(view.article);
            }
            syncCaptureButton(view, message);
            syncResponseProgress(view, message);
            syncTokenStats(view, message);
            const traces = selectionTracesForMessage(conversation, message.id);
            const traceKey = messageTraceKey(traces);
            if (view.renderedContent !== message.content ||
                view.renderedTraceKey !== traceKey ||
                view.renderedStatus !== message.status) {
                scheduleMessageRender(view, {
                    message,
                    conversation,
                    nodeId: node.id,
                    mutable,
                    traceKey,
                    traces
                });
            }
        }
    };
    const syncComposer = (conversation) => {
        if (composer === undefined)
            return;
        const node = conversation.nodes[conversation.currentNodeId];
        if (node === undefined)
            return;
        composer.root.className = `treetalk-composer is-${node.draft.mode}`;
        renderDraftContexts(composer.contextMount, store);
        const isStreaming = node.messages.some((message) => message.role === "assistant" && message.status === "streaming");
        composer.input.disabled = isStreaming;
        if (composer.input.ownerDocument.activeElement !== composer.input &&
            composer.input.value !== node.draft.text) {
            composer.input.value = node.draft.text;
        }
        const webSearch = options?.webSearch;
        const webSearchAvailable = webSearch?.isAvailable() ?? false;
        const webSearchEnabled = webSearch?.isEnabled() ?? false;
        composer.webSearch.disabled = isStreaming || !webSearchAvailable;
        composer.webSearch.className = [
            "treetalk-web-search-toggle",
            "treetalk-control",
            webSearchEnabled ? "is-enabled" : "",
            webSearchAvailable ? "" : "is-unavailable"
        ].filter((entry) => entry.length > 0).join(" ");
        composer.webSearch.setAttribute("aria-pressed", String(webSearchEnabled));
        composer.webSearch.setAttribute("aria-label", webSearchEnabled ? "关闭联网模式" : "开启联网模式");
        composer.webSearch.title = webSearchAvailable
            ? webSearchEnabled
                ? "联网模式已开启：DeepSeek 会自动判断是否搜索网页"
                : "联网模式已关闭"
            : "当前服务商暂不支持联网模式";
        composer.webSearch.onclick = null;
        if (!isStreaming && webSearchAvailable && webSearch !== undefined) {
            composer.webSearch.onclick = () => {
                void webSearch.setEnabled(!webSearch.isEnabled());
            };
        }
        composer.send.onclick = null;
        if (isStreaming) {
            composer.send.className = "treetalk-send treetalk-stop";
            composer.send.setAttribute("aria-label", "停止生成");
            composer.send.textContent = "■";
            composer.send.onclick = () => {
                if (actions?.stop !== undefined)
                    void actions.stop();
            };
        }
        else {
            composer.send.className = "treetalk-send";
            composer.send.setAttribute("aria-label", "发送");
            composer.send.textContent = "↑";
            composer.send.onclick = () => {
                const text = composer?.input.value.trim() ?? "";
                if (text.length > 0 && actions !== undefined)
                    void actions.send(text);
            };
        }
    };
    const buildShell = (conversation, mutable, mode) => {
        disposeShell();
        container.replaceChildren();
        container.className = "treetalk-conversation";
        if (conversation === undefined) {
            shellKey = "empty";
            emptyState(container, actions);
            return;
        }
        shellKey = [
            conversation.id,
            conversation.currentNodeId,
            conversation.status,
            mode ?? "unknown",
            String(mutable)
        ].join(":");
        if (mode === "archived") {
            const historyBar = document.createElement("div");
            historyBar.className = "treetalk-history-bar is-archived";
            const restore = document.createElement("button");
            restore.type = "button";
            restore.className = "treetalk-restore";
            restore.textContent = "恢复对话";
            restore.disabled = actions?.restore === undefined;
            restore.addEventListener("click", () => {
                if (actions?.restore !== undefined)
                    void actions.restore();
            });
            historyBar.append(restore);
            container.append(historyBar);
        }
        if (mode === "active" && actions?.captureTree !== undefined) {
            const captureBar = document.createElement("div");
            captureBar.className = "treetalk-capture-bar";
            const captureTree = document.createElement("button");
            captureTree.type = "button";
            captureTree.className = "treetalk-capture-tree";
            captureTree.textContent = "沉淀对话树";
            captureTree.addEventListener("click", () => {
                void actions.captureTree?.();
            });
            captureBar.append(captureTree);
            container.append(captureBar);
        }
        messagesMount = document.createElement("div");
        messagesMount.className = "treetalk-messages";
        followBottom = true;
        const onScroll = () => {
            if (messagesMount !== undefined)
                followBottom = isNearBottom(messagesMount);
        };
        messagesMount.addEventListener("scroll", onScroll, { passive: true });
        shellCleanups.push(() => messagesMount?.removeEventListener("scroll", onScroll));
        shellCleanups.push((0, message_renderer_1.installObsidianFormulaSelection)(messagesMount));
        container.append(messagesMount);
        if (mutable) {
            composer = createComposer();
            container.append(composer.root);
            const onContainerKeyDown = (event) => handleBranchShortcut(event, false);
            container.addEventListener("keydown", onContainerKeyDown);
            shellCleanups.push(() => container.removeEventListener("keydown", onContainerKeyDown));
            const view = container.ownerDocument.defaultView;
            if (view !== null) {
                const onWindowKeyDown = (event) => handleBranchShortcut(event, true);
                view.addEventListener("keydown", onWindowKeyDown);
                shellCleanups.push(() => view.removeEventListener("keydown", onWindowKeyDown));
            }
        }
    };
    const sync = () => {
        const conversation = store.getSnapshot();
        const mode = store.getMode?.() ?? conversation?.status;
        const mutable = mode === "active" &&
            conversation?.status === "active" &&
            (store.canMutate?.() ?? true);
        const nextKey = conversation === undefined
            ? "empty"
            : [
                conversation.id,
                conversation.currentNodeId,
                conversation.status,
                mode ?? "unknown",
                String(mutable)
            ].join(":");
        if (nextKey !== shellKey)
            buildShell(conversation, mutable, mode);
        if (conversation === undefined)
            return;
        syncMessages(conversation, mutable);
        if (mutable)
            syncComposer(conversation);
    };
    const unsubscribe = store.subscribe(() => {
        if (!suppressSync)
            sync();
    });
    const unsubscribeHighlights = highlights?.subscribe((source) => {
        clearSourceHighlight();
        applySourceHighlight(source);
    });
    const unsubscribeUsage = options?.transientUsage?.subscribe(() => {
        if (!disposed)
            sync();
    });
    const unsubscribeResponseStatus = options?.transientResponseStatus?.subscribe(() => {
        if (!disposed)
            sync();
    });
    const unsubscribeWebSearch = options?.webSearch?.subscribe(() => {
        if (!disposed)
            sync();
    });
    sync();
    return () => {
        disposed = true;
        unsubscribe();
        unsubscribeHighlights?.();
        unsubscribeUsage?.();
        unsubscribeResponseStatus?.();
        unsubscribeWebSearch?.();
        disposeShell();
    };
}

},
"views/message-renderer.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.plainTextMessageRendererFactory = exports.ObsidianMessageRendererFactory = void 0;
exports.installObsidianFormulaSelection = installObsidianFormulaSelection;
exports.enhanceRenderedMarkdown = enhanceRenderedMarkdown;
const obsidian_1 = require("obsidian");
const SOURCE_TEXT_ATTRIBUTE = "data-treetalk-source-text";
const VISIBLE_TEXT_ATTRIBUTE = "data-treetalk-visible-text";
function tokenRanges(markdown, pattern) {
    return [...markdown.matchAll(pattern)].map((match) => {
        const raw = match[0];
        const start = match.index;
        return { raw, start, end: start + raw.length };
    });
}
function maskRanges(markdown, ranges) {
    const characters = new Array(markdown.length);
    for (let index = 0; index < markdown.length; index += 1) {
        characters[index] = markdown.charAt(index);
    }
    for (const range of ranges) {
        for (let index = range.start; index < range.end; index += 1) {
            characters[index] = " ";
        }
    }
    return characters.join("");
}
function sourceTokens(markdown) {
    const blockMath = tokenRanges(markdown, /\$\$[\s\S]*?\$\$/gu);
    const fencedCode = tokenRanges(markdown, /```[^\n]*\n[\s\S]*?```|~~~[^\n]*\n[\s\S]*?~~~/gu);
    const withoutBlocks = maskRanges(markdown, [...blockMath, ...fencedCode]);
    const inlineCode = tokenRanges(withoutBlocks, /(`+)[^`\n]+?\1/gu);
    const withoutCode = maskRanges(withoutBlocks, inlineCode);
    const inlineMath = tokenRanges(withoutCode, /(?<!\\)\$(?!\$)(?:\\.|[^$\n\\])+(?<!\\)\$/gu);
    return {
        blockMath: blockMath.map((entry) => entry.raw),
        inlineMath: inlineMath.map((entry) => markdown.slice(entry.start, entry.end)),
        fencedCode: fencedCode.map((entry) => entry.raw),
        inlineCode: inlineCode.map((entry) => markdown.slice(entry.start, entry.end)),
        links: tokenRanges(withoutCode, /(?<!!)\[[^\]]+\]\([^)]+\)|\[\[[^\]]+\]\]/gu).map((entry) => markdown.slice(entry.start, entry.end)),
        strong: tokenRanges(withoutCode, /\*\*(?=\S)[\s\S]*?\S\*\*|__(?=\S)[\s\S]*?\S__/gu).map((entry) => markdown.slice(entry.start, entry.end)),
        emphasis: tokenRanges(withoutCode, /(?<!\*)\*(?!\*)(?=\S)[^*\n]*?\S\*(?!\*)|(?<!_)_(?!_)(?=\S)[^_\n]*?\S_(?!_)/gu).map((entry) => markdown.slice(entry.start, entry.end)),
        deleted: tokenRanges(withoutCode, /~~(?=\S)[\s\S]*?\S~~/gu).map((entry) => markdown.slice(entry.start, entry.end))
    };
}
function outermostElements(container, selector) {
    const elements = [...container.querySelectorAll(selector)];
    return elements.filter((candidate) => !elements.some((other) => other !== candidate && other.contains(candidate)));
}
function sourceVisibleText(rendered, rawSource) {
    const candidates = [
        rendered.getAttribute(VISIBLE_TEXT_ATTRIBUTE),
        rendered.textContent,
        rendered.getAttribute("aria-label"),
        rendered.querySelector("[aria-label]")?.getAttribute("aria-label")
    ];
    for (const candidate of candidates) {
        const normalized = candidate?.trim();
        if (normalized !== undefined && normalized.length > 0)
            return normalized;
    }
    return rawSource;
}
function annotateElements(elements, tokens) {
    for (const [index, element] of elements.entries()) {
        const token = tokens[index];
        if (token === undefined)
            break;
        element.setAttribute(SOURCE_TEXT_ATTRIBUTE, token);
        element.setAttribute(VISIBLE_TEXT_ATTRIBUTE, sourceVisibleText(element, token));
        element.classList.add("treetalk-source-atomic");
    }
}
function installFormulaSelectionSource(rendered, rawSource) {
    if (rendered.closest(".treetalk-formula-block") !== null)
        return;
    const parent = rendered.parentNode;
    if (parent === null)
        return;
    const wrapper = rendered.ownerDocument.createElement("div");
    wrapper.className = "treetalk-formula-block treetalk-source-atomic";
    wrapper.setAttribute(SOURCE_TEXT_ATTRIBUTE, rawSource);
    wrapper.setAttribute(VISIBLE_TEXT_ATTRIBUTE, sourceVisibleText(rendered, rawSource));
    parent.replaceChild(wrapper, rendered);
    rendered.removeAttribute(SOURCE_TEXT_ATTRIBUTE);
    rendered.removeAttribute(VISIBLE_TEXT_ATTRIBUTE);
    rendered.classList.remove("treetalk-source-atomic");
    rendered.classList.add("treetalk-formula-rendered");
    rendered.hidden = false;
    rendered.setAttribute("aria-hidden", "false");
    const source = rendered.ownerDocument.createElement("pre");
    source.className = "treetalk-formula-source";
    source.textContent = rawSource;
    source.hidden = true;
    source.setAttribute("aria-hidden", "true");
    wrapper.append(source, rendered);
}
function syncFormulaPresentation(wrapper) {
    const rendered = wrapper.querySelector(".treetalk-formula-rendered");
    const source = wrapper.querySelector(".treetalk-formula-source");
    if (rendered === null || source === null)
        return;
    const selectionSourceMode = wrapper.classList.contains("is-selection-source");
    rendered.hidden = false;
    rendered.setAttribute("aria-hidden", "false");
    source.hidden = !selectionSourceMode;
    source.setAttribute("aria-hidden", String(!selectionSourceMode));
}
function rangeIntersectsNode(range, node) {
    try {
        return range.intersectsNode(node);
    }
    catch {
        return false;
    }
}
/**
 * Mirrors Obsidian live preview while selecting Markdown: formulas stay
 * rendered normally, but any formula crossed by the active DOM selection also
 * exposes its original LaTeX in place. The preview remains visible underneath,
 * matching Obsidian's editor selection behavior.
 */
function installObsidianFormulaSelection(root) {
    const document = root.ownerDocument;
    let adjustingSelection = false;
    const blocks = () => [
        ...root.querySelectorAll(".treetalk-formula-block")
    ];
    const clearSelectionSources = () => {
        for (const block of blocks()) {
            block.classList.remove("is-selection-source");
            syncFormulaPresentation(block);
        }
    };
    const syncSelectionSources = () => {
        if (adjustingSelection)
            return;
        const selection = document.defaultView?.getSelection();
        if (selection === null ||
            selection === undefined ||
            selection.rangeCount === 0 ||
            selection.isCollapsed) {
            clearSelectionSources();
            return;
        }
        const ranges = Array.from({ length: selection.rangeCount }, (_, index) => selection.getRangeAt(index)).filter((range) => root.contains(range.startContainer) &&
            root.contains(range.endContainer));
        let adjusted = false;
        for (const block of blocks()) {
            const selected = ranges.some((range) => rangeIntersectsNode(range, block));
            block.classList.toggle("is-selection-source", selected);
            syncFormulaPresentation(block);
            if (!selected)
                continue;
            const source = block.querySelector(".treetalk-formula-source");
            if (source === null)
                continue;
            const sourceText = source.firstChild;
            if (!(sourceText instanceof Text))
                continue;
            for (const range of ranges) {
                if (block.contains(range.startContainer) &&
                    !source.contains(range.startContainer)) {
                    range.setStart(sourceText, 0);
                    adjusted = true;
                }
                if (block.contains(range.endContainer) &&
                    !source.contains(range.endContainer)) {
                    range.setEnd(sourceText, sourceText.data.length);
                    adjusted = true;
                }
            }
        }
        if (adjusted) {
            adjustingSelection = true;
            try {
                selection.removeAllRanges();
                for (const range of ranges)
                    selection.addRange(range);
            }
            finally {
                adjustingSelection = false;
            }
        }
    };
    const onPointerDown = (event) => {
        const target = event.target;
        const element = target instanceof Element ? target : null;
        const block = element?.closest(".treetalk-formula-block");
        if (block === null || block === undefined || !root.contains(block))
            return;
        block.classList.add("is-selection-source");
        syncFormulaPresentation(block);
    };
    document.addEventListener("selectionchange", syncSelectionSources);
    root.addEventListener("pointerdown", onPointerDown);
    return () => {
        document.removeEventListener("selectionchange", syncSelectionSources);
        root.removeEventListener("pointerdown", onPointerDown);
        clearSelectionSources();
    };
}
/**
 * Adds source metadata to Obsidian-rendered Markdown without replacing its
 * native renderer. The metadata lets TreeTalk preserve Markdown/LaTeX when a
 * user selects visual output, and complete block formulas gain an Obsidian-like
 * temporary source preview during native text selection.
 */
function enhanceRenderedMarkdown(container, markdown) {
    const tokens = sourceTokens(markdown);
    const blockMath = outermostElements(container, ".math-block, mjx-container[display='true'], .MathJax_Display, .katex-display");
    annotateElements(blockMath, tokens.blockMath);
    const inlineMath = outermostElements(container, ".math-inline, mjx-container:not([display='true']), span.math").filter((element) => !blockMath.some((block) => block.contains(element)));
    annotateElements(inlineMath, tokens.inlineMath);
    annotateElements(outermostElements(container, "pre"), tokens.fencedCode);
    annotateElements(outermostElements(container, "code:not(pre code)"), tokens.inlineCode);
    annotateElements(outermostElements(container, "a"), tokens.links);
    annotateElements(outermostElements(container, "strong"), tokens.strong);
    annotateElements(outermostElements(container, "em"), tokens.emphasis);
    annotateElements(outermostElements(container, "del, s"), tokens.deleted);
    for (const [index, element] of blockMath.entries()) {
        const rawSource = tokens.blockMath[index];
        if (rawSource !== undefined)
            installFormulaSelectionSource(element, rawSource);
    }
}
class ObsidianMessageRenderer {
    app;
    owner;
    sourcePath;
    component = new obsidian_1.Component();
    disposed = false;
    constructor(app, owner, sourcePath) {
        this.app = app;
        this.owner = owner;
        this.sourcePath = sourcePath;
        this.owner.addChild(this.component);
    }
    async render(markdown, container) {
        if (this.disposed)
            throw new Error("Message renderer is disposed");
        container.replaceChildren();
        await obsidian_1.MarkdownRenderer.render(this.app, markdown, container, this.sourcePath, this.component);
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        this.owner.removeChild(this.component);
    }
}
class ObsidianMessageRendererFactory {
    app;
    owner;
    sourcePath;
    constructor(app, owner, sourcePath = "") {
        this.app = app;
        this.owner = owner;
        this.sourcePath = sourcePath;
    }
    create() {
        return new ObsidianMessageRenderer(this.app, this.owner, this.sourcePath);
    }
}
exports.ObsidianMessageRendererFactory = ObsidianMessageRendererFactory;
exports.plainTextMessageRendererFactory = {
    create: () => ({
        render: (markdown, container) => {
            container.textContent = markdown;
            return Promise.resolve();
        },
        dispose: () => undefined
    })
};

},
"views/obsidian-views.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TreeTalkWorkspaceView = void 0;
const obsidian_1 = require("obsidian");
const conversation_view_1 = require("./conversation-view");
const conversation_switcher_1 = require("./conversation-switcher");
const sidebar_workspace_coordinator_1 = require("./sidebar-workspace-coordinator");
const tree_view_1 = require("./tree-view");
const resizable_split_1 = require("./resizable-split");
const message_renderer_1 = require("./message-renderer");
const DEFAULT_LAYOUT = {
    initialTreeWidth: 220,
    onTreeWidthChange: () => undefined
};
class TreeTalkWorkspaceView extends obsidian_1.ItemView {
    store;
    actions;
    layout;
    tabs;
    spaceActions;
    messageRendererFactory;
    sourceHighlights;
    isObsidianMarkdownCompatibilityEnabled;
    transientUsage;
    transientResponseStatus;
    webSearch;
    cleanups = [];
    constructor(leaf, store, actions, layout = DEFAULT_LAYOUT, tabs, spaceActions, messageRendererFactory, sourceHighlights, isObsidianMarkdownCompatibilityEnabled, transientUsage, transientResponseStatus, webSearch) {
        super(leaf);
        this.store = store;
        this.actions = actions;
        this.layout = layout;
        this.tabs = tabs;
        this.spaceActions = spaceActions;
        this.messageRendererFactory = messageRendererFactory;
        this.sourceHighlights = sourceHighlights;
        this.isObsidianMarkdownCompatibilityEnabled = isObsidianMarkdownCompatibilityEnabled;
        this.transientUsage = transientUsage;
        this.transientResponseStatus = transientResponseStatus;
        this.webSearch = webSearch;
    }
    getViewType() {
        return sidebar_workspace_coordinator_1.TREETALK_WORKSPACE_VIEW_TYPE;
    }
    getDisplayText() {
        return "TreeTalk";
    }
    getIcon() {
        return "messages-square";
    }
    onOpen() {
        this.contentEl.classList.add("treetalk-view-content");
        this.contentEl.replaceChildren();
        const shell = document.createElement("div");
        shell.className = "treetalk-workspace";
        const tree = document.createElement("section");
        tree.className = "treetalk-workspace-tree";
        const switcherMount = document.createElement("div");
        const treeMount = document.createElement("div");
        tree.append(switcherMount, treeMount);
        const conversation = document.createElement("section");
        conversation.className = "treetalk-workspace-conversation";
        const conversationMount = document.createElement("div");
        conversationMount.className = "treetalk-conversation-mount";
        const conversationPanel = document.createElement("div");
        conversationMount.append(conversationPanel);
        conversation.append(conversationMount);
        const separator = document.createElement("div");
        separator.className = "treetalk-resizer";
        shell.append(tree, separator, conversation);
        this.contentEl.append(shell);
        const cleanups = [
            (0, tree_view_1.renderTreePanel)(treeMount, this.store, this.sourceHighlights),
            (0, conversation_view_1.renderConversationPanel)(conversationPanel, this.store, this.actions, this.messageRendererFactory ??
                new message_renderer_1.ObsidianMessageRendererFactory(this.app, this), this.sourceHighlights, {
                isObsidianMarkdownCompatibilityEnabled: this.isObsidianMarkdownCompatibilityEnabled,
                transientUsage: this.transientUsage,
                transientResponseStatus: this.transientResponseStatus,
                webSearch: this.webSearch
            }),
            (0, resizable_split_1.installResizableSplit)(shell, separator, this.layout.initialTreeWidth, (width) => this.layout.onTreeWidthChange(width))
        ];
        if (this.tabs !== undefined && this.spaceActions !== undefined) {
            cleanups.push((0, conversation_switcher_1.renderConversationSwitcher)(switcherMount, this.tabs, this.spaceActions), () => switcherMount.remove());
        }
        else {
            switcherMount.remove();
        }
        this.cleanups = cleanups;
        return Promise.resolve();
    }
    onClose() {
        this.transientUsage?.clear();
        this.transientResponseStatus?.clear();
        for (const cleanup of this.cleanups)
            cleanup();
        this.cleanups = [];
        this.contentEl.classList.remove("treetalk-view-content");
        return Promise.resolve();
    }
}
exports.TreeTalkWorkspaceView = TreeTalkWorkspaceView;

},
"views/rendered-selection.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapRenderedText = mapRenderedText;
exports.offsetsForDomRange = offsetsForDomRange;
exports.canonicalRenderedText = canonicalRenderedText;
exports.installSourceRangeHighlight = installSourceRangeHighlight;
exports.selectionForDomRange = selectionForDomRange;
exports.sourceTextForDomRange = sourceTextForDomRange;
exports.installSourceAwareTraceRanges = installSourceAwareTraceRanges;
exports.installTraceRanges = installTraceRanges;
exports.installTraceSegments = installTraceSegments;
const IGNORED_SELECTOR = [
    ".treetalk-control",
    ".MathJax_Assistive_MathML",
    "[aria-hidden='true']",
    "script",
    "style"
].join(",");
const BLOCK_SELECTOR = [
    "p",
    "li",
    "blockquote",
    "pre",
    "table",
    "tr",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "div"
].join(",");
const TEXT_NODE = 3;
const SOURCE_TEXT_ATTRIBUTE = "data-treetalk-source-text";
const VISIBLE_TEXT_ATTRIBUTE = "data-treetalk-visible-text";
function isSelectableText(node, root) {
    const parent = node.parentElement;
    return (node.data.length > 0 &&
        parent !== null &&
        root.contains(parent) &&
        parent.closest(IGNORED_SELECTOR) === null);
}
function mapRenderedText(root) {
    const showText = root.ownerDocument.defaultView?.NodeFilter.SHOW_TEXT ??
        NodeFilter.SHOW_TEXT;
    const walker = root.ownerDocument.createTreeWalker(root, showText);
    const segments = [];
    const text = [];
    let offset = 0;
    let previousBlock = null;
    let current = walker.nextNode();
    while (current !== null) {
        if (current.nodeType === TEXT_NODE) {
            const textNode = current;
            if (!isSelectableText(textNode, root)) {
                current = walker.nextNode();
                continue;
            }
            const block = textNode.parentElement?.closest(BLOCK_SELECTOR) ?? null;
            if (offset > 0 &&
                block !== null &&
                previousBlock !== null &&
                block !== previousBlock) {
                text.push("\n");
                offset += 1;
            }
            const start = offset;
            offset += textNode.data.length;
            segments.push({ node: textNode, start, end: offset });
            text.push(textNode.data);
            previousBlock = block;
        }
        current = walker.nextNode();
    }
    return { text: text.join(""), segments };
}
function offsetForBoundary(map, container, offset) {
    if (container.nodeType !== TEXT_NODE)
        return undefined;
    const textNode = container;
    const segment = map.segments.find((entry) => entry.node === textNode);
    if (segment === undefined ||
        !Number.isInteger(offset) ||
        offset < 0 ||
        offset > textNode.data.length) {
        return undefined;
    }
    return segment.start + offset;
}
function offsetsForDomRange(map, range) {
    if (range.collapsed)
        return undefined;
    const start = offsetForBoundary(map, range.startContainer, range.startOffset);
    const end = offsetForBoundary(map, range.endContainer, range.endOffset);
    if (start === undefined || end === undefined || start === end) {
        return undefined;
    }
    return {
        start: Math.min(start, end),
        end: Math.max(start, end)
    };
}
function intersectsRange(range, node) {
    try {
        return range.intersectsNode(node);
    }
    catch {
        return false;
    }
}
function selectedTextFromNode(range, node) {
    if (!intersectsRange(range, node))
        return "";
    let start = 0;
    let end = node.data.length;
    if (range.startContainer === node)
        start = range.startOffset;
    if (range.endContainer === node)
        end = range.endOffset;
    if (start < 0 || end > node.data.length || start >= end)
        return "";
    return node.data.slice(start, end);
}
function blockForNode(node) {
    const element = node instanceof Element ? node : node.parentElement;
    return element?.closest(BLOCK_SELECTOR) ?? null;
}
function safeTextContent(node) {
    return node.textContent ?? "";
}
function isTopLevelSourceElement(element, root) {
    if (!element.hasAttribute(SOURCE_TEXT_ATTRIBUTE))
        return false;
    const parentSource = element.parentElement?.closest(`[${SOURCE_TEXT_ATTRIBUTE}]`);
    return (parentSource === null ||
        parentSource === undefined ||
        !root.contains(parentSource));
}
function canonicalRenderedMap(root) {
    const chunks = [];
    const units = [];
    let offset = 0;
    let previousBlock = null;
    const append = (node, visibleText, sourceText) => {
        if (visibleText.length === 0)
            return;
        const block = blockForNode(node);
        if (offset > 0 &&
            block !== null &&
            previousBlock !== null &&
            block !== previousBlock) {
            chunks.push("\n");
            offset += 1;
        }
        const start = offset;
        chunks.push(visibleText);
        offset += visibleText.length;
        units.push({
            node,
            start,
            end: offset,
            visibleText,
            ...(sourceText === undefined ? {} : { sourceText })
        });
        previousBlock = block;
    };
    const visit = (node) => {
        if (node instanceof HTMLElement && isTopLevelSourceElement(node, root)) {
            append(node, node.getAttribute(VISIBLE_TEXT_ATTRIBUTE) ?? safeTextContent(node), node.getAttribute(SOURCE_TEXT_ATTRIBUTE) ?? "");
            return;
        }
        if (node instanceof Element && node.matches(IGNORED_SELECTOR))
            return;
        if (node.nodeType === TEXT_NODE) {
            const textNode = node;
            if (isSelectableText(textNode, root))
                append(textNode, textNode.data);
            return;
        }
        for (const child of node.childNodes)
            visit(child);
    };
    for (const child of root.childNodes)
        visit(child);
    return { text: chunks.join(""), units };
}
function canonicalRenderedText(root) {
    return canonicalRenderedMap(root).text;
}
function installSourceRangeHighlight(root, start, end) {
    const map = canonicalRenderedMap(root);
    if (!Number.isInteger(start) ||
        !Number.isInteger(end) ||
        start < 0 ||
        end > map.text.length ||
        start >= end) {
        return { elements: [], cleanup: () => undefined };
    }
    const elements = [];
    const cleanups = [];
    for (const unit of map.units) {
        const intersectionStart = Math.max(start, unit.start);
        const intersectionEnd = Math.min(end, unit.end);
        if (intersectionStart >= intersectionEnd)
            continue;
        if (unit.node instanceof HTMLElement) {
            const element = unit.node;
            element.classList.add("treetalk-source-range-flash");
            elements.push(element);
            cleanups.push(() => element.classList.remove("treetalk-source-range-flash"));
            continue;
        }
        const localStart = intersectionStart - unit.start;
        const localEnd = intersectionEnd - unit.start;
        const before = unit.node.data.slice(0, localStart);
        const selected = unit.node.data.slice(localStart, localEnd);
        const after = unit.node.data.slice(localEnd);
        const mark = root.ownerDocument.createElement("mark");
        mark.className = "treetalk-source-range-flash";
        mark.textContent = selected;
        const replacement = [];
        if (before.length > 0) {
            replacement.push(root.ownerDocument.createTextNode(before));
        }
        replacement.push(mark);
        if (after.length > 0) {
            replacement.push(root.ownerDocument.createTextNode(after));
        }
        unit.node.replaceWith(...replacement);
        elements.push(mark);
        cleanups.push(() => {
            const parent = mark.parentNode;
            if (parent === null)
                return;
            mark.replaceWith(root.ownerDocument.createTextNode(safeTextContent(mark)));
            parent.normalize();
        });
    }
    let cleaned = false;
    return {
        elements,
        cleanup: () => {
            if (cleaned)
                return;
            cleaned = true;
            for (const cleanup of [...cleanups].reverse())
                cleanup();
        }
    };
}
/**
 * Returns both the canonical visible-text anchor and the model-facing source
 * quote for a rendered selection. Source-annotated elements are atomic: a
 * selection touching one contributes its complete Markdown/LaTeX token and is
 * anchored against the element's rendered visible text, even while a formula
 * is showing its raw source view.
 */
function selectionForDomRange(root, range) {
    if (range.collapsed ||
        !root.contains(range.startContainer) ||
        !root.contains(range.endContainer)) {
        return undefined;
    }
    const map = canonicalRenderedMap(root);
    const selected = [];
    for (const unit of map.units) {
        if (unit.node instanceof Text) {
            const text = selectedTextFromNode(range, unit.node);
            if (text.length === 0)
                continue;
            const localStart = range.startContainer === unit.node ? range.startOffset : 0;
            selected.push({
                start: unit.start + localStart,
                end: unit.start + localStart + text.length,
                sourceText: text
            });
            continue;
        }
        if (intersectsRange(range, unit.node)) {
            selected.push({
                start: unit.start,
                end: unit.end,
                sourceText: unit.sourceText ?? unit.visibleText
            });
        }
    }
    if (selected.length === 0)
        return undefined;
    selected.sort((left, right) => left.start - right.start || left.end - right.end);
    const first = selected[0];
    const last = selected.at(-1);
    if (first === undefined || last === undefined)
        return undefined;
    const sourceChunks = [];
    let previousEnd;
    for (const fragment of selected) {
        if (previousEnd !== undefined && fragment.start > previousEnd) {
            sourceChunks.push(map.text.slice(previousEnd, fragment.start));
        }
        sourceChunks.push(fragment.sourceText);
        previousEnd = fragment.end;
    }
    return {
        visibleText: map.text,
        startOffset: first.start,
        endOffset: last.end,
        sourceText: sourceChunks.join("")
    };
}
/**
 * Builds the model-facing quote for a rendered DOM selection. Normal text is
 * copied character-for-character. Rendered elements annotated with
 * `data-treetalk-source-text` contribute their complete original Markdown or
 * LaTeX token instead of the visual text produced by Obsidian.
 */
function sourceTextForDomRange(root, range) {
    return selectionForDomRange(root, range)?.sourceText;
}
function traceElement(document, text, activate) {
    const trace = document.createElement("span");
    trace.className = "treetalk-selection-trace";
    trace.tabIndex = 0;
    trace.setAttribute("role", "button");
    trace.textContent = text;
    trace.addEventListener("click", activate);
    trace.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ")
            return;
        event.preventDefault();
        activate();
    });
    return trace;
}
function traceTitle(targetIds) {
    return targetIds.length === 1
        ? "打开使用这段原文提问的节点"
        : `选择 ${String(targetIds.length)} 个关联分支`;
}
function targetIdsForRange(ranges, start, end) {
    return [
        ...new Set(ranges
            .filter((range) => range.start < end && range.end > start)
            .map((range) => range.targetId))
    ];
}
/**
 * Installs persistent selection traces using the same source-aware canonical
 * map used while capturing a rendered selection. Source-annotated atoms such
 * as MathJax formulas are highlighted as complete rendered elements instead
 * of trying to wrap inaccessible SVG text nodes.
 */
function installSourceAwareTraceRanges(root, ranges, activate) {
    const map = canonicalRenderedMap(root);
    const validRanges = ranges.filter((range) => Number.isInteger(range.start) &&
        Number.isInteger(range.end) &&
        range.start >= 0 &&
        range.end <= map.text.length &&
        range.start < range.end &&
        range.targetId.length > 0);
    const traces = [];
    for (const unit of map.units) {
        const intersecting = validRanges.filter((range) => range.start < unit.end && range.end > unit.start);
        if (intersecting.length === 0)
            continue;
        if (unit.node instanceof HTMLElement) {
            const targetIds = targetIdsForRange(intersecting, unit.start, unit.end);
            if (targetIds.length === 0)
                continue;
            const element = unit.node;
            element.classList.add("treetalk-selection-trace-atomic");
            element.tabIndex = 0;
            element.setAttribute("role", "button");
            element.title = traceTitle(targetIds);
            const trigger = () => activate(targetIds, element);
            element.addEventListener("click", trigger);
            element.addEventListener("keydown", (event) => {
                if (event.key !== "Enter" && event.key !== " ")
                    return;
                event.preventDefault();
                trigger();
            });
            traces.push(element);
            continue;
        }
        const boundaries = new Set([unit.start, unit.end]);
        for (const range of intersecting) {
            boundaries.add(Math.max(unit.start, range.start));
            boundaries.add(Math.min(unit.end, range.end));
        }
        const ordered = [...boundaries].sort((left, right) => left - right);
        const replacement = [];
        for (let index = 0; index < ordered.length - 1; index += 1) {
            const start = ordered[index];
            const end = ordered[index + 1];
            if (start === undefined || end === undefined || start >= end)
                continue;
            const text = unit.node.data.slice(start - unit.start, end - unit.start);
            const targetIds = targetIdsForRange(intersecting, start, end);
            if (targetIds.length === 0) {
                replacement.push(root.ownerDocument.createTextNode(text));
                continue;
            }
            const trace = traceElement(root.ownerDocument, text, () => activate(targetIds, trace));
            trace.title = traceTitle(targetIds);
            replacement.push(trace);
            traces.push(trace);
        }
        unit.node.replaceWith(...replacement);
    }
    return traces;
}
function installTraceRanges(root, map, ranges, activate) {
    const validRanges = ranges.filter((range) => Number.isInteger(range.start) &&
        Number.isInteger(range.end) &&
        range.start >= 0 &&
        range.end <= map.text.length &&
        range.start < range.end &&
        range.targetId.length > 0);
    const traces = [];
    for (const segment of map.segments) {
        const intersecting = validRanges.filter((range) => range.start < segment.end && range.end > segment.start);
        if (intersecting.length === 0)
            continue;
        const boundaries = new Set([segment.start, segment.end]);
        for (const range of intersecting) {
            boundaries.add(Math.max(segment.start, range.start));
            boundaries.add(Math.min(segment.end, range.end));
        }
        const ordered = [...boundaries].sort((left, right) => left - right);
        const replacement = [];
        for (let index = 0; index < ordered.length - 1; index += 1) {
            const start = ordered[index];
            const end = ordered[index + 1];
            if (start === undefined || end === undefined || start >= end)
                continue;
            const text = segment.node.data.slice(start - segment.start, end - segment.start);
            const targetIds = [
                ...new Set(intersecting
                    .filter((range) => range.start < end && range.end > start)
                    .map((range) => range.targetId))
            ];
            if (targetIds.length === 0) {
                replacement.push(root.ownerDocument.createTextNode(text));
                continue;
            }
            const trace = traceElement(root.ownerDocument, text, () => activate(targetIds, trace));
            trace.title =
                targetIds.length === 1
                    ? "打开使用这段原文提问的节点"
                    : `选择 ${String(targetIds.length)} 个关联分支`;
            replacement.push(trace);
            traces.push(trace);
        }
        segment.node.replaceWith(...replacement);
    }
    return traces;
}
function installTraceSegments(root, map, start, end, activate) {
    if (!Number.isInteger(start) ||
        !Number.isInteger(end) ||
        start < 0 ||
        end > map.text.length ||
        start >= end) {
        return [];
    }
    const traces = [];
    for (const segment of map.segments) {
        const intersectionStart = Math.max(start, segment.start);
        const intersectionEnd = Math.min(end, segment.end);
        if (intersectionStart >= intersectionEnd)
            continue;
        const localStart = intersectionStart - segment.start;
        const localEnd = intersectionEnd - segment.start;
        const before = segment.node.data.slice(0, localStart);
        const selected = segment.node.data.slice(localStart, localEnd);
        const after = segment.node.data.slice(localEnd);
        const trace = traceElement(root.ownerDocument, selected, activate);
        const replacement = [];
        if (before.length > 0) {
            replacement.push(root.ownerDocument.createTextNode(before));
        }
        replacement.push(trace);
        if (after.length > 0) {
            replacement.push(root.ownerDocument.createTextNode(after));
        }
        segment.node.replaceWith(...replacement);
        traces.push(trace);
    }
    return traces;
}

},
"views/resizable-split.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.installResizableSplit = installResizableSplit;
const MIN_TREE_WIDTH = 140;
const MAX_TREE_RATIO = 0.65;
function containerWidth(shell) {
    return shell.getBoundingClientRect().width || shell.clientWidth;
}
function clampWidth(shell, width) {
    const available = containerWidth(shell);
    const maximum = available > 0 ? Math.max(MIN_TREE_WIDTH, Math.floor(available * MAX_TREE_RATIO)) : width;
    return Math.min(Math.max(Math.round(width), MIN_TREE_WIDTH), maximum);
}
function applyWidth(shell, separator, width) {
    shell.style.setProperty("--treetalk-tree-width", `${String(width)}px`);
    separator.setAttribute("aria-valuenow", String(width));
}
function installResizableSplit(shell, separator, initialWidth, onWidthChange) {
    let dragging = false;
    let currentWidth = clampWidth(shell, initialWidth);
    separator.setAttribute("role", "separator");
    separator.setAttribute("aria-orientation", "vertical");
    separator.setAttribute("aria-label", "调整树状列表宽度");
    separator.setAttribute("aria-valuemin", String(MIN_TREE_WIDTH));
    separator.tabIndex = 0;
    applyWidth(shell, separator, currentWidth);
    const move = (event) => {
        if (!dragging)
            return;
        const left = shell.getBoundingClientRect().left;
        currentWidth = clampWidth(shell, event.clientX - left);
        applyWidth(shell, separator, currentWidth);
    };
    const stop = () => {
        if (!dragging)
            return;
        dragging = false;
        separator.classList.remove("is-resizing");
        onWidthChange(currentWidth);
    };
    const start = (event) => {
        dragging = true;
        separator.classList.add("is-resizing");
        event.preventDefault();
    };
    separator.addEventListener("pointerdown", start);
    document.addEventListener("pointermove", move);
    document.addEventListener("pointerup", stop);
    document.addEventListener("pointercancel", stop);
    return () => {
        separator.removeEventListener("pointerdown", start);
        document.removeEventListener("pointermove", move);
        document.removeEventListener("pointerup", stop);
        document.removeEventListener("pointercancel", stop);
    };
}

},
"views/sidebar-workspace-coordinator.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObsidianSidebarWorkspacePort = exports.SidebarWorkspaceCoordinator = exports.TREETALK_WORKSPACE_VIEW_TYPE = void 0;
exports.TREETALK_WORKSPACE_VIEW_TYPE = "treetalk-workspace";
const LEGACY_VIEW_TYPES = ["treetalk-tree", "treetalk-conversation"];
class SidebarWorkspaceCoordinator {
    workspace;
    constructor(workspace) {
        this.workspace = workspace;
    }
    async open() {
        if (!this.workspace.has(exports.TREETALK_WORKSPACE_VIEW_TYPE)) {
            await this.workspace.openRight(exports.TREETALK_WORKSPACE_VIEW_TYPE);
        }
    }
    async close() {
        await this.workspace.detach(exports.TREETALK_WORKSPACE_VIEW_TYPE);
    }
    async toggle() {
        if (this.workspace.has(exports.TREETALK_WORKSPACE_VIEW_TYPE)) {
            await this.close();
        }
        else {
            await this.open();
        }
    }
    async repairLegacyViews() {
        let foundLegacy = false;
        for (const type of LEGACY_VIEW_TYPES) {
            if (this.workspace.has(type)) {
                foundLegacy = true;
                await this.workspace.detach(type);
            }
        }
        if (foundLegacy)
            await this.open();
    }
}
exports.SidebarWorkspaceCoordinator = SidebarWorkspaceCoordinator;
class ObsidianSidebarWorkspacePort {
    workspace;
    constructor(workspace) {
        this.workspace = workspace;
    }
    has(type) {
        return this.workspace.getLeavesOfType(type).length > 0;
    }
    async openRight(type) {
        const leaf = this.workspace.getRightLeaf(false) ?? this.workspace.getRightLeaf(true);
        if (leaf === null)
            throw new Error("无法创建 TreeTalk 右侧栏");
        await leaf.setViewState({ type, active: true });
        await this.workspace.revealLeaf(leaf);
    }
    detach(type) {
        this.workspace.detachLeavesOfType(type);
        return Promise.resolve();
    }
}
exports.ObsidianSidebarWorkspacePort = ObsidianSidebarWorkspacePort;

},
"views/tree-view.js": function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.renderTreePanel = renderTreePanel;
function requiredNode(store, nodeId) {
    const node = store.getSnapshot()?.nodes[nodeId];
    if (node === undefined)
        throw new Error(`Node not found: ${nodeId}`);
    return node;
}
function renderTreePanel(container, store, highlights) {
    const render = () => {
        const conversation = store.getSnapshot();
        container.replaceChildren();
        container.className = "treetalk-tree";
        if (conversation === undefined)
            return;
        const list = document.createElement("div");
        list.className = "treetalk-tree-list";
        const appendNode = (nodeId, depth) => {
            const node = requiredNode(store, nodeId);
            const row = document.createElement("button");
            row.type = "button";
            row.className = "treetalk-tree-row";
            if (node.id === conversation.currentNodeId) {
                row.classList.add("is-active");
            }
            row.dataset.nodeId = node.id;
            row.dataset.depth = String(depth);
            row.style.setProperty("--treetalk-depth", String(depth));
            row.setAttribute("aria-current", node.id === conversation.currentNodeId ? "true" : "false");
            const dot = document.createElement("span");
            dot.className = "treetalk-node-dot";
            dot.setAttribute("aria-hidden", "true");
            const title = document.createElement("span");
            title.className = "treetalk-node-label";
            title.textContent = node.title;
            row.append(dot, title);
            row.addEventListener("click", () => store.selectNode(node.id));
            list.append(row);
            for (const childId of node.childIds)
                appendNode(childId, depth + 1);
        };
        appendNode(conversation.rootNodeId, 0);
        container.append(list);
    };
    let removeFlash;
    const unsubscribeHighlight = highlights?.subscribe((source) => {
        const conversation = store.getSnapshot();
        if (conversation === undefined ||
            conversation.id !== source.conversationId ||
            conversation.nodes[source.nodeId] === undefined) {
            return;
        }
        removeFlash?.();
        const row = [...container.querySelectorAll("[data-node-id]")].find((candidate) => candidate.dataset.nodeId === source.nodeId);
        if (row === undefined)
            return;
        row.classList.add("treetalk-source-node-flash");
        if (typeof row.scrollIntoView === "function") {
            row.scrollIntoView({ block: "nearest" });
        }
        const view = container.ownerDocument.defaultView;
        const timer = (view ?? globalThis).setTimeout(() => row.classList.remove("treetalk-source-node-flash"), 1800);
        removeFlash = () => {
            (view ?? globalThis).clearTimeout(timer);
            row.classList.remove("treetalk-source-node-flash");
        };
    });
    const unsubscribe = store.subscribe(render);
    render();
    return () => {
        unsubscribe();
        unsubscribeHighlight?.();
        removeFlash?.();
    };
}

}
  };
  const __cache = Object.create(null);
  function __normalize(parts) {
    const output = [];
    for (const part of parts) {
      if (!part || part === '.') continue;
      if (part === '..') output.pop(); else output.push(part);
    }
    return output.join('/');
  }
  function __resolve(parentId, request) {
    const parentParts = parentId.split('/');
    parentParts.pop();
    const base = __normalize(parentParts.concat(request.split('/')));
    const candidates = request.endsWith('.js')
      ? [base]
      : [base + '.js', base + '/index.js', base];
    for (const candidate of candidates) {
      if (__modules[candidate]) return candidate;
    }
    throw new Error('TreeTalk bundle module not found: ' + request + ' from ' + parentId);
  }
  function __load(id) {
    if (__cache[id]) return __cache[id].exports;
    const factory = __modules[id];
    if (!factory) throw new Error('TreeTalk bundle module not found: ' + id);
    const module = { exports: {} };
    __cache[id] = module;
    const localRequire = (request) => request.startsWith('.')
      ? __load(__resolve(id, request))
      : __externalRequire(request);
    factory(module, module.exports, localRequire);
    return module.exports;
  }
  module.exports = __load('main.js');
})();
